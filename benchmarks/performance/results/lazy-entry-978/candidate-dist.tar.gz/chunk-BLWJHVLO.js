import {
  ACResult,
  BJT,
  BSIM3v3,
  BehavioralCurrentSource,
  BehavioralVoltageSource,
  CCCS,
  CCVS,
  Capacitor,
  ClassicBsimMosfet,
  ComplexSparseSolver,
  ControlScriptError,
  ControlScriptExitError,
  CurrentSource,
  DCResult,
  DCSweepResult,
  Diode,
  DistortionResult,
  HFET1,
  Inductor,
  InvalidCircuitError,
  JFET,
  MNAAssembler,
  MOS2,
  MOS3,
  MOSFET,
  MutualInductor,
  NoiseResult,
  PoleZeroResult,
  Resistor,
  SParameterResult,
  SensitivityResult,
  SwitchBase,
  TransferFunctionResult,
  TransientResult,
  UnsupportedControlCommandError,
  UnsupportedMeasureError,
  VCCS,
  VCVS,
  VoltageSource,
  buildACRHS,
  complexVector,
  computeUICInitialSolution,
  createConvergenceTelemetry,
  createDriverFromCompiled,
  createLinearizedFrequencySystem,
  createMatrixVariableIdentities,
  createSimulator,
  evaluateMeasureCards,
  formatVector,
  frequencyGrid,
  generateStepValues,
  getMeasure2,
  gettokWords,
  inpEvaluate,
  isComplex,
  isSavedTransientPoint,
  isTrue,
  measureCards,
  measurePlot,
  measuredAnalyses,
  parseAsync,
  parseControlAnalysisCard,
  parseControlOptions,
  realVector,
  renamed,
  resolveOptions,
  resolveStepTarget,
  runnableTransient,
  scalar,
  solveAC,
  solveDCOperatingPoint,
  solveDCSweep,
  solveStep,
  solveTransferFunction,
  solveTransient,
  toCsc,
  tokenizeNetlist,
  transientStepCap,
  withNetlistOptions
} from "./chunk-3G2EU3P5.js";

// src/parser/control/vector-expression.ts
var UnsupportedExpressionFeature = class extends Error {
  constructor(feature, message) {
    super(message);
    this.feature = feature;
    this.name = "UnsupportedExpressionFeature";
  }
  feature;
};
var ExpressionError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ExpressionError";
  }
};
var NUMBER = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?([A-Za-z]*)/;
var NAME = /^[A-Za-z_@#][A-Za-z0-9_#.:@$]*/;
var WORD_OPERATORS = {
  eq: "eq",
  ne: "ne",
  gt: "gt",
  lt: "lt",
  ge: "ge",
  le: "le",
  and: "and",
  or: "or",
  not: "not"
};
var SYMBOL_OPERATORS = [
  [">=", "ge"],
  ["<=", "le"],
  ["<>", "ne"],
  ["><", "ne"],
  ["!=", "ne"],
  ["==", "eq"],
  ["=", "eq"],
  [">", "gt"],
  ["<", "lt"],
  ["&", "and"],
  ["|", "or"],
  ["~", "not"],
  ["+", "+"],
  ["-", "-"],
  ["*", "*"],
  ["/", "/"],
  ["%", "%"],
  ["^", "^"],
  ["(", "("],
  [")", ")"],
  ["[", "["],
  ["]", "]"],
  [",", ","],
  ["?", "?"],
  [":", ":"]
];
function scaleSuffix(suffix) {
  const lower = suffix.toLowerCase();
  if (lower.startsWith("meg")) return 1e6;
  if (lower.startsWith("mil")) return 254e-7;
  switch (lower[0]) {
    case void 0:
      return 1;
    case "t":
      return 1e12;
    case "g":
      return 1e9;
    case "k":
      return 1e3;
    case "m":
      return 1e-3;
    case "u":
      return 1e-6;
    case "n":
      return 1e-9;
    case "p":
      return 1e-12;
    case "f":
      return 1e-15;
    case "a":
      return 1e-18;
    default:
      return 1;
  }
}
function parseControlNumber(text) {
  const trimmed = text.trim();
  const sign2 = trimmed.startsWith("-") ? -1 : 1;
  const body = trimmed.replace(/^[+-]/, "");
  const match = NUMBER.exec(body);
  if (!match || match[0].length !== body.length) return void 0;
  const mantissa = Number(body.slice(0, body.length - match[1].length));
  return sign2 * mantissa * scaleSuffix(match[1]);
}
function tokenize(text) {
  const tokens = [];
  let rest = text;
  while (rest.length > 0) {
    const whitespace = /^\s+/.exec(rest);
    if (whitespace) {
      rest = rest.slice(whitespace[0].length);
      continue;
    }
    if (rest[0] === '"' || rest[0] === "'") {
      const end = rest.indexOf(rest[0], 1);
      if (end < 0) throw new ExpressionError(`unterminated string in '${text}'`);
      tokens.push({ type: "string", value: rest.slice(1, end) });
      rest = rest.slice(end + 1);
      continue;
    }
    const number = NUMBER.exec(rest);
    if (number) {
      const mantissa = Number(number[0].slice(0, number[0].length - number[1].length));
      tokens.push({ type: "number", value: mantissa * scaleSuffix(number[1]) });
      rest = rest.slice(number[0].length);
      continue;
    }
    const name = NAME.exec(rest);
    if (name) {
      let value = name[0];
      rest = rest.slice(value.length);
      if (value.startsWith("@") && rest.startsWith("[")) {
        const close = rest.indexOf("]");
        if (close < 0) throw new ExpressionError(`unterminated '[' in '${text}'`);
        value += rest.slice(0, close + 1);
        rest = rest.slice(close + 1);
      }
      const lower = value.toLowerCase();
      if (WORD_OPERATORS[lower] && !value.includes(".")) {
        tokens.push({ type: "op", value: WORD_OPERATORS[lower] });
        continue;
      }
      const dot2 = lower.lastIndexOf(".");
      const fn = lower.slice(dot2 + 1);
      if ((fn === "v" || fn === "i") && /^\s*\(/.test(rest)) {
        const open = rest.indexOf("(");
        const close = rest.indexOf(")", open);
        if (close < 0) throw new ExpressionError(`unterminated '(' in '${text}'`);
        tokens.push({
          type: "probe",
          fn,
          ...dot2 >= 0 ? { plot: lower.slice(0, dot2) } : {},
          raw: rest.slice(open + 1, close)
        });
        rest = rest.slice(close + 1);
        continue;
      }
      tokens.push({ type: "name", value });
      continue;
    }
    const symbol = SYMBOL_OPERATORS.find(([operator]) => rest.startsWith(operator));
    if (!symbol) throw new ExpressionError(`unexpected character '${rest[0]}' in '${text}'`);
    tokens.push({ type: "op", value: symbol[1] });
    rest = rest.slice(symbol[0].length);
  }
  return tokens;
}
var INFIX_POWER = {
  "?": 2,
  or: 3,
  and: 4,
  eq: 5,
  ne: 5,
  gt: 5,
  lt: 5,
  ge: 5,
  le: 5,
  ",": 7,
  "+": 8,
  "-": 8,
  "*": 9,
  "/": 9,
  "%": 9,
  "^": 11,
  "[": 12
};
var PREFIX_POWER = 10;
var NOT_POWER = 6;
function parseVectorExpression(text) {
  const tokens = tokenize(text);
  if (tokens.length === 0) throw new ExpressionError("missing expression");
  let position = 0;
  const peek = () => tokens[position];
  const isOp = (token, value) => token?.type === "op" && token.value === value;
  const expect = (value) => {
    if (!isOp(peek(), value)) throw new ExpressionError(`expected '${value}' in '${text}'`);
    position++;
  };
  function prefix() {
    const token = tokens[position++];
    if (!token) throw new ExpressionError(`unexpected end of expression '${text}'`);
    switch (token.type) {
      case "number":
        return { kind: "number", value: token.value };
      case "string":
        return { kind: "name", name: token.value };
      case "probe":
        return {
          kind: "probe",
          fn: token.fn,
          ...token.plot ? { plot: token.plot } : {},
          args: token.raw.split(",").map((arg) => arg.trim()).filter(Boolean)
        };
      case "name": {
        if (isOp(peek(), "(")) {
          position++;
          const args = [];
          if (!isOp(peek(), ")")) {
            args.push(expression(0));
          }
          expect(")");
          return { kind: "call", name: token.value.toLowerCase(), args };
        }
        return { kind: "name", name: token.value };
      }
      case "op":
        if (token.value === "(") {
          const inner = expression(0);
          expect(")");
          return inner;
        }
        if (token.value === "-" || token.value === "+" || token.value === "not") {
          return { kind: "unary", op: token.value, arg: expression(token.value === "not" ? NOT_POWER : PREFIX_POWER) };
        }
        throw new ExpressionError(`unexpected '${token.value}' in '${text}'`);
    }
  }
  function expression(rightPower) {
    let left = prefix();
    for (; ; ) {
      const token = peek();
      if (token?.type !== "op") {
        if (token === void 0) return left;
        throw new ExpressionError(`unexpected operand in '${text}'`);
      }
      const power2 = INFIX_POWER[token.value];
      if (power2 === void 0 || power2 <= rightPower) return left;
      position++;
      switch (token.value) {
        case "[": {
          const index = expression(0);
          expect("]");
          left = { kind: "index", target: left, index };
          break;
        }
        case "?": {
          const whenTrue = expression(INFIX_POWER["?"]);
          expect(":");
          const whenFalse = expression(INFIX_POWER["?"] - 1);
          left = { kind: "ternary", condition: left, whenTrue, whenFalse };
          break;
        }
        case ",":
          left = { kind: "comma", left, right: expression(power2) };
          break;
        case "^":
          left = { kind: "binary", op: "^", left, right: expression(power2 - 1) };
          break;
        default:
          left = { kind: "binary", op: token.value, left, right: expression(power2) };
      }
    }
  }
  const tree = expression(0);
  if (position !== tokens.length) throw new ExpressionError(`unexpected trailing input in '${text}'`);
  return tree;
}
function evaluateVectorExpression(node, env) {
  switch (node.kind) {
    case "number":
      return scalar(node.value);
    case "name":
      return env.lookup(node.name);
    case "probe":
      return evaluateProbe(node, env);
    case "call":
      return evaluateCall(node, env);
    case "unary": {
      const arg = evaluateVectorExpression(node.arg, env);
      if (node.op === "+") return arg;
      if (node.op === "-") return mapComplex(arg, (value) => ({ re: -value.re, im: -value.im }));
      return realVector("result", Array.from(arg.re, (value, index) => value === 0 && (!arg.im || arg.im[index] === 0) ? 1 : 0));
    }
    case "binary":
      return binary(node.op, evaluateVectorExpression(node.left, env), evaluateVectorExpression(node.right, env));
    case "ternary":
      return isTrue(evaluateVectorExpression(node.condition, env)) ? evaluateVectorExpression(node.whenTrue, env) : evaluateVectorExpression(node.whenFalse, env);
    case "comma": {
      const re = evaluateVectorExpression(node.left, env);
      const im = evaluateVectorExpression(node.right, env);
      return combine(re, im, (a, b) => ({ re: a.re - b.im, im: a.im + b.re }), true);
    }
    case "index":
      return evaluateIndex(evaluateVectorExpression(node.target, env), evaluateVectorExpression(node.index, env));
  }
}
function evaluateProbe(node, env) {
  const prefix = node.plot ? `${node.plot}.` : "";
  if (node.args.length === 0 || node.args.length > 2) {
    throw new ExpressionError(`${node.fn}() takes one or two arguments`);
  }
  if (node.fn === "i") {
    if (node.args.length !== 1) throw new ExpressionError("i() takes one branch name");
    return env.lookup(`${prefix}${node.args[0]}#branch`);
  }
  const positive = env.lookup(`${prefix}${node.args[0]}`);
  if (node.args.length === 1) return positive;
  return binary("-", positive, env.lookup(`${prefix}${node.args[1]}`));
}
function evaluateIndex(target, index) {
  const length = target.re.length;
  const at = (raw) => {
    const position = Math.trunc(raw);
    if (!Number.isFinite(raw) || position < 0 || position >= length) {
      throw new ExpressionError(`index ${raw} out of range for vector '${target.name}' of length ${length}`);
    }
    return position;
  };
  const low = at(index.re[0]);
  const high = index.im ? at(index.im[0]) : low;
  const picks = [];
  for (let position = low; low <= high ? position <= high : position >= high; position += low <= high ? 1 : -1) {
    picks.push(position);
  }
  const re = picks.map((position) => target.re[position]);
  return target.im ? complexVector(target.name, re, picks.map((position) => target.im[position])) : realVector(target.name, re);
}
function element(vector, index) {
  const position = Math.min(index, vector.re.length - 1);
  return { re: vector.re[position], im: vector.im ? vector.im[position] : 0 };
}
function combine(left, right, operation, forceComplex = false) {
  if (left.re.length === 0 || right.re.length === 0) throw new ExpressionError("operand has zero length");
  const length = Math.max(left.re.length, right.re.length);
  const re = new Float64Array(length);
  const im = new Float64Array(length);
  let complex = forceComplex || isComplex(left) || isComplex(right);
  for (let index = 0; index < length; index++) {
    const value = operation(element(left, index), element(right, index));
    re[index] = value.re;
    im[index] = value.im;
    if (value.im !== 0) complex = true;
  }
  const scale2 = left.scale ?? right.scale;
  return complex ? complexVector("result", re, im, scale2) : realVector("result", re, scale2);
}
function compare(left, right, test) {
  const result = combine(left, right, (a, b) => ({ re: test(a, b) ? 1 : 0, im: 0 }));
  return realVector("result", result.re, result.scale);
}
function binary(op, left, right) {
  switch (op) {
    case "+":
      return combine(left, right, (a, b) => ({ re: a.re + b.re, im: a.im + b.im }));
    case "-":
      return combine(left, right, (a, b) => ({ re: a.re - b.re, im: a.im - b.im }));
    case "*":
      return combine(left, right, (a, b) => ({ re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re }));
    case "/":
      return combine(left, right, (a, b) => {
        const denominator = b.re * b.re + b.im * b.im;
        if (denominator === 0) throw new ExpressionError("divide by zero");
        return { re: (a.re * b.re + a.im * b.im) / denominator, im: (a.im * b.re - a.re * b.im) / denominator };
      });
    case "%":
      return combine(left, right, (a, b) => {
        if (a.im !== 0 || b.im !== 0) throw new ExpressionError("operator '%' needs real operands");
        const divisor = Math.floor(Math.abs(b.re));
        if (divisor === 0) throw new ExpressionError("argument out of range for mod");
        return { re: Math.floor(Math.abs(a.re)) % divisor, im: 0 };
      });
    case "^":
      return combine(left, right, power);
    case "eq":
      return compare(left, right, (a, b) => a.re === b.re && a.im === b.im);
    case "ne":
      return compare(left, right, (a, b) => a.re !== b.re || a.im !== b.im);
    case "gt":
      return compare(left, right, (a, b) => a.re > b.re);
    case "lt":
      return compare(left, right, (a, b) => a.re < b.re);
    case "ge":
      return compare(left, right, (a, b) => a.re >= b.re);
    case "le":
      return compare(left, right, (a, b) => a.re <= b.re);
    case "and":
      return compare(left, right, (a, b) => (a.re !== 0 || a.im !== 0) && (b.re !== 0 || b.im !== 0));
    case "or":
      return compare(left, right, (a, b) => a.re !== 0 || a.im !== 0 || b.re !== 0 || b.im !== 0);
  }
}
function power(base, exponent) {
  if (base.im === 0 && exponent.im === 0) {
    const value = base.re ** exponent.re;
    if (!Number.isNaN(value)) return { re: value, im: 0 };
  }
  if (base.re === 0 && base.im === 0) return { re: 0, im: 0 };
  return complexExp(multiply(exponent, complexLog(base)));
}
function multiply(a, b) {
  return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re };
}
function divide(a, b) {
  const denominator = b.re * b.re + b.im * b.im;
  return { re: (a.re * b.re + a.im * b.im) / denominator, im: (a.im * b.re - a.re * b.im) / denominator };
}
function complexLog(value) {
  return { re: Math.log(Math.hypot(value.re, value.im)), im: Math.atan2(value.im, value.re) };
}
function complexExp(value) {
  const magnitude2 = Math.exp(value.re);
  return { re: magnitude2 * Math.cos(value.im), im: magnitude2 * Math.sin(value.im) };
}
function complexSqrt(value) {
  const magnitude2 = Math.hypot(value.re, value.im);
  const re = Math.sqrt((magnitude2 + value.re) / 2);
  const im = Math.sign(value.im || 1) * Math.sqrt((magnitude2 - value.re) / 2);
  return { re, im: value.im === 0 && value.re >= 0 ? 0 : im };
}
var I = { re: 0, im: 1 };
var ONE = { re: 1, im: 0 };
var add = (a, b) => ({ re: a.re + b.re, im: a.im + b.im });
var subtract = (a, b) => ({ re: a.re - b.re, im: a.im - b.im });
var COMPLEX_FUNCTIONS = {
  exp: complexExp,
  sqrt: complexSqrt,
  sin: (value) => ({ re: Math.sin(value.re) * Math.cosh(value.im), im: Math.cos(value.re) * Math.sinh(value.im) }),
  cos: (value) => ({ re: Math.cos(value.re) * Math.cosh(value.im), im: -Math.sin(value.re) * Math.sinh(value.im) }),
  tan: (value) => divide(COMPLEX_FUNCTIONS.sin(value), COMPLEX_FUNCTIONS.cos(value)),
  sinh: (value) => ({ re: Math.sinh(value.re) * Math.cos(value.im), im: Math.cosh(value.re) * Math.sin(value.im) }),
  cosh: (value) => ({ re: Math.cosh(value.re) * Math.cos(value.im), im: Math.sinh(value.re) * Math.sin(value.im) }),
  tanh: (value) => divide(COMPLEX_FUNCTIONS.sinh(value), COMPLEX_FUNCTIONS.cosh(value)),
  // atan(z) = i/2 * ln((i + z) / (i - z))
  atan: (value) => multiply({ re: 0, im: 0.5 }, complexLog(divide(add(I, value), subtract(I, value)))),
  // asin(z) = -i ln(iz + sqrt(1 - z^2)), acos(z) = pi/2 - asin(z)
  asin: (value) => multiply({ re: 0, im: -1 }, complexLog(add(multiply(I, value), complexSqrt(subtract(ONE, multiply(value, value)))))),
  acos: (value) => subtract({ re: Math.PI / 2, im: 0 }, COMPLEX_FUNCTIONS.asin(value)),
  // asinh(z) = ln(z + sqrt(z^2 + 1)), acosh(z) = ln(z + sqrt(z + 1) sqrt(z - 1)), atanh(z) = ln((1 + z)/(1 - z)) / 2
  asinh: (value) => complexLog(add(value, complexSqrt(add(multiply(value, value), ONE)))),
  acosh: (value) => complexLog(add(value, multiply(complexSqrt(add(value, ONE)), complexSqrt(subtract(value, ONE))))),
  atanh: (value) => multiply({ re: 0.5, im: 0 }, complexLog(divide(add(ONE, value), subtract(ONE, value))))
};
var REAL_FUNCTIONS = {
  exp: Math.exp,
  sqrt: Math.sqrt,
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  atan: Math.atan,
  asin: Math.asin,
  acos: Math.acos,
  asinh: Math.asinh,
  acosh: Math.acosh,
  atanh: Math.atanh
};
var FLT_MAX = 34028234663852886e22;
var LOGARITHMS = {
  ln: { errorName: "log", real: Math.log },
  log: { errorName: "log", real: Math.log },
  log10: { errorName: "log10", real: Math.log10 }
};
function evaluateLogarithm(arg, { errorName, real }) {
  const clamped = (value) => value === 0 ? -real(FLT_MAX) : real(value);
  if (!isComplex(arg)) {
    return mapReal(arg, (value) => {
      if (!(value >= 0)) throw new ExpressionError(`argument out of range for ${errorName}`);
      return clamped(value);
    });
  }
  return mapComplex(arg, (value) => {
    const magnitude2 = Math.hypot(value.re, value.im);
    if (magnitude2 === 0) return { re: clamped(0), im: 0 };
    return { re: real(magnitude2), im: Math.atan2(value.im, value.re) };
  });
}
var UNSUPPORTED_FUNCTIONS = /* @__PURE__ */ new Set([
  "deriv",
  "integ",
  "interpolate",
  "fft",
  "ifft",
  "avg",
  "group_delay",
  "cph",
  "unwrap",
  "sunif",
  "sgauss",
  "rnd",
  "poisson",
  "exponential",
  "stddev",
  "sum"
]);
function mapComplex(vector, operation) {
  return combine(vector, vector, (value) => operation(value));
}
function mapReal(vector, operation, keepScale = true) {
  return realVector("result", Array.from(vector.re, operation), keepScale ? vector.scale : void 0);
}
function magnitudes(vector) {
  return Float64Array.from(vector.re, (value, index) => Math.hypot(value, vector.im ? vector.im[index] : 0));
}
function count(vector, name) {
  const value = vector.re[0];
  if (!Number.isFinite(value) || value < 0) throw new ExpressionError(`${name}() needs a non-negative length`);
  return Math.trunc(value);
}
function roundHalfEven(value) {
  const floor = Math.floor(value);
  const fraction = value - floor;
  if (fraction > 0.5) return floor + 1;
  if (fraction < 0.5) return floor;
  return floor % 2 === 0 ? floor : floor + 1;
}
function evaluateCall(node, env) {
  const argumentsOf = (arg2) => arg2.kind === "comma" ? [...argumentsOf(arg2.left), ...argumentsOf(arg2.right)] : [arg2];
  const userArgs = node.args.flatMap(argumentsOf);
  const user = env.userFunction(node.name, userArgs.length);
  if (user) {
    const bound = new Map(user.params.map((param, index) => [param.toLowerCase(), evaluateVectorExpression(userArgs[index], env)]));
    return evaluateVectorExpression(user.body, {
      ...env,
      lookup: (name) => bound.get(name.toLowerCase()) ?? env.lookup(name)
    });
  }
  if (UNSUPPORTED_FUNCTIONS.has(node.name)) {
    throw new UnsupportedExpressionFeature(node.name, `vector function '${node.name}()' is not evaluated by spice-ts`);
  }
  if (node.args.length !== 1) {
    throw new ExpressionError(`unknown function '${node.name}' with ${node.args.length} arguments`);
  }
  const arg = evaluateVectorExpression(node.args[0], env);
  const logarithm = LOGARITHMS[node.name];
  if (logarithm) return evaluateLogarithm(arg, logarithm);
  const complexFunction = COMPLEX_FUNCTIONS[node.name];
  if (complexFunction) {
    const real = REAL_FUNCTIONS[node.name];
    if (!isComplex(arg) && Array.from(arg.re).every((value) => !Number.isNaN(real(value)))) {
      return mapReal(arg, real);
    }
    return mapComplex(arg, complexFunction);
  }
  switch (node.name) {
    case "mag":
    case "abs":
    case "magnitude":
      return realVector("result", magnitudes(arg), arg.scale);
    case "ph":
    case "phase": {
      const factor = env.degrees() ? 180 / Math.PI : 1;
      return realVector("result", Array.from(arg.re, (value, index) => Math.atan2(arg.im ? arg.im[index] : 0, value) * factor), arg.scale);
    }
    case "db":
      return realVector("result", Array.from(isComplex(arg) ? magnitudes(arg) : arg.re, (value) => {
        if (!(value > 0)) throw new ExpressionError("argument out of range for db");
        return 20 * Math.log10(value);
      }), arg.scale);
    case "real":
    case "re":
      return realVector("result", arg.re, arg.scale);
    case "imag":
    case "im":
      return realVector("result", arg.im ?? new Float64Array(arg.re.length), arg.scale);
    case "conj":
      return mapComplex(arg, (value) => ({ re: value.re, im: -value.im }));
    case "j":
      return combine(arg, arg, (value) => multiply(I, value), true);
    case "length":
      return scalar(arg.re.length);
    case "vector":
      return realVector("result", Array.from({ length: count(arg, "vector") }, (_, index) => index));
    case "unitvec":
      return realVector("result", new Array(count(arg, "unitvec")).fill(1));
    case "mean": {
      const length = arg.re.length;
      const re = arg.re.reduce((sum, value) => sum + value, 0) / length;
      if (!arg.im) return scalar(re);
      return complexVector("result", [re], [arg.im.reduce((sum, value) => sum + value, 0) / length]);
    }
    case "vecmax":
    case "vecmin": {
      const values = arg.im ? magnitudes(arg) : arg.re;
      if (values.length === 0) throw new ExpressionError(`${node.name}() of an empty vector`);
      return scalar(node.name === "vecmax" ? Math.max(...values) : Math.min(...values));
    }
    case "norm": {
      const largest = Math.max(...magnitudes(arg));
      if (largest === 0) throw new ExpressionError("norm() of a zero vector");
      return binary("/", arg, scalar(largest));
    }
    case "floor":
      return mapComplex(arg, (value) => ({ re: Math.floor(value.re), im: Math.floor(value.im) }));
    case "ceil":
      return mapComplex(arg, (value) => ({ re: Math.ceil(value.re), im: Math.ceil(value.im) }));
    case "nint":
      return mapComplex(arg, (value) => ({ re: roundHalfEven(value.re), im: roundHalfEven(value.im) }));
    default:
      throw new UnsupportedExpressionFeature(node.name, `vector function '${node.name}()' is not evaluated by spice-ts`);
  }
}

// src/parser/control/spectrum.ts
function spectrumWindow(window, time, maxt, span, order) {
  const length = time.length;
  const win = new Float64Array(length);
  const outside = (index) => maxt - time[index] > span;
  const cosine = (index, harmonic) => Math.cos(harmonic * 2 * Math.PI * (time[index] - maxt) / span);
  switch (window) {
    case "none":
      win.fill(1);
      return win;
    case "rectangular":
      for (let i = 0; i < length; i++) win[i] = outside(i) ? 0 : 1;
      return win;
    case "triangle":
    case "bartlet":
    case "bartlett":
      for (let i = 0; i < length; i++) {
        if (outside(i)) win[i] = 0;
        else if (maxt - time[i] < span / 2) win[i] = 4 * (maxt - time[i]) / span;
        else win[i] = 4 - 4 * (maxt - time[i]) / span;
      }
      return win;
    case "hann":
    case "hanning":
    case "cosine":
      for (let i = 0; i < length; i++) win[i] = outside(i) ? 0 : 1 - cosine(i, 1);
      return win;
    case "hamming":
      for (let i = 0; i < length; i++) win[i] = outside(i) ? 0 : 1 - 0.46 / 0.54 * cosine(i, 1);
      return win;
    case "blackman":
      for (let i = 0; i < length; i++) {
        if (outside(i)) continue;
        let value = 1;
        value -= 0.5 / 0.42 * cosine(i, 1);
        value += 0.08 / 0.42 * cosine(i, 2);
        win[i] = value;
      }
      return win;
    case "blackmanharris":
      for (let i = 0; i < length; i++) {
        if (outside(i)) continue;
        let value = 1;
        value -= 0.48829 / 0.35875 * cosine(i, 1);
        value += 0.14128 / 0.35875 * cosine(i, 2);
        value -= 0.01168 / 0.35875 * cosine(i, 3);
        win[i] = value;
      }
      return win;
    case "flattop":
      for (let i = 0; i < length; i++) {
        if (outside(i)) continue;
        let value = 1;
        value -= 1.93 * cosine(i, 1);
        value += 1.29 * cosine(i, 2);
        value -= 0.388 * cosine(i, 3);
        value += 0.032 * cosine(i, 4);
        win[i] = value;
      }
      return win;
    case "gaussian": {
      const sigma = 1 / order;
      const scale2 = 0.83 / sigma;
      for (let i = 0; i < length; i++) {
        win[i] = outside(i) ? 0 : scale2 * Math.exp(-0.5 * ((time[i] - maxt / 2) / (sigma * maxt / 2)) ** 2);
      }
      return win;
    }
    default:
      return void 0;
  }
}
function realDft(input) {
  const n = input.length;
  const re = Float64Array.from(input);
  const im = new Float64Array(n);
  if (n > 1) {
    if ((n & n - 1) === 0) radix2(re, im);
    else bluestein(re, im);
  }
  const bins = Math.floor(n / 2) + 1;
  return { re: re.slice(0, bins), im: im.slice(0, bins) };
}
function radix2(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  const cos = new Float64Array(n >> 1);
  const sin = new Float64Array(n >> 1);
  for (let k = 0; k < n >> 1; k++) {
    cos[k] = Math.cos(2 * Math.PI * k / n);
    sin[k] = -Math.sin(2 * Math.PI * k / n);
  }
  for (let size = 2; size <= n; size <<= 1) {
    const half = size >> 1;
    const stride = n / size;
    for (let start = 0; start < n; start += size) {
      for (let k = 0; k < half; k++) {
        const wr = cos[k * stride];
        const wi = sin[k * stride];
        const a = start + k;
        const b = a + half;
        const tr = re[b] * wr - im[b] * wi;
        const ti = re[b] * wi + im[b] * wr;
        re[b] = re[a] - tr;
        im[b] = im[a] - ti;
        re[a] += tr;
        im[a] += ti;
      }
    }
  }
}
function bluestein(re, im) {
  const n = re.length;
  let m = 1;
  while (m < 2 * n - 1) m <<= 1;
  const chirpRe = new Float64Array(n);
  const chirpIm = new Float64Array(n);
  const period = 2 * n;
  for (let k = 0; k < n; k++) {
    const phase = k * k % period;
    chirpRe[k] = Math.cos(Math.PI * phase / n);
    chirpIm[k] = -Math.sin(Math.PI * phase / n);
  }
  const aRe = new Float64Array(m);
  const aIm = new Float64Array(m);
  for (let k = 0; k < n; k++) {
    aRe[k] = re[k] * chirpRe[k] - im[k] * chirpIm[k];
    aIm[k] = re[k] * chirpIm[k] + im[k] * chirpRe[k];
  }
  const bRe = new Float64Array(m);
  const bIm = new Float64Array(m);
  bRe[0] = chirpRe[0];
  bIm[0] = -chirpIm[0];
  for (let k = 1; k < n; k++) {
    bRe[k] = bRe[m - k] = chirpRe[k];
    bIm[k] = bIm[m - k] = -chirpIm[k];
  }
  radix2(aRe, aIm);
  radix2(bRe, bIm);
  for (let k = 0; k < m; k++) {
    const r = aRe[k] * bRe[k] - aIm[k] * bIm[k];
    const i = aRe[k] * bIm[k] + aIm[k] * bRe[k];
    aRe[k] = r;
    aIm[k] = -i;
  }
  radix2(aRe, aIm);
  for (let k = 0; k < n; k++) {
    const r = aRe[k] / m;
    const i = -aIm[k] / m;
    re[k] = r * chirpRe[k] - i * chirpIm[k];
    im[k] = r * chirpIm[k] + i * chirpRe[k];
  }
}
function ngspiceFft(time, inputs, window) {
  const length = time.length;
  const span = time[length - 1] - time[0] + time[length - 1] - time[length - 2];
  const fpts = Math.trunc(length / 2) + 1;
  const scale2 = length / 2;
  const frequency = Float64Array.from({ length: fpts }, (_, i) => i * 1 / span);
  const vectors = inputs.map((input) => {
    const out = realDft(Array.from({ length }, (_, j) => input[j] * window[j]));
    const re = new Float64Array(fpts);
    const im = new Float64Array(fpts);
    re[0] = out.re[0] / scale2 / 2;
    for (let j = 1; j < fpts; j++) {
      re[j] = out.re[j] / scale2;
      im[j] = out.im[j] / scale2;
    }
    if (length % 2 === 0) {
      re[fpts - 1] = out.re[fpts - 1] / scale2 / 2;
      im[fpts - 1] = 0;
    }
    return { re, im };
  });
  return { frequency, vectors };
}
function ngspicePsd(time, inputs, window, smooth) {
  const length = time.length;
  const span = time[length - 1] - time[0];
  const fpts = Math.trunc(length / 2) + 1;
  const frequency = Float64Array.from({ length: fpts }, (_, i) => i * 1 / span);
  const totalPower = [];
  const vectors = inputs.map((input) => {
    const out = realDft(Array.from({ length }, (_, j) => input[j] * window[j]));
    const intres = length * length;
    const power2 = new Float64Array(fpts);
    power2[0] = out.re[0] * out.re[0] / intres;
    let noipower = power2[0];
    for (let j = 1; j < fpts; j++) {
      power2[j] = 2 * (out.re[j] * out.re[j] + out.im[j] * out.im[j]) / intres;
      noipower += power2[j];
      if (!Number.isFinite(noipower)) break;
    }
    if (length % 2 === 0) power2[fpts - 1] = out.re[fpts - 1] * out.re[fpts - 1] / intres;
    noipower += power2[fpts - 1];
    totalPower.push(noipower);
    const reald = new Float64Array(fpts);
    const hsmooth = smooth >> 1;
    for (let j = 0; j < hsmooth; j++) {
      let sum = 0;
      for (let jj = 0; jj < hsmooth + j; jj++) sum += power2[jj];
      reald[j] = sum / (hsmooth + j);
    }
    for (let j = hsmooth; j < fpts - hsmooth; j++) {
      let sum = 0;
      for (let jj = 0; jj < smooth; jj++) sum += power2[j - hsmooth + jj];
      reald[j] = sum / smooth;
    }
    for (let j = fpts - hsmooth; j < fpts; j++) {
      let sum = 0;
      for (let jj = 0; jj < fpts + hsmooth - j - 1; jj++) sum += power2[j - hsmooth + jj + 1];
      reald[j] = sum / (fpts + hsmooth - j - 1);
    }
    const re = Float64Array.from(reald, (value) => value * fpts / frequency[fpts - 1]);
    return { re, im: new Float64Array(fpts) };
  });
  return { frequency, vectors, totalPower };
}
var EDGE_FACTOR = 1e-3;
function ngspiceLinearInterpolate(data, oscale, nscale) {
  const olen = oscale.length;
  const nlen = nscale.length;
  if (olen < 2 || nlen < 2) return void 0;
  const ndata = new Float64Array(nlen);
  let sign2 = 1;
  for (let i2 = 0; i2 < olen - 1; i2++) {
    if (oscale[i2 + 1] < oscale[i2]) {
      sign2 = -1;
      break;
    } else if (oscale[i2 + 1] > oscale[i2]) {
      sign2 = 1;
      break;
    }
  }
  const xdata = [0, 0];
  const ydata = [0, 0];
  let l = 0;
  let i = 0;
  if (sign2 > 0) {
    while (l < olen - 1 && oscale[l + 1] < nscale[0]) l++;
  } else {
    while (l < olen - 1 && oscale[l + 1] > nscale[0]) l++;
  }
  ydata[0] = data[l];
  xdata[0] = oscale[l];
  do {
    if (oscale[l + 1] === oscale[l]) {
      ydata[0] = data[++l];
    }
    xdata[++i] = oscale[++l];
    ydata[i] = data[l];
  } while (i < 1 && l < olen - 1);
  let c0 = 0;
  let c1 = 0;
  const fit = () => {
    c0 = (xdata[1] * ydata[0] - xdata[0] * ydata[1]) / (xdata[1] - xdata[0]);
    c1 = (ydata[1] - ydata[0]) / (xdata[1] - xdata[0]);
  };
  const putinterval = (last, oval) => {
    let end = last + 1;
    for (; end < nlen; end++) if (nscale[end] * sign2 > oval * sign2) break;
    end--;
    for (let k = last + 1; k <= end; k++) {
      let y = c1;
      y *= nscale[k];
      y += c0;
      ndata[k] = y;
    }
    return end;
  };
  fit();
  let lastone = putinterval(-1, xdata[1]);
  for (++l; l < olen && lastone < nlen - 1; l++) {
    const out = xdata[0];
    xdata[0] = xdata[1];
    ydata[0] = ydata[1];
    ydata[1] = data[l];
    xdata[1] = oscale[l];
    if (oscale[l] === xdata[0]) {
      const diff = xdata[0] - out;
      xdata[0] -= sign2 * diff * EDGE_FACTOR;
    }
    if (l < olen - 1) {
      if (sign2 > 0 && xdata[1] < nscale[lastone + 1]) continue;
      if (sign2 < 0 && xdata[1] > nscale[lastone + 1]) continue;
    }
    fit();
    lastone = putinterval(lastone, xdata[1]);
  }
  lastone = putinterval(lastone, oscale[olen - 1]);
  if (lastone < nlen - 1) ndata[nlen - 1] = data[olen - 1];
  return ndata;
}

// src/parser/control/interpreter.ts
var EDIT_DISABLED_WARNING = "`edit' is disabled because 'interactive' has not been set";
var QuitSignal = class {
  constructor(status, line) {
    this.status = status;
    this.line = line;
  }
  status;
  line;
};
var MAX_LOOP_ITERATIONS = 1e6;
var OPTION_VARIABLES = /* @__PURE__ */ new Set([
  "temp",
  "tnom",
  "gmin",
  "reltol",
  "abstol",
  "vntol",
  "trtol",
  "chgtol",
  "pivtol",
  "pivrel",
  "itl1",
  "itl2",
  "itl3",
  "itl4",
  "itl5",
  "itl6",
  "srcsteps",
  "gminsteps",
  "gminfactor",
  "method",
  "maxord",
  "noinit",
  "noopiter",
  "keepopinfo",
  "rshunt",
  "cshunt",
  "xmu",
  "bypass",
  "defl",
  "defw",
  "defad",
  "defas",
  "ramptime",
  "seed"
]);
var RESULT_AFFECTING_VARIABLES = {
  sqrnoise: "noise spectra in V^2/Hz are not produced",
  ngbehavior: "compatibility modes change netlist interpretation",
  nobjthack: "the BJT three-terminal hack is not implemented",
  notrnoise: "transient noise switching is not implemented",
  rndseed: "random-number seeding is not implemented",
  xtrtol: "XSPICE truncation tolerance is not implemented",
  nosubckt: "disabling subcircuit expansion is not implemented",
  dpolydegree: "polynomial interpolation settings are not implemented",
  polydegree: "polynomial interpolation settings are not implemented",
  polysteps: "polynomial interpolation settings are not implemented",
  interp: "raw-file interpolation is not implemented",
  strict_errorhandling: "ngspice error-handling modes are not implemented"
};
function constantPlot() {
  const values = [
    ["pi", Math.PI],
    ["e", Math.E],
    ["c", 299792458],
    ["kelvin", -273.15],
    ["echarge", 160219e-24],
    ["boltz", 138062e-28],
    ["planck", 662607e-39],
    ["yes", 1],
    ["no", 0],
    ["true", 1],
    ["false", 0]
  ];
  const vectors = new Map(values.map(([name, value]) => [name, scalar(value, name)]));
  vectors.set("i", complexVector("i", [0], [1]));
  return { name: "const", title: "Constant values", vectors, unproducedSaves: /* @__PURE__ */ new Set() };
}
function runControlScript(script, host) {
  return new ControlInterpreter(host).run(script);
}
var ControlInterpreter = class {
  constructor(host) {
    this.host = host;
  }
  host;
  plots = [constantPlot()];
  current = this.plots[0];
  plotNumber = 1;
  variables = /* @__PURE__ */ new Map([["batchmode", true]]);
  functions = /* @__PURE__ */ new Map();
  savedDeviceVectors = /* @__PURE__ */ new Set();
  runs = [];
  output = [];
  measurements = [];
  warnings = [];
  /** inpcom.c `replaceno`: numbers the `vexprint<n>` vectors of `meas` operands. */
  measureExpressionCount = 1;
  /**
   * The `.tran` job of the circuit's current task (ngspice `ci_curTask`), read
   * by `linearize` (spiceif.c if_tranparams): the last `tran` command, or the
   * deck's `.tran` card after `run`; undefined after any other analysis.
   */
  transientTask;
  run(script) {
    for (const [name, value] of Object.entries(script.constants ?? {})) {
      this.plots[0].vectors.set(name, scalar(value, name));
    }
    try {
      this.block(script.statements);
    } catch (signal) {
      if (!(signal instanceof QuitSignal)) throw signal;
      if (signal.status !== 0) throw new ControlScriptExitError(signal.status, signal.line.lineNumber, this.output);
      return { runs: this.runs, output: this.output, quit: true, measurements: this.measurements, warnings: this.warnings };
    }
    return { runs: this.runs, output: this.output, quit: false, measurements: this.measurements, warnings: this.warnings };
  }
  // -------------------------------------------------------------------------
  // Statements
  block(statements) {
    for (const statement of statements) {
      const flow = this.statement(statement);
      if (flow !== "next") return flow;
    }
    return "next";
  }
  statement(statement) {
    switch (statement.kind) {
      case "command":
        this.command(statement.name, statement.line);
        return "next";
      case "break":
      case "continue":
        return statement.kind;
      case "if":
        return this.block(this.condition(statement.condition, statement.line) ? statement.then : statement.otherwise);
      case "while":
      case "dowhile": {
        let iterations = 0;
        let first = statement.kind === "dowhile";
        while (first || this.condition(statement.condition, statement.line)) {
          first = false;
          this.countIteration(++iterations, statement.line);
          if (this.block(statement.body) === "break") break;
        }
        return "next";
      }
      case "repeat": {
        const text = this.substitute(statement.count, statement.line).trim();
        if (text === "") {
          throw new UnsupportedControlCommandError(
            "repeat",
            "an unbounded repeat loop is not executed",
            statement.line.lineNumber,
            statement.line.text
          );
        }
        const count2 = this.evaluate(text, statement.line).re[0];
        for (let iteration = 0; iteration < count2; iteration++) {
          this.countIteration(iteration + 1, statement.line);
          if (this.block(statement.body) === "break") break;
        }
        return "next";
      }
      case "foreach": {
        const values = splitWords(this.substitute(statement.values, statement.line)).map(unquote);
        for (const value of values) {
          this.variables.set(statement.variable.toLowerCase(), value);
          if (this.block(statement.body) === "break") break;
        }
        return "next";
      }
    }
  }
  countIteration(iteration, line) {
    if (iteration > MAX_LOOP_ITERATIONS) {
      throw new ControlScriptError(`loop exceeded ${MAX_LOOP_ITERATIONS} iterations`, line.lineNumber, line.text);
    }
  }
  condition(text, line) {
    const substituted = this.substitute(text, line).trim();
    if (substituted === "") throw new ControlScriptError("missing condition", line.lineNumber, line.text);
    return isTrue(this.evaluate(substituted, line));
  }
  command(name, line) {
    const text = this.substitute(line.text, line);
    const rest = text.slice(/^\s*[^\s=(]*/.exec(text)[0].length).trim();
    switch (name) {
      case "op":
      case "dc":
      case "ac":
      case "tran":
      case "noise":
      case "sp":
      case "sens": {
        const tokens = tokenizeNetlist(text)[0]?.tokens ?? [];
        const run = this.host.runAnalysis([`.${name.toUpperCase()}`, ...tokens.slice(1)], line);
        this.recordRun(run);
        this.transientTask = run.directive.type === "tran" ? run.directive : void 0;
        return;
      }
      case "run":
        if (rest !== "") {
          throw new UnsupportedControlCommandError("run", "writing a raw file from run is not supported", line.lineNumber, line.text);
        }
        {
          const runs = this.host.runDeck(line);
          for (const run of runs) this.recordRun(run);
          this.transientTask = runs.map((run) => run.directive).find(
            (directive) => directive.type === "tran"
          );
        }
        return;
      case "let":
        return this.let(rest, line);
      case "unlet":
        for (const word of splitWords(rest)) this.current.vectors.delete(word.toLowerCase());
        return;
      case "set":
        return this.set(rest, line);
      case "unset":
        for (const word of splitWords(rest)) this.variables.delete(word.toLowerCase());
        return;
      case "define":
        return this.define(rest, line);
      case "undefine":
        for (const word of splitWords(rest)) {
          for (const key of [...this.functions.keys()]) if (key.startsWith(`${word.toLowerCase()}/`)) this.functions.delete(key);
        }
        return;
      case "alter":
        return this.alter(rest, line);
      case "altermod":
        return this.altermod(rest, line);
      case "option":
      case "options":
        if (rest !== "") this.host.setOptions(splitWords(rest).map(unquote), line);
        return;
      case "setplot":
        return this.setplot(rest);
      case "destroy":
        return this.destroy(rest);
      case "compose":
        return this.compose(rest, line);
      case "strcmp":
        return this.strcmp(rest, line);
      case "meas":
        return this.meas(rest, line);
      case "linearize":
        return this.linearize(rest, line);
      case "fft":
        return this.spectrum("fft", rest, line);
      case "psd":
        return this.spectrum("psd", rest, line);
      case "setscale": {
        if (rest === "") return;
        this.current.scale = this.vector(rest, line);
        return;
      }
      case "echo":
        this.output.push(withoutRedirection(splitWords(rest)).map(unquote).join(" "));
        return;
      case "edit":
        if (this.variables.has("interactive")) {
          throw new UnsupportedControlCommandError(
            "edit",
            "the interactive netlist editor is not available",
            line.lineNumber,
            line.text
          );
        }
        this.warnings.push(EDIT_DISABLED_WARNING);
        return;
      case "save":
        for (const word of splitWords(rest)) if (word.startsWith("@")) this.savedDeviceVectors.add(word.toLowerCase());
        return;
      case "quit":
      case "exit": {
        const status = rest === "" ? 0 : parseControlNumber(rest);
        if (status === void 0) throw new ControlScriptError(`invalid exit status '${rest}'`, line.lineNumber, line.text);
        throw new QuitSignal(status, line);
      }
      default:
        return;
    }
  }
  // -------------------------------------------------------------------------
  // Commands
  let(rest, line) {
    const equals = assignmentIndex(rest);
    if (equals < 0) {
      throw new UnsupportedControlCommandError("let", "let without an assignment (vector listing) is not supported", line.lineNumber, line.text);
    }
    const target = rest.slice(0, equals).trim();
    const expression = rest.slice(equals + 1).trim();
    rejectRedirection("let", expression, line);
    const value = this.evaluate(expression, line);
    const element2 = /^([^\s[\]]+)\s*\[(.+)\]$/.exec(target);
    if (element2) {
      const name = element2[1].toLowerCase();
      const plot = this.assignmentPlot(name);
      const existing = plot.vectors.get(name);
      if (!existing) throw new ControlScriptError(`no such vector '${element2[1]}' to index`, line.lineNumber, line.text);
      const index = Math.trunc(this.evaluate(element2[2], line).re[0]);
      if (!(index >= 0 && index < existing.re.length)) {
        throw new ControlScriptError(`index ${index} out of range for vector '${element2[1]}'`, line.lineNumber, line.text);
      }
      const updated = renamed(existing, name);
      updated.re[index] = value.re[0];
      if (value.im || updated.im) {
        updated.im ??= new Float64Array(updated.re.length);
        updated.im[index] = value.im ? value.im[0] : 0;
      }
      plot.vectors.set(name, updated);
      return;
    }
    if (!/^[A-Za-z_][\w#.@:-]*$/.test(target)) {
      throw new ControlScriptError(`invalid vector name '${target}'`, line.lineNumber, line.text);
    }
    this.assignmentPlot(target.toLowerCase()).vectors.set(target.toLowerCase(), renamed(value, target));
  }
  /**
   * Plot a `let` writes to: the plot where the name already resolves (current
   * plot, then `const`), else the current plot. ngspice updates a `const`
   * vector in place even while an analysis plot is current.
   */
  assignmentPlot(name) {
    if (this.current.vectors.has(name)) return this.current;
    if (this.plots[0].vectors.has(name)) return this.plots[0];
    return this.current;
  }
  set(rest, line) {
    const normalized = rest.replace(/\s*=\s*/g, "=");
    for (const word of splitWords(normalized)) {
      const separator = word.indexOf("=");
      const name = (separator < 0 ? word : word.slice(0, separator)).toLowerCase();
      const rawValue = separator < 0 ? void 0 : word.slice(separator + 1);
      if (name === "") throw new ControlScriptError(`invalid set argument '${word}'`, line.lineNumber, line.text);
      const reason = RESULT_AFFECTING_VARIABLES[name];
      if (reason !== void 0) {
        throw new UnsupportedControlCommandError("set", `variable '${name}': ${reason}`, line.lineNumber, line.text);
      }
      if (OPTION_VARIABLES.has(name)) {
        this.host.setOptions([rawValue === void 0 ? name : `${name}=${unquote(rawValue)}`], line);
        continue;
      }
      if (name === "curplot") {
        const target = rawValue === void 0 ? "" : unquote(rawValue);
        this.setplot(target);
        continue;
      }
      if (name === "curplottitle") {
        this.current.title = rawValue === void 0 ? "" : unquote(rawValue);
        continue;
      }
      if (rawValue === void 0) {
        this.variables.set(name, true);
      } else if (rawValue.startsWith("(") && rawValue.endsWith(")")) {
        this.variables.set(name, splitWords(rawValue.slice(1, -1)).map(unquote));
      } else {
        this.variables.set(name, unquote(rawValue));
      }
    }
  }
  define(rest, line) {
    const match = /^([A-Za-z_]\w*)\s*\(([^)]*)\)\s*(.+)$/.exec(rest);
    if (!match) {
      throw new UnsupportedControlCommandError("define", "only define name(args) expression is supported", line.lineNumber, line.text);
    }
    rejectRedirection("define", match[3], line);
    const params = match[2].split(",").map((param) => param.trim()).filter(Boolean);
    this.functions.set(`${match[1].toLowerCase()}/${params.length}`, { params, body: this.parse(match[3], line) });
  }
  alter(rest, line) {
    const { target, parameter, valueText } = this.splitAlter("alter", rest, line);
    this.host.alterInstance(target, parameter, this.alterValues(valueText, line), line);
  }
  altermod(rest, line) {
    const { target, parameter, valueText } = this.splitAlter("altermod", rest, line);
    if (parameter === void 0) {
      throw new UnsupportedControlCommandError("altermod", "altermod needs a model parameter (altermod model param = value)", line.lineNumber, line.text);
    }
    const values = this.alterValues(valueText, line);
    if (values.length !== 1) {
      throw new ControlScriptError("altermod needs a single value", line.lineNumber, line.text);
    }
    this.host.alterModel(target, parameter, values[0], line);
  }
  splitAlter(command, rest, line) {
    const bracket = /^@([^\s[]+)\[([^\]]+)\]\s*=?\s*(.+)$/.exec(rest);
    if (bracket) return { target: bracket[1], parameter: bracket[2], valueText: bracket[3] };
    const equals = rest.indexOf("=");
    if (equals >= 0) {
      const left = rest.slice(0, equals).trim().split(/\s+/);
      const valueText = rest.slice(equals + 1).trim();
      if (left.length === 1 && left[0] !== "") return { target: left[0], valueText };
      if (left.length === 2) return { target: left[0], parameter: left[1], valueText };
    } else {
      const words = rest.split(/\s+/);
      if (words.length === 2) return { target: words[0], valueText: words[1] };
      if (words.length === 3) return { target: words[0], parameter: words[1], valueText: words[2] };
    }
    throw new UnsupportedControlCommandError(command, `unsupported ${command} form`, line.lineNumber, line.text);
  }
  alterValues(valueText, line) {
    const trimmed = valueText.trim();
    if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
      return splitWords(trimmed.slice(1, -1)).map((word) => {
        const value = parseControlNumber(word);
        if (value === void 0) throw new ControlScriptError(`invalid number '${word}' in value list`, line.lineNumber, line.text);
        return value;
      });
    }
    const vector = this.evaluate(trimmed, line);
    if (vector.im && vector.im.some((value) => value !== 0)) {
      throw new ControlScriptError("alter needs a real value", line.lineNumber, line.text);
    }
    return Array.from(vector.re);
  }
  /**
   * ngspice-47 plot_setcur (frontend/vectors.c). `this.plots` is in creation
   * order, the reverse of ngspice's plot_list, so `previous` (pl_next, older)
   * is one index down and `next` (newer) one index up. A failed selection
   * prints ngspice's message, keeps the current plot and the script goes on.
   */
  setplot(rest) {
    const name = rest.trim().toLowerCase();
    if (name === "") return;
    if (name === "new") {
      this.current = this.newPlot("unknown", "anonymous", void 0);
      return;
    }
    if (name === "previous" || name === "next") {
      const index = this.plots.indexOf(this.current) + (name === "previous" ? -1 : 1);
      const plot2 = this.plots[index];
      if (index >= 0 && plot2) this.current = plot2;
      else this.warnings.push(`No ${name} plot is available. Plot remains unchanged (${this.current.name})`);
      return;
    }
    const plot = [...this.plots].reverse().find((candidate) => plotPrefix(name, candidate.name));
    if (!plot) {
      this.warnings.push(`no such plot named ${rest.trim()}`);
      return;
    }
    this.current = plot;
  }
  /** ngspice-47 com_destroy (frontend/postcoms.c): a missing plot is reported, the rest destroyed. */
  destroy(rest) {
    const names = splitWords(rest).map((word) => word.toLowerCase());
    const doomed = [];
    if (names.length === 0) doomed.push(this.current);
    else if (names[0] === "all") doomed.push(...this.plots.filter((plot) => plot.name !== "const"));
    else {
      for (const name of names) {
        const plot = this.plots.find((candidate) => candidate.name === name && !doomed.includes(candidate));
        if (plot) doomed.push(plot);
        else this.warnings.push(`no such plot ${name}`);
      }
    }
    for (const plot of doomed) {
      if (plot.name === "const") continue;
      this.plots.splice(this.plots.indexOf(plot), 1);
    }
    if (!this.plots.includes(this.current)) this.current = this.plots.at(-1);
  }
  compose(rest, line) {
    const [target, ...words] = splitWords(rest.replace(/\s*=\s*/g, "="));
    if (!target) throw new ControlScriptError("compose needs a vector name", line.lineNumber, line.text);
    if (words[0]?.toLowerCase() === "values") {
      const values2 = words.slice(1).map((word) => this.evaluate(word, line));
      const complex = values2.some((value) => value.im !== void 0);
      const re = values2.map((value) => value.re[0]);
      const vector = complex ? complexVector(target, re, values2.map((value) => value.im ? value.im[0] : 0)) : realVector(target, re);
      this.current.vectors.set(target.toLowerCase(), vector);
      return;
    }
    const params = /* @__PURE__ */ new Map();
    for (const word of words) {
      const [key, value] = word.split("=");
      if (value === void 0 || !["start", "stop", "step", "lin", "len"].includes(key.toLowerCase())) {
        throw new UnsupportedControlCommandError("compose", `compose parameter '${word}' is not supported`, line.lineNumber, line.text);
      }
      params.set(key.toLowerCase() === "len" ? "lin" : key.toLowerCase(), this.evaluate(value, line).re[0]);
    }
    const start = params.get("start");
    const stop = params.get("stop");
    const step = params.get("step");
    const count2 = params.get("lin");
    let values;
    if (start !== void 0 && step !== void 0 && count2 !== void 0 && stop === void 0) {
      values = Array.from({ length: Math.trunc(count2) }, (_, index) => start + index * step);
    } else if (start !== void 0 && stop !== void 0 && count2 !== void 0 && step === void 0) {
      const points = Math.trunc(count2);
      values = Array.from({ length: points }, (_, index) => points === 1 ? start : start + index * (stop - start) / (points - 1));
    } else if (start !== void 0 && stop !== void 0 && step !== void 0 && count2 === void 0) {
      if (step === 0) throw new ControlScriptError("compose step must be non-zero", line.lineNumber, line.text);
      const points = Math.trunc(Math.abs((stop - start) / step) + 1.5);
      values = Array.from({ length: points }, (_, index) => start + index * step);
    } else {
      throw new UnsupportedControlCommandError("compose", "this compose parameter combination is not supported", line.lineNumber, line.text);
    }
    this.current.vectors.set(target.toLowerCase(), realVector(target, values));
  }
  strcmp(rest, line) {
    const words = splitWords(rest).map(unquote);
    if (words.length !== 3) throw new ControlScriptError("strcmp needs a variable and two strings", line.lineNumber, line.text);
    const [name, left, right] = words;
    this.variables.set(name.toLowerCase(), String(left < right ? -1 : left > right ? 1 : 0));
  }
  /**
   * `meas`: ngspice-47 com_meas() (frontend/measure.c) after inpcom.c's
   * inp_meas_control() rewrite, which moves every `=` operand with an
   * arithmetic character into a temporary vector (`let vexprint<n> = operand`
   * before the command, `unlet` after). A failed measurement is recorded, not
   * thrown: ngspice prints it and runs on.
   */
  meas(rest, line) {
    let text = rest.replace(/\s*=\s*/g, "=").toLowerCase();
    const temporaries = [];
    let search = 0;
    for (let equals = findAssignment(text, search); equals >= 0; equals = findAssignment(text, search)) {
      const { token, end } = gettokAt(text, equals + 1);
      if (!/[+\-*/()<>?:|&^!%\\]/.test(token)) {
        search = end;
        continue;
      }
      search = equals + 1;
      const name = `vexprint${this.measureExpressionCount++}`;
      try {
        const plot = this.assignmentPlot(name);
        plot.vectors.set(name, renamed(this.evaluate(token, line), name));
        temporaries.push({ plot, name });
      } catch (error) {
        if (!(error instanceof ControlScriptError)) throw error;
      }
      text = `${text.slice(0, equals)}=${name} ${text.slice(end)}`;
    }
    try {
      const result = this.measure(text.trim().split(/\s+/).filter(Boolean), line);
      if (result) this.measurements.push(result);
    } finally {
      for (const { plot, name } of temporaries) plot.vectors.delete(name);
    }
  }
  /** com_meas body: replace `=<single-valued vector>` by its value, measure, `let` the result. */
  measure(words, line) {
    if (words.length === 0) return void 0;
    const failed = (error) => ({
      name: (words[1] ?? "").toLowerCase(),
      analysis: words[0].toLowerCase(),
      function: (words[2] ?? "").toLowerCase(),
      line: line.lineNumber,
      status: "failed",
      error
    });
    const value = (operand) => {
      if (operand.toLowerCase() === "last" || inpEvaluate(operand) !== void 0) return void 0;
      const vector = this.measureVector(operand);
      return vector && vector.re.length === 1 ? formatC(vector.re[0]) : void 0;
    };
    for (let index = 0; index < words.length; index++) {
      const word = words[index];
      if (word.endsWith("=")) {
        if (++index >= words.length) return failed(`meas failed due to missing token in meas ${words.join(" ")}`);
        words[index] = value(words[index]) ?? words[index];
      } else if (word.includes("=")) {
        const lhs = word.slice(0, word.indexOf("="));
        const replaced = value(word.slice(word.indexOf("=") + 1));
        if (replaced !== void 0) words[index] = `${lhs}=${replaced}`;
      }
    }
    if (words.length < 2) return failed("unspecified output var name");
    const outcome = getMeasure2(words, this.measurePlot());
    if (!outcome.ok) return failed(outcome.error);
    const name = words[1].toLowerCase();
    const { ok: _ok, value: measured, ...details } = outcome;
    this.assignmentPlot(name).vectors.set(name, scalar(Number(formatC(measured)), name));
    return {
      name,
      analysis: words[0].toLowerCase(),
      function: words[2].toLowerCase(),
      line: line.lineNumber,
      status: "ok",
      value: measured,
      ...details
    };
  }
  /** The current plot as `get_measure2` reads it. */
  measurePlot() {
    return { type: this.current.name, scale: this.current.scale, vector: (name) => this.measureVector(name) };
  }
  /** ngspice vec_get for a measurement: the name, `v(node)` as `node`, `i(dev)` as `dev#branch`. */
  measureVector(rawName) {
    const name = rawName.toLowerCase();
    const candidates = [name];
    const voltage = /^v\((.+)\)$/.exec(name);
    if (voltage) candidates.push(voltage[1]);
    const current = /^i\((.+)\)$/.exec(name);
    if (current) candidates.push(`${current[1]}#branch`);
    for (const candidate of candidates) {
      try {
        return this.lookup(candidate);
      } catch (error) {
        if (!(error instanceof ExpressionError || error instanceof UnsupportedExpressionFeature)) throw error;
      }
    }
    return void 0;
  }
  /**
   * `linearize [np=n] [vec ...]`: ngspice-47 com_linearize (frontend/linear.c).
   * Re-interpolates the current transient plot onto `tstart, tstart+tstep, ...`
   * (`(tstop-tstart)/tstep + 1.5` points, accumulated by repeated addition)
   * with the current task's `.tran` parameters, or the scale's range and
   * `range/length` when there is none, overridden by `lin-tstart`, `lin-tstop`
   * and `lin-tstep` vectors of the plot. The new plot `tran<n>` becomes
   * current. Complex, scalar and short vectors are not copied (lincopy).
   */
  linearize(rest, line) {
    const fail = (message) => {
      throw new ControlScriptError(`linearize: ${message}`, line.lineNumber, line.text);
    };
    const old = this.current;
    if (!old.name.startsWith("tran")) fail("plot must be a transient analysis");
    const oldTime = old.scale;
    if (!oldTime || old.vectors.size === 0) fail("no vectors available");
    if (oldTime.im) fail(`non-real time scale for ${old.name}`);
    let tstart;
    let tstop;
    let tstep;
    if (this.transientTask) {
      tstart = this.transientTask.startTime ?? 0;
      tstop = this.transientTask.stopTime;
      tstep = this.transientTask.timestep;
    } else {
      const length2 = oldTime.re.length;
      if (length2 < 1) fail("no data in vector");
      tstart = oldTime.re[0];
      tstop = oldTime.re[length2 - 1];
      tstep = (tstop - tstart) / length2;
    }
    tstart = old.vectors.get("lin-tstart")?.re[0] ?? tstart;
    tstop = old.vectors.get("lin-tstop")?.re[0] ?? tstop;
    tstep = old.vectors.get("lin-tstep")?.re[0] ?? tstep;
    if ((tstop - tstart) * tstep <= 0 || tstop - tstart < tstep) {
      fail(`bad parameters -- start = ${tstart}, stop = ${tstop}, step = ${tstep}`);
    }
    const words = splitWords(rest);
    const npWord = words.find((word) => word.toLowerCase().startsWith("np="));
    let length;
    if (npWord !== void 0) {
      const text = npWord.slice(3);
      length = Math.trunc(Number(/^\s*[+-]?\d+/.exec(text)?.[0] ?? 0));
      if (length === 0 && text.toLowerCase().startsWith("auto2n")) {
        length = 2 ** roundHalfAway(Math.log2((tstop - tstart) / tstep));
      }
    } else {
      length = Math.trunc((tstop - tstart) / tstep + 1.5);
    }
    if (!(length >= 2)) fail(`cannot interpolate onto ${length} points`);
    const grid = new Float64Array(length);
    for (let index = 0, time2 = tstart; index < length; index++, time2 += tstep) grid[index] = time2;
    const time = realVector(oldTime.name, grid);
    const plot = this.newPlot("tran", `${old.title} (linearized)`, time, old.unproducedSaves);
    this.current = plot;
    const names = words.filter((word) => !word.toLowerCase().startsWith("np="));
    const sources = names.length > 0 ? names.map((name) => {
      const found = this.plotVector(old, name);
      if (!found) fail(`no such vector ${name}`);
      return found;
    }) : [...old.vectors].filter(([, vector]) => vector !== oldTime);
    for (const [key, vector] of sources) {
      if (vector.im || vector.re.length === 1 || vector.re.length < oldTime.re.length) continue;
      const values = ngspiceLinearInterpolate(vector.re.subarray(0, oldTime.re.length), oldTime.re, grid);
      if (!values) fail(`can't interpolate ${vector.name}`);
      plot.vectors.set(key, { name: vector.name, re: values, scale: time });
    }
    const transient = this.runs.filter((run) => run.plot === old.name).at(-1)?.result.transient;
    const copy = (names2, branch) => {
      const vectors = /* @__PURE__ */ new Map();
      for (const name of names2) {
        const vector = plot.vectors.get(`${name.toLowerCase()}${branch ? "#branch" : ""}`);
        if (vector) vectors.set(name, Array.from(vector.re));
      }
      return vectors;
    };
    this.runs.push({
      plot: plot.name,
      analysis: "tran",
      result: {
        transient: new TransientResult(
          Array.from(grid),
          copy(transient?.voltages.keys() ?? [], false),
          copy(transient?.currents.keys() ?? [], true)
        ),
        warnings: []
      }
    });
  }
  /**
   * `fft vec ...` (com_fft) and `psd npts vec ...` (com_psd), ngspice-47 with
   * FFTW: a new `sp<n>` plot with a `frequency` scale and one complex vector
   * per input, under the input's name. The window is `specwindow` (default
   * `hanning`) of order `specwindoworder` (default and minimum 2).
   */
  spectrum(command, rest, line) {
    const fail = (message) => {
      throw new ControlScriptError(`${command}: ${message}`, line.lineNumber, line.text);
    };
    const source = this.current;
    const scale2 = source.scale;
    if (!scale2) fail("no vectors loaded");
    if (scale2.im || scale2.name !== "time") fail("fft needs real time scale");
    const time = scale2.re;
    const length = time.length;
    if (length < 2) fail("fft needs more than one time point, check the tran simulation!");
    let words = splitWords(rest);
    let smooth = 1;
    if (command === "psd") {
      if (words.length === 0) fail("missing number of averaged data points");
      const value = parseControlNumber(words[0]);
      smooth = value === void 0 || !(value >= 1) ? 1 : Math.trunc(value);
      words = words.slice(1);
    }
    const windowSetting = this.variables.get("specwindow");
    const window = typeof windowSetting === "string" ? windowSetting : "hanning";
    const orderSetting = Number(this.variables.get("specwindoworder"));
    const order = Number.isFinite(orderSetting) ? Math.max(2, Math.trunc(orderSetting)) : 2;
    const maxt = time[length - 1];
    const span = command === "fft" ? time[length - 1] - time[0] + time[length - 1] - time[length - 2] : time[length - 1] - time[0];
    const weights = spectrumWindow(window, time, maxt, span, order);
    if (!weights) fail(`unknown window type ${window}`);
    const inputs = [];
    for (const word of words) {
      const vector = this.evaluate(word, line);
      if (vector.re.length !== length) {
        fail(`lengths of ${word} vectors don't match: ${vector.re.length}, ${length}`);
      }
      if (vector.im) fail(`${word} isn't real!`);
      if (vector === scale2) continue;
      const key = [...source.vectors].find(([, candidate]) => candidate === vector)?.[0] ?? word.toLowerCase();
      inputs.push({ name: key, values: vector.re });
    }
    if (inputs.length === 0) fail("no vectors to transform");
    const values = inputs.map((input) => input.values);
    const result = command === "fft" ? ngspiceFft(time, values, weights) : ngspicePsd(time, values, weights, smooth);
    const frequency = realVector("frequency", result.frequency);
    const plot = this.newPlot("sp", command === "fft" ? "Spectrum" : "PSD", frequency, source.unproducedSaves);
    inputs.forEach((input, index) => {
      const { re, im } = result.vectors[index];
      plot.vectors.set(input.name, complexVector(input.name, re, im, frequency));
    });
    this.current = plot;
  }
  /** ngspice vec_fromplot: a vector of one plot by name, `v(node)` or `i(device)`, with its key. */
  plotVector(plot, rawName) {
    const name = rawName.toLowerCase();
    const voltage = /^v\((.+)\)$/.exec(name);
    const current = /^i\((.+)\)$/.exec(name);
    for (const candidate of [name, voltage?.[1], current ? `${current[1]}#branch` : void 0]) {
      if (candidate === void 0) continue;
      const vector = plot.vectors.get(candidate);
      if (vector) return [candidate, vector];
    }
    return void 0;
  }
  // -------------------------------------------------------------------------
  // Plots
  newPlot(type, title, scale2, unproducedSaves = /* @__PURE__ */ new Set()) {
    while (this.plots.some((plot2) => plot2.name === `${type}${this.plotNumber}`)) this.plotNumber++;
    const plot = { name: `${type}${this.plotNumber}`, title, vectors: /* @__PURE__ */ new Map(), scale: scale2, unproducedSaves };
    if (scale2) plot.vectors.set(scale2.name, scale2);
    this.plots.push(plot);
    return plot;
  }
  recordRun(run) {
    const saves = new Set(this.savedDeviceVectors);
    const type = run.directive.type;
    const { result } = run;
    if (type === "noise" && result.noise) {
      const noise = result.noise;
      const frequency = realVector("frequency", noise.frequencies);
      const spectrum = this.newPlot("noise", "Noise Spectral Density Curves", frequency, saves);
      spectrum.vectors.set("onoise_spectrum", realVector("onoise_spectrum", noise.outputNoiseDensity, frequency));
      spectrum.vectors.set("inoise_spectrum", realVector("inoise_spectrum", noise.inputNoiseDensity, frequency));
      this.runs.push({ plot: spectrum.name, analysis: type, result });
      const integrated = this.newPlot("noise", "Integrated Noise", void 0, saves);
      if (noise.integratedOutputNoise !== void 0) {
        integrated.vectors.set("onoise_total", scalar(noise.integratedOutputNoise, "onoise_total"));
      }
      if (noise.integratedInputNoise !== void 0) {
        integrated.vectors.set("inoise_total", scalar(noise.integratedInputNoise, "inoise_total"));
      }
      this.current = integrated;
      return;
    }
    const plot = this.plotFor(run, saves);
    this.runs.push({ plot: plot.name, analysis: type, result });
    this.current = plot;
  }
  plotFor(run, saves) {
    const { directive, result } = run;
    switch (directive.type) {
      case "op": {
        const plot = this.newPlot("op", "Operating Point", void 0, saves);
        for (const [node, value] of result.dc?.voltages ?? []) plot.vectors.set(node.toLowerCase(), scalar(value, node));
        for (const [branch, value] of result.dc?.currents ?? []) {
          plot.vectors.set(`${branch.toLowerCase()}#branch`, scalar(value, `${branch}#branch`));
        }
        return plot;
      }
      case "dc": {
        const sweep = result.dcSweep;
        const source = directive.source.toLowerCase();
        const scaleName = source === "temp" ? "temp-sweep" : `${source[0] === "i" ? "i" : source[0] === "r" ? "res" : "v"}-sweep`;
        const scale2 = realVector(scaleName, sweep ? sweep.sweepValues : []);
        const plot = this.newPlot("dc", "DC transfer characteristic", scale2, saves);
        if (sweep) {
          for (const [node, values] of sweep.voltages) plot.vectors.set(node.toLowerCase(), realVector(node, values, scale2));
          for (const [branch, values] of sweep.currents) {
            plot.vectors.set(`${branch.toLowerCase()}#branch`, realVector(`${branch}#branch`, values, scale2));
          }
        }
        return plot;
      }
      case "tran": {
        const transient = result.transient;
        const scale2 = realVector("time", transient ? transient.time : []);
        const plot = this.newPlot("tran", "Transient Analysis", scale2, saves);
        if (transient) {
          for (const [node, values] of transient.voltages) plot.vectors.set(node.toLowerCase(), realVector(node, values, scale2));
          for (const [branch, values] of transient.currents) {
            plot.vectors.set(`${branch.toLowerCase()}#branch`, realVector(`${branch}#branch`, values, scale2));
          }
        }
        return plot;
      }
      case "ac": {
        const ac = result.ac;
        const scale2 = realVector("frequency", ac ? ac.frequencies : []);
        const plot = this.newPlot("ac", "AC Analysis", scale2, saves);
        const phasors = (name, values) => complexVector(
          name,
          values.map((value) => value.magnitude * Math.cos(value.phase * Math.PI / 180)),
          values.map((value) => value.magnitude * Math.sin(value.phase * Math.PI / 180)),
          scale2
        );
        if (ac) {
          for (const [node, values] of ac.voltages) plot.vectors.set(node.toLowerCase(), phasors(node, values));
          for (const [branch, values] of ac.currents) {
            plot.vectors.set(`${branch.toLowerCase()}#branch`, phasors(`${branch}#branch`, values));
          }
        }
        return plot;
      }
      case "sp": {
        const sp = result.sParameters;
        const scale2 = realVector("frequency", sp ? sp.frequencies : []);
        const plot = this.newPlot("sp", "SP Analysis", scale2, saves);
        for (const [name, values] of sp?.vectors ?? []) {
          plot.vectors.set(name.toLowerCase(), complexVector(
            name,
            values.map((value) => value.real),
            values.map((value) => value.imaginary),
            scale2
          ));
        }
        return plot;
      }
      case "sens": {
        const sens = result.sensitivity;
        const ac = directive.mode === "ac";
        const scale2 = ac ? realVector("frequency", sens ? sens.frequencies : []) : void 0;
        const plot = this.newPlot("sens", "Sensitivity Analysis", scale2, saves);
        for (const entry of sens?.entries ?? []) {
          const vector = entry.dc !== void 0 ? scalar(entry.dc, entry.device) : complexVector(
            entry.device,
            (entry.ac ?? []).map((value) => value.real),
            (entry.ac ?? []).map((value) => value.imaginary),
            scale2
          );
          for (const { name, firstPointOnly } of sensitivityVectorNames(entry.device, entry.parameter, ac)) {
            plot.vectors.set(name, firstPointOnly ? complexVector(
              name,
              (entry.ac ?? []).map((value, index) => index === 0 ? value.real : -0),
              (entry.ac ?? []).map((value, index) => index === 0 ? value.imaginary : -0),
              scale2
            ) : renamed(vector, name));
          }
        }
        return plot;
      }
      default:
        return this.newPlot(directive.type, directive.type, void 0, saves);
    }
  }
  // -------------------------------------------------------------------------
  // Vectors and expressions
  environment() {
    return {
      lookup: (name) => this.lookup(name),
      userFunction: (name, arity) => this.functions.get(`${name.toLowerCase()}/${arity}`),
      degrees: () => {
        const units = this.variables.get("units");
        return typeof units === "string" && units.toLowerCase().startsWith("degree");
      }
    };
  }
  lookup(rawName) {
    const name = rawName.toLowerCase();
    const dot2 = name.indexOf(".");
    if (dot2 > 0) {
      const plot = this.plots.find((candidate) => candidate.name === name.slice(0, dot2));
      if (plot) return this.lookupIn(plot, name.slice(dot2 + 1), rawName);
    }
    const local = this.current.vectors.get(name);
    if (local) return local;
    const constant = this.plots[0].vectors.get(name);
    if (constant) return constant;
    return this.lookupIn(this.current, name, rawName);
  }
  lookupIn(plot, name, rawName) {
    const vector = plot.vectors.get(name);
    if (vector) return vector;
    if (name.startsWith("@")) {
      if (plot.unproducedSaves.has(name)) {
        throw new UnsupportedExpressionFeature(rawName, `saved device-parameter vector '${rawName}' is not produced by spice-ts analyses`);
      }
      const match = /^@([^[]+)\[([^\]]+)\]$/.exec(name);
      const values = match ? this.host.parameterVector(match[1], match[2]) : void 0;
      if (values === void 0) {
        throw new UnsupportedExpressionFeature(rawName, `device or model parameter '${rawName}' is not available to the spice-ts control language`);
      }
      return realVector(name, values);
    }
    throw new ExpressionError(`no such vector '${rawName}' in plot '${plot.name}'`);
  }
  parse(text, line) {
    try {
      return parseVectorExpression(text);
    } catch (error) {
      throw this.wrap(error, line);
    }
  }
  evaluate(text, line) {
    const tree = this.parse(text, line);
    try {
      return evaluateVectorExpression(tree, this.environment());
    } catch (error) {
      throw this.wrap(error, line);
    }
  }
  vector(name, line) {
    try {
      return this.lookup(name.trim());
    } catch (error) {
      throw this.wrap(error, line);
    }
  }
  wrap(error, line) {
    if (error instanceof UnsupportedExpressionFeature) {
      return new UnsupportedControlCommandError(commandWord(line.text), error.message, line.lineNumber, line.text);
    }
    if (error instanceof ExpressionError) return new ControlScriptError(error.message, line.lineNumber, line.text);
    return error;
  }
  // -------------------------------------------------------------------------
  // Variable substitution
  /**
   * ngspice variable substitution: `$name`, `{$name}`, `$&vector`, `$?name`,
   * `$#name`, and the plot variables `$curplot`, `$curplottitle`, `$plots`.
   * Nothing is substituted inside single quotes.
   */
  substitute(text, line) {
    let output = "";
    let index = 0;
    let singleQuoted = false;
    while (index < text.length) {
      const character = text[index];
      if (character === "'") singleQuoted = !singleQuoted;
      if (singleQuoted) {
        output += character;
        index++;
        continue;
      }
      if (character === "{" && text[index + 1] === "$") {
        const close = text.indexOf("}", index);
        if (close > index) {
          output += this.substituteReference(text.slice(index + 1, close), line);
          index = close + 1;
          continue;
        }
      }
      if (character === "$") {
        const reference = /^\$(?:&[A-Za-z0-9_#@.]+(?:\([^)]*\))?(?:\[[^\]]*\])*|[?#][A-Za-z0-9_]+|[A-Za-z0-9_]+)/.exec(text.slice(index));
        if (reference) {
          output += this.substituteReference(reference[0], line);
          index += reference[0].length;
          continue;
        }
      }
      output += character;
      index++;
    }
    return output;
  }
  substituteReference(reference, line) {
    if (reference.startsWith("$&")) {
      const digits = Number(this.variables.get("numdgt"));
      return formatVector(this.evaluate(reference.slice(2), line), Number.isInteger(digits) && digits > 0 ? digits : 6);
    }
    if (reference.startsWith("$?")) return this.variable(reference.slice(2)) === void 0 ? "0" : "1";
    if (reference.startsWith("$#")) {
      const value2 = this.variable(reference.slice(2));
      return String(value2 === void 0 ? 0 : Array.isArray(value2) ? value2.length : 1);
    }
    const name = reference.slice(1);
    const value = this.variable(name);
    if (value === void 0) throw new ControlScriptError(`'${name}': no such variable`, line.lineNumber, line.text);
    if (value === true) return "";
    return Array.isArray(value) ? value.join(" ") : value;
  }
  variable(rawName) {
    const name = rawName.toLowerCase();
    if (name === "curplot") return this.current.name;
    if (name === "curplottitle") return this.current.title;
    if (name === "curplotname") return this.current.title;
    if (name === "plots") return this.plots.map((plot) => plot.name);
    return this.variables.get(name);
  }
};
function plotPrefix(pre, plot) {
  if (!plot.startsWith(pre)) return false;
  return pre.length === plot.length || !/[0-9]$/.test(pre);
}
function splitWords(text) {
  const words = [];
  let word = "";
  let quoted = false;
  let depth = 0;
  for (const character of text) {
    if (character === '"') quoted = !quoted;
    if (!quoted && character === "(") depth++;
    if (!quoted && character === ")") depth = Math.max(0, depth - 1);
    if (!quoted && depth === 0 && /\s/.test(character)) {
      if (word !== "") words.push(word);
      word = "";
      continue;
    }
    word += character;
  }
  if (word !== "") words.push(word);
  return words;
}
function unquote(word) {
  return word.replace(/"/g, "");
}
function commandWord(text) {
  return (/^[^\s=(]+/.exec(text)?.[0] ?? "").toLowerCase();
}
function withoutRedirection(words) {
  const kept = [];
  for (let index = 0; index < words.length; index++) {
    const word = words[index];
    if (/^>>?/.test(word)) {
      if (word === ">" || word === ">>") index++;
      continue;
    }
    kept.push(word);
  }
  return kept;
}
function rejectRedirection(command, text, line) {
  if (splitWords(text).some((word) => word === "<" || word === ">" || word === ">>")) {
    throw new UnsupportedControlCommandError(
      command,
      `a separate '<' or '>' word on a ${command} line is csh-style redirection in ngspice and is not supported`,
      line.lineNumber,
      line.text
    );
  }
}
function findAssignment(text, from) {
  for (let index = text.indexOf("=", from); index >= 0; index = text.indexOf("=", index + 1)) {
    if (text[index + 1] === "=") {
      index++;
      continue;
    }
    if (index > 0 && "!<>".includes(text[index - 1])) continue;
    return index;
  }
  return -1;
}
function gettokAt(text, start) {
  const [token = ""] = gettokWords(text.slice(start));
  let end = text.indexOf(token, start) + token.length;
  while (end < text.length && (/\s/.test(text[end]) || text[end] === ",")) end++;
  return { token, end };
}
function sensitivityVectorNames(device, parameter, ac) {
  const name = device.toLowerCase();
  const plain = (vectorName) => [{ name: vectorName, firstPointOnly: false }];
  switch (parameter) {
    case "resistance":
      return ac ? [{ name, firstPointOnly: true }, { name: `${name}_ac`, firstPointOnly: false }] : plain(name);
    case "acMagnitude":
      return plain(`${name}_acmag`);
    case "gain":
      return plain(`${name}_gain`);
    case "multiplier":
      return plain(`${name}_m`);
    case "scale":
      return plain(`${name}_scale`);
    default:
      return plain(name);
  }
}
function roundHalfAway(value) {
  return Math.sign(value) * Math.round(Math.abs(value));
}
function formatC(value) {
  if (Number.isNaN(value)) return "nan";
  if (!Number.isFinite(value)) return value > 0 ? "inf" : "-inf";
  return value.toExponential(6).replace(/e([+-])(\d)$/, "e$10$2");
}
function assignmentIndex(text) {
  let depth = 0;
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === "[" || character === "(") depth++;
    if (character === "]" || character === ")") depth--;
    if (character === "=" && depth === 0) return index;
  }
  return -1;
}

// src/control-device-output.ts
function controlOperatingState(compiled, directive, result) {
  const { nodeNames, branchNames, nodeCount } = compiled;
  const solution = new Float64Array(nodeCount + branchNames.length);
  const fill = (voltage, current) => {
    for (let i = 0; i < nodeNames.length; i++) {
      const value = voltage(nodeNames[i]);
      if (value === void 0) return false;
      solution[i] = value;
    }
    for (let i = 0; i < branchNames.length; i++) {
      const value = current(branchNames[i]);
      if (value === void 0) return false;
      solution[nodeCount + i] = value;
    }
    return true;
  };
  let filled = false;
  if (directive.type === "op" && result.dc) {
    const { voltages, currents } = result.dc;
    filled = fill((name) => voltages.get(name), (name) => currents.get(name));
  } else if (directive.type === "dc" && result.dcSweep) {
    const { voltages, currents } = result.dcSweep;
    filled = fill((name) => voltages.get(name)?.at(-1), (name) => currents.get(name)?.at(-1));
  } else if (directive.type === "tran" && result.transient) {
    const { voltages, currents } = result.transient;
    filled = fill((name) => voltages.get(name)?.at(-1), (name) => currents.get(name)?.at(-1));
  }
  return filled ? { devices: compiled.devices, solution, nodeCount } : void 0;
}
function deviceOutputVector(state, name, parameter) {
  if (!state) return void 0;
  const wanted = name.toLowerCase();
  const device = state.devices.find((candidate) => candidate.name.toLowerCase() === wanted);
  if (!device) return void 0;
  const key = parameter.toLowerCase();
  const { solution, nodeCount } = state;
  const voltage = (node) => node >= 0 ? solution[node] : 0;
  const branch = (index) => solution[nodeCount + index];
  if (device instanceof Resistor && key === "i") {
    const [positive, negative] = device.nodes;
    return [device.branchIndex !== void 0 ? branch(device.branchIndex) : (voltage(positive) - voltage(negative)) * device.conductance];
  }
  if (device instanceof CurrentSource && key === "current") {
    return device.lastCurrent === void 0 ? void 0 : [device.lastCurrent];
  }
  if (device instanceof BehavioralCurrentSource && key === "i") return [device.lastValue];
  if ((device instanceof BehavioralVoltageSource || device instanceof VoltageSource) && key === "i") {
    return [branch(device.branches[0])];
  }
  return void 0;
}

// src/analysis/noise.ts
var BOLTZMANN_CONSTANT = 1380649e-29;
var ELEMENTARY_CHARGE = 1602176634e-28;
var CELSIUS_TO_KELVIN = 273.15;
var DEFAULT_TEMPERATURE_KELVIN = CELSIUS_TO_KELVIN + 27;
var N_MINGAIN = 1e-20;
var BJT_NOISE_MODEL_PARAMETERS = /* @__PURE__ */ new Set([
  "LEVEL",
  "BF",
  "BR",
  "IS",
  "NF",
  "NR",
  "VAF",
  "VA",
  "IKF",
  "IK",
  "ISE",
  "C2",
  "NE",
  "VAR",
  "VB",
  "IKR",
  "ISC",
  "C4",
  "NC",
  "NKF",
  "NK",
  "RB",
  "RC",
  "RE",
  "KF",
  "AF",
  "CJE",
  "VJE",
  "PE",
  "MJE",
  "ME",
  "TF",
  "XTF",
  "VTF",
  "ITF",
  "CJC",
  "VJC",
  "PC",
  "MJC",
  "MC",
  "XCJC",
  "TR",
  "FC",
  "XTI",
  "XTB",
  "EG",
  "polarity",
  "ISS",
  "NS",
  "CJS",
  "CSUB",
  "CCS",
  "VJS",
  "PS",
  "MJS",
  "MS",
  "SUBS",
  "TNOM",
  "TREF"
]);
function assertNoiseDevicesSupported(compiled) {
  const hasDifferentialOutput = compiled.analyses.some(
    (analysis) => analysis.type === "noise" && analysis.outputReferenceNode !== void 0
  );
  for (const device of compiled.devices) {
    if (hasDifferentialOutput && isSemiconductorNoiseDevice(device)) {
      throw new InvalidCircuitError(
        ".noise differential voltage output only supports resistor noise"
      );
    }
    if (device instanceof Diode && (device.params.RS ?? 0) > 0) {
      throw new InvalidCircuitError(
        `.noise does not support diode series-resistance noise for '${device.name}'`
      );
    }
    let kind;
    if (device instanceof BJT) {
      for (const parameter of Object.keys(device.suppliedParams)) {
        if (!BJT_NOISE_MODEL_PARAMETERS.has(parameter)) {
          throw new InvalidCircuitError(
            `.noise does not support BJT model parameter '${parameter}' for '${device.name}'`
          );
        }
      }
      if (device.nodes[4] !== void 0) {
        throw new InvalidCircuitError(
          `.noise does not support BJT base resistance with XCJC < 1 for '${device.name}'`
        );
      }
    } else if (device instanceof BSIM3v3) kind = "MOSFET";
    else if (device instanceof ClassicBsimMosfet) kind = `MOSFET ${device.setup.kind}`;
    else if (device instanceof MOS2) kind = "MOSFET level 2";
    else if (device instanceof MOS3) kind = `MOSFET level ${device.model.level}`;
    else if (device instanceof HFET1) kind = "HFET";
    if (device instanceof MOSFET) {
      if (device.params.LEVEL !== 1) {
        throw new InvalidCircuitError(
          `.noise only supports MOSFET level 1 for '${device.name}'`
        );
      }
      for (const parameter of ["RD", "RS"]) {
        if (device.suppliedParams[parameter] !== void 0) {
          throw new InvalidCircuitError(
            `.noise does not support MOSFET model parameter '${parameter}' for '${device.name}'`
          );
        }
      }
      const sourceNode = device.nodes[2];
      const bulkNode = device.nodes[3] ?? sourceNode;
      if (bulkNode !== sourceNode || device.suppliedParams.GAMMA !== void 0 || device.suppliedParams.PHI !== void 0) {
        throw new InvalidCircuitError(
          `.noise does not support MOSFET bulk/body-effect form for '${device.name}'`
        );
      }
      const { W, L, KF, AF, NLEV, TOX } = device.params;
      if (!(W > 0) || !Number.isFinite(W) || !(L > 0) || !Number.isFinite(L)) {
        throw new InvalidCircuitError(`.noise requires positive finite MOSFET W and L for '${device.name}'`);
      }
      if (!(KF >= 0) || !Number.isFinite(KF) || !(AF > 0) || !Number.isFinite(AF)) {
        throw new InvalidCircuitError(`.noise requires finite MOSFET KF >= 0 and AF > 0 for '${device.name}'`);
      }
      if (NLEV !== 2) {
        throw new InvalidCircuitError(`.noise only supports MOSFET NLEV=2 for '${device.name}'`);
      }
      if (TOX !== void 0 && (!(TOX > 0) || !Number.isFinite(TOX))) {
        throw new InvalidCircuitError(`.noise requires a positive finite MOSFET TOX for '${device.name}'`);
      }
    }
    if (kind) {
      throw new InvalidCircuitError(
        `.noise does not support ${kind} noise for '${device.name}'`
      );
    }
  }
}
function solveNoise(compiled, analysis, options, dcSolution) {
  const { devices, nodeCount, branchCount, nodeNames, branchNames } = compiled;
  const outputIndex = findNodeIndex(compiled, analysis.outputNode);
  const outputReferenceIndex = analysis.outputReferenceNode === void 0 ? -1 : findNodeIndex(compiled, analysis.outputReferenceNode);
  if (analysis.outputReferenceNode !== void 0 && devices.some(isSemiconductorNoiseDevice)) {
    throw new InvalidCircuitError(
      ".noise differential voltage output only supports resistor noise"
    );
  }
  const inputSource = devices.find(
    (device) => (device instanceof VoltageSource || device instanceof CurrentSource) && device.name.toLowerCase() === analysis.inputSource.toLowerCase()
  );
  if (!(inputSource instanceof VoltageSource || inputSource instanceof CurrentSource)) {
    throw new InvalidCircuitError(
      `.noise input source '${analysis.inputSource}' is not an independent voltage or current source`
    );
  }
  const assembler = new MNAAssembler(nodeCount, branchCount);
  assembler.solution.set(dcSolution);
  const ctx = assembler.getStampContext();
  for (const device of devices) {
    if (device.stampSmallSignal) device.stampSmallSignal(ctx);
    else device.stamp(ctx);
  }
  for (const device of devices) device.stampDynamic?.(ctx);
  for (let i = 0; i < nodeCount; i++) assembler.G.add(i, i, options.gmin);
  const { csc: gCsc } = toCsc(assembler.G);
  const { csc: cCsc } = toCsc(assembler.C);
  const solver = new ComplexSparseSolver();
  solver.analyzePattern(
    gCsc,
    cCsc,
    createMatrixVariableIdentities(nodeNames, branchNames)
  );
  const systemSize = nodeCount + branchCount;
  const zeroImaginary = new Float64Array(systemSize);
  const gainRhs = new Float64Array(systemSize);
  if (inputSource instanceof VoltageSource) {
    gainRhs[nodeCount + inputSource.branchIndex] = 1;
  } else {
    const [positiveNode, negativeNode] = inputSource.nodes;
    if (positiveNode >= 0) gainRhs[positiveNode] -= 1;
    if (negativeNode >= 0) gainRhs[negativeNode] += 1;
  }
  const resistorSources = devices.filter((device) => device instanceof Resistor && device.noisy).map((resistor) => {
    if (!(resistor.resistance > 0) || !Number.isFinite(resistor.resistance)) {
      throw new InvalidCircuitError(
        `.noise requires a positive finite resistance for '${resistor.name}'`
      );
    }
    if (resistor.flickerCoefficient !== 0) {
      throw new InvalidCircuitError(
        `.noise does not support resistor flicker noise (model KF) for '${resistor.name}'`
      );
    }
    const kelvin = resistor.getTemperature() + CELSIUS_TO_KELVIN;
    return {
      positive: resistor.nodes[0],
      negative: resistor.nodes[1],
      currentPowerDensity: (_frequency) => 4 * BOLTZMANN_CONSTANT * kelvin * resistor.conductance
    };
  });
  const mosfetSources = devices.filter((device) => device instanceof MOSFET).flatMap((mosfet) => {
    const operatingPoint = mosfet.noiseOperatingPoint(dcSolution);
    const { W, KF, AF, TOX, M } = mosfet.params;
    const L = mosfet.effectiveLength;
    const oxideCapacitance = 3.9 * 8854214871e-21 / (TOX ?? 1e-7);
    const sources = [{
      positive: operatingPoint.drainNode,
      negative: operatingPoint.sourceNode,
      currentPowerDensity: (_frequency) => 4 * BOLTZMANN_CONSTANT * DEFAULT_TEMPERATURE_KELVIN * (2 / 3) * Math.abs(operatingPoint.transconductance)
    }];
    if (KF > 0) {
      sources.push({
        positive: operatingPoint.drainNode,
        negative: operatingPoint.sourceNode,
        currentPowerDensity: (frequency) => KF * operatingPoint.transconductance * operatingPoint.transconductance / (M * Math.pow(frequency, AF) * W * L * oxideCapacitance)
      });
    }
    return sources;
  });
  const bjtSources = devices.filter((device) => device instanceof BJT).flatMap((bjt) => {
    const operatingPoint = bjt.noiseOperatingPoint(dcSolution);
    const sources = [{
      positive: operatingPoint.collectorNode,
      negative: operatingPoint.emitterNode,
      currentPowerDensity: (_frequency) => 2 * ELEMENTARY_CHARGE * operatingPoint.collectorCurrent
    }, {
      positive: operatingPoint.baseNode,
      negative: operatingPoint.emitterNode,
      currentPowerDensity: (_frequency) => 2 * ELEMENTARY_CHARGE * operatingPoint.baseCurrent
    }];
    if (bjt.params.KF > 0) {
      sources.push({
        positive: operatingPoint.baseNode,
        negative: operatingPoint.emitterNode,
        currentPowerDensity: (frequency) => bjt.params.KF * Math.pow(Math.max(operatingPoint.baseCurrent, 1e-38), bjt.params.AF) / frequency
      });
    }
    return sources;
  });
  const diodeSources = devices.filter((device) => device instanceof Diode).flatMap((diode) => {
    const operatingPoint = diode.noiseOperatingPoint(dcSolution);
    const current = Math.abs(operatingPoint.current);
    const sources = [{
      nodes: diode.nodes,
      powerDensity: () => 2 * ELEMENTARY_CHARGE * current
    }];
    if (operatingPoint.flickerCoefficient > 0) {
      const multiplier = operatingPoint.parallelMultiplier;
      sources.push({
        nodes: diode.nodes,
        powerDensity: (frequency) => operatingPoint.flickerCoefficient * Math.pow(Math.max(current / multiplier, Number.MIN_VALUE), operatingPoint.flickerExponent) * multiplier / frequency
      });
    }
    return sources;
  });
  const switchSources = devices.filter((device) => device instanceof SwitchBase).map((sw) => ({
    positive: sw.nodes[0],
    negative: sw.nodes[1],
    currentPowerDensity: (_frequency) => 4 * BOLTZMANN_CONSTANT * DEFAULT_TEMPERATURE_KELVIN * sw.smallSignalConductance
  }));
  const noiseSources = [...resistorSources, ...switchSources, ...mosfetSources, ...bjtSources];
  const frequencies = frequencyGrid(analysis, options.reltol, "noise");
  const hasIntegratedTotals = analysis.stopFreq > analysis.startFreq;
  const outputNoiseDensity = [];
  const inputNoiseDensity = [];
  const gainSquaredInverse = [];
  const sourceOutputPowerDensity = noiseSources.map(() => []);
  const diodeOutputPowerDensity = diodeSources.map(() => []);
  for (const frequency of frequencies) {
    solver.factorize(gCsc, cCsc, 2 * Math.PI * frequency);
    const [gainReal, gainImaginary] = solver.solve(gainRhs, zeroImaginary);
    const gain = differentialMagnitude(
      gainReal,
      gainImaginary,
      outputIndex,
      outputReferenceIndex
    );
    if (!(gain > 0) || !Number.isFinite(gain)) {
      const outputName = analysis.outputReferenceNode === void 0 ? analysis.outputNode : `${analysis.outputNode},${analysis.outputReferenceNode}`;
      throw new InvalidCircuitError(
        `.noise input source '${analysis.inputSource}' has zero gain to '${outputName}'`
      );
    }
    gainSquaredInverse.push(1 / Math.max(gain * gain, N_MINGAIN));
    let outputPowerDensity = 0;
    for (let index = 0; index < noiseSources.length; index++) {
      const { positive, negative, currentPowerDensity } = noiseSources[index];
      const powerDensity = currentPowerDensity(frequency);
      const currentDensity = Math.sqrt(Math.abs(powerDensity));
      const rhs = new Float64Array(systemSize);
      if (positive >= 0) rhs[positive] -= currentDensity;
      if (negative >= 0) rhs[negative] += currentDensity;
      const [real, imaginary] = solver.solve(rhs, zeroImaginary);
      const contribution = Math.sign(powerDensity) * differentialMagnitudeSquared(
        real,
        imaginary,
        outputIndex,
        outputReferenceIndex
      );
      sourceOutputPowerDensity[index].push(contribution);
      outputPowerDensity += contribution;
    }
    for (let index = 0; index < diodeSources.length; index++) {
      const { nodes, powerDensity } = diodeSources[index];
      const rhs = new Float64Array(systemSize);
      const [positive, negative] = nodes;
      const currentDensity = Math.sqrt(powerDensity(frequency));
      if (positive >= 0) rhs[positive] -= currentDensity;
      if (negative >= 0) rhs[negative] += currentDensity;
      const [real, imaginary] = solver.solve(rhs, zeroImaginary);
      const contribution = differentialMagnitudeSquared(
        real,
        imaginary,
        outputIndex,
        outputReferenceIndex
      );
      diodeOutputPowerDensity[index].push(contribution);
      outputPowerDensity += contribution;
    }
    const outputDensity = Math.sqrt(outputPowerDensity);
    outputNoiseDensity.push(outputDensity);
    inputNoiseDensity.push(outputDensity * Math.sqrt(gainSquaredInverse[gainSquaredInverse.length - 1]));
  }
  const integratedOutputNoise = hasIntegratedTotals ? Math.sqrt(sumIntegratedOutputPower(
    frequencies,
    [...sourceOutputPowerDensity, ...diodeOutputPowerDensity]
  )) : void 0;
  const integratedInputNoise = hasIntegratedTotals ? Math.sqrt(sumIntegratedInputPower(
    frequencies,
    [...sourceOutputPowerDensity, ...diodeOutputPowerDensity],
    gainSquaredInverse
  )) : void 0;
  return new NoiseResult(
    frequencies,
    analysis.outputNode,
    analysis.inputSource,
    outputNoiseDensity,
    inputNoiseDensity,
    integratedOutputNoise,
    integratedInputNoise,
    analysis.outputReferenceNode
  );
}
function isSemiconductorNoiseDevice(device) {
  return device instanceof Diode || device instanceof BJT || device instanceof JFET || device instanceof MOSFET || device instanceof MOS2 || device instanceof MOS3 || device instanceof BSIM3v3;
}
function findNodeIndex(compiled, name) {
  for (const [nodeName, index] of compiled.nodeIndexMap) {
    if (nodeName.toLowerCase() === name.toLowerCase()) return index;
  }
  throw new InvalidCircuitError(`.noise output node '${name}' does not exist`);
}
function differentialMagnitude(real, imaginary, positive, negative) {
  return Math.sqrt(differentialMagnitudeSquared(real, imaginary, positive, negative));
}
function differentialMagnitudeSquared(real, imaginary, positive, negative) {
  const realDifference = (positive < 0 ? 0 : real[positive]) - (negative < 0 ? 0 : real[negative]);
  const imaginaryDifference = (positive < 0 ? 0 : imaginary[positive]) - (negative < 0 ? 0 : imaginary[negative]);
  return realDifference * realDifference + imaginaryDifference * imaginaryDifference;
}
function sumIntegratedOutputPower(frequencies, sources) {
  return sources.reduce((total, powerDensity) => {
    for (let index = 1; index < frequencies.length; index++) {
      total += integratePowerLawInterval(
        frequencies[index - 1],
        frequencies[index],
        powerDensity[index],
        Math.log(Math.max(powerDensity[index - 1], 1e-38)),
        Math.log(Math.max(powerDensity[index], 1e-38))
      );
    }
    return total;
  }, 0);
}
function sumIntegratedInputPower(frequencies, sources, gainSquaredInverse) {
  return sources.reduce((total, outputPowerDensity) => {
    for (let index = 1; index < frequencies.length; index++) {
      const logGainInverse = Math.log(gainSquaredInverse[index]);
      total += integratePowerLawInterval(
        frequencies[index - 1],
        frequencies[index],
        outputPowerDensity[index] * gainSquaredInverse[index],
        Math.log(Math.max(outputPowerDensity[index - 1], 1e-38)) + logGainInverse,
        Math.log(Math.max(outputPowerDensity[index], 1e-38)) + logGainInverse
      );
    }
    return total;
  }, 0);
}
function integratePowerLawInterval(previousFrequency, frequency, powerDensity, previousLogPowerDensity, logPowerDensity) {
  const logFrequency = Math.log(frequency);
  const previousLogFrequency = Math.log(previousFrequency);
  let exponent = (logPowerDensity - previousLogPowerDensity) / (logFrequency - previousLogFrequency);
  if (Math.abs(exponent) < 1e-10) {
    return powerDensity * (frequency - previousFrequency);
  }
  const coefficient = Math.exp(logPowerDensity - exponent * logFrequency);
  exponent += 1;
  if (Math.abs(exponent) < 1e-10) {
    return coefficient * (logFrequency - previousLogFrequency);
  }
  return coefficient * (Math.exp(exponent * logFrequency) - Math.exp(exponent * previousLogFrequency)) / exponent;
}

// src/analysis/s-parameter.ts
var NGSPICE_BOLTZMANN = 138064852e-31;
var CELSIUS_TO_KELVIN2 = 273.15;
var NOMINAL_TEMPERATURE_C = 27;
var SP_NOISE_DEVICES = [
  Resistor,
  Capacitor,
  Inductor,
  MutualInductor,
  VoltageSource,
  CurrentSource,
  VCVS,
  VCCS,
  CCVS,
  CCCS
];
function solveSParameters(compiled, analysis, options, dcSolution, guard) {
  const ports = rfPorts(compiled);
  assertSingleExcitationKind(compiled);
  if (analysis.noise) assertNoiseDevicesSupported2(compiled.devices);
  const { nodeCount } = compiled;
  const system = createLinearizedFrequencySystem(compiled, options, dcSolution);
  const frequencies = frequencyGrid(analysis, options.reltol, "sp");
  const n = ports.length;
  const z0 = ports.map((port) => port.port.z0);
  const ki = z0.map((z) => 0.5 / Math.sqrt(z));
  const gn = ki.map((k) => 2 * k);
  const names = (prefix) => ports.flatMap((_, row) => ports.map((__, col) => `${prefix}_${row + 1}_${col + 1}`));
  const vectors = /* @__PURE__ */ new Map();
  for (const prefix of ["S", "Y", "Z", ...analysis.noise ? ["Cy"] : []]) {
    for (const name of names(prefix)) vectors.set(name, []);
  }
  const twoPortNoise = analysis.noise && n === 2;
  if (twoPortNoise) for (const name of ["NF", "SOpt", "NFmin", "Rn"]) vectors.set(name, []);
  const noiseSources = analysis.noise ? resistorNoiseSources(compiled.devices) : [];
  const noiseKelvin = twoPortNoise ? circuitKelvin(compiled.devices) : 0;
  const portVoltage = (x, port) => {
    const [positive, negative] = port.nodes;
    const at = (values, node) => node >= 0 ? values[node] : 0;
    return {
      real: at(x.real, positive) - at(x.real, negative),
      imaginary: at(x.imaginary, positive) - at(x.imaginary, negative)
    };
  };
  for (const frequency of frequencies) {
    guard?.checkpoint("solve:ac-point");
    guard?.recordResultPoint();
    const omega = 2 * Math.PI * frequency;
    const a = zeros(n);
    const b = zeros(n);
    for (let active = 0; active < n; active++) {
      const rhs = { real: new Float64Array(system.size), imaginary: new Float64Array(system.size) };
      rhs.real[nodeCount + ports[active].branchIndex] = 1;
      const x = system.solve(omega, rhs);
      for (let row = 0; row < n; row++) {
        const v = portVoltage(x, ports[row]);
        const branch = nodeCount + ports[row].branchIndex;
        const i = { real: -x.real[branch], imaginary: -x.imaginary[branch] };
        a[row][active] = {
          real: ki[row] * (v.real + z0[row] * i.real),
          imaginary: ki[row] * (v.imaginary + z0[row] * i.imaginary)
        };
        b[row][active] = {
          real: ki[row] * (v.real - z0[row] * i.real),
          imaginary: ki[row] * (v.imaginary - z0[row] * i.imaginary)
        };
      }
    }
    const s = multiply2(b, inverse(a));
    const sz0 = scaleColumns(s, z0);
    const sz0PlusZ0 = addDiagonal(sz0, z0, 1);
    const eMinusS = addDiagonal(negate(s), Array(n).fill(1), 1);
    const z = scaleRows(multiply2(inverse(eMinusS), scaleColumns(sz0PlusZ0, gn)), gn.map((g) => 1 / g));
    const y = scaleRows(multiply2(inverse(sz0PlusZ0), scaleColumns(eMinusS, gn)), gn.map((g) => 1 / g));
    push(vectors, "S", s);
    push(vectors, "Y", y);
    push(vectors, "Z", z);
    if (analysis.noise) {
      const cy = zeros(n);
      for (const source of noiseSources) {
        const rhs = { real: new Float64Array(system.size), imaginary: new Float64Array(system.size) };
        if (source.positive >= 0) rhs.real[source.positive] = 1;
        if (source.negative >= 0) rhs.real[source.negative] -= 1;
        const x = system.solve(omega, rhs);
        const amplitude = Math.sqrt(source.powerDensity);
        const vn = ports.map((port) => {
          const v = portVoltage(x, port);
          return { real: v.real * amplitude, imaginary: v.imaginary * amplitude };
        });
        const inoise = vn.map((value, d) => {
          let real = value.real / z0[d];
          let imaginary = value.imaginary / z0[d];
          for (let k = 0; k < n; k++) {
            real += y[d][k].real * vn[k].real - y[d][k].imaginary * vn[k].imaginary;
            imaginary += y[d][k].real * vn[k].imaginary + y[d][k].imaginary * vn[k].real;
          }
          return { real, imaginary };
        });
        for (let d = 0; d < n; d++) {
          for (let k = 0; k < n; k++) {
            cy[d][k].real += inoise[d].real * inoise[k].real + inoise[d].imaginary * inoise[k].imaginary;
            cy[d][k].imaginary += inoise[d].imaginary * inoise[k].real - inoise[d].real * inoise[k].imaginary;
          }
        }
      }
      push(vectors, "Cy", cy);
      if (twoPortNoise) pushTwoPortNoise(vectors, cy, y, 1 / z0[0], noiseKelvin);
    }
  }
  return new SParameterResult(frequencies, ports.map((port) => port.name), vectors);
}
function rfPorts(compiled) {
  const ports = compiled.devices.filter((device) => device instanceof VoltageSource && device.port !== void 0).sort((left, right) => left.port.number - right.port.number);
  if (ports.length < 2) {
    throw new InvalidCircuitError(
      `.sp needs at least two RF ports (V sources with portnum); found ${ports.length}`
    );
  }
  return ports;
}
function assertSingleExcitationKind(compiled) {
  for (const device of compiled.devices) {
    if (!(device instanceof CurrentSource)) continue;
    const excitation = device.getACExcitation();
    if (excitation && excitation.magnitude !== 0) {
      throw new InvalidCircuitError(
        `.sp does not support the AC excitation of current source '${device.name}'`
      );
    }
  }
}
function assertNoiseDevicesSupported2(devices) {
  for (const device of devices) {
    if (!SP_NOISE_DEVICES.some((kind) => device instanceof kind)) {
      throw new InvalidCircuitError(
        `.sp donoise only supports resistor thermal noise; '${device.name}' has unsupported S-parameter noise`
      );
    }
  }
}
function resistorNoiseSources(devices) {
  return devices.filter((device) => device instanceof Resistor && device.noisy).map((resistor) => {
    if (!Number.isFinite(resistor.conductance)) {
      throw new InvalidCircuitError(`.sp donoise requires a finite resistance for '${resistor.name}'`);
    }
    const kelvin = resistor.getTemperature() + CELSIUS_TO_KELVIN2;
    return {
      positive: resistor.nodes[0],
      negative: resistor.nodes[1],
      powerDensity: 4 * NGSPICE_BOLTZMANN * kelvin * resistor.conductance
    };
  });
}
function circuitKelvin(devices) {
  const resistor = devices.find((device) => device instanceof Resistor);
  return (resistor?.getCircuitTemperature() ?? NOMINAL_TEMPERATURE_C) + CELSIUS_TO_KELVIN2;
}
function pushTwoPortNoise(vectors, cy, y, y0, kelvin) {
  const knorm = 4 * NGSPICE_BOLTZMANN * kelvin;
  const c = cy.map((row) => row.map((value) => ({ real: value.real / knorm, imaginary: value.imaginary / knorm })));
  let rn = c[1][1].real / modulusSquared(y[1][0]);
  if (Math.abs(rn) < 1e-30) rn = 1e-30;
  if (Math.abs(c[1][1].real) < 1e-30 && Math.abs(c[1][1].imaginary) < 1e-30) c[1][1].real = 1e-30;
  const ycor = subtract2(y[0][0], mul(divide2(c[0][1], c[1][1]), y[1][0]));
  const gu = c[0][0].real - rn * modulusSquared(subtract2(y[0][0], ycor));
  const ysopt = { real: Math.sqrt(ycor.real * ycor.real + gu / rn), imaginary: -ycor.imaginary };
  const y0c = { real: y0, imaginary: 0 };
  const sopt = divide2(subtract2(y0c, ysopt), add2(y0c, ysopt));
  const fmin = 1 + 2 * rn * (ycor.real + ysopt.real);
  const nf = fmin + rn / y0 * modulusSquared(subtract2(y0c, ysopt));
  vectors.get("NF").push({ real: 10 * Math.log10(nf), imaginary: 0 });
  vectors.get("SOpt").push(sopt);
  vectors.get("NFmin").push({ real: 10 * Math.log10(fmin), imaginary: 0 });
  vectors.get("Rn").push({ real: rn, imaginary: 0 });
}
function push(vectors, prefix, matrix) {
  matrix.forEach((row, r) => row.forEach((value, c) => vectors.get(`${prefix}_${r + 1}_${c + 1}`).push(value)));
}
function zeros(n) {
  return Array.from({ length: n }, () => Array.from({ length: n }, () => ({ real: 0, imaginary: 0 })));
}
function add2(left, right) {
  return { real: left.real + right.real, imaginary: left.imaginary + right.imaginary };
}
function subtract2(left, right) {
  return { real: left.real - right.real, imaginary: left.imaginary - right.imaginary };
}
function mul(left, right) {
  return {
    real: left.real * right.real - left.imaginary * right.imaginary,
    imaginary: left.real * right.imaginary + left.imaginary * right.real
  };
}
function modulusSquared(value) {
  return value.real * value.real + value.imaginary * value.imaginary;
}
function divide2(left, right) {
  const denominator = modulusSquared(right);
  return {
    real: (left.real * right.real + left.imaginary * right.imaginary) / denominator,
    imaginary: (left.imaginary * right.real - left.real * right.imaginary) / denominator
  };
}
function multiply2(left, right) {
  return left.map((row) => right[0].map((_, col) => row.reduce((sum, value, k) => add2(sum, mul(value, right[k][col])), { real: 0, imaginary: 0 })));
}
function negate(matrix) {
  return matrix.map((row) => row.map((value) => ({ real: -value.real, imaginary: -value.imaginary })));
}
function addDiagonal(matrix, values, scale2) {
  return matrix.map((row, r) => row.map((value, c) => r === c ? { real: value.real + scale2 * values[r], imaginary: value.imaginary } : value));
}
function scaleColumns(matrix, values) {
  return matrix.map((row) => row.map((value, c) => ({ real: value.real * values[c], imaginary: value.imaginary * values[c] })));
}
function scaleRows(matrix, values) {
  return matrix.map((row, r) => row.map((value) => ({ real: value.real * values[r], imaginary: value.imaginary * values[r] })));
}
function inverse(matrix) {
  const n = matrix.length;
  const work = matrix.map((row, r) => [
    ...row.map((value) => ({ ...value })),
    ...Array.from({ length: n }, (_, c) => ({ real: r === c ? 1 : 0, imaginary: 0 }))
  ]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let r = col + 1; r < n; r++) {
      if (modulusSquared(work[r][col]) > modulusSquared(work[pivot][col])) pivot = r;
    }
    if (modulusSquared(work[pivot][col]) === 0) {
      throw new InvalidCircuitError(".sp port matrix is singular");
    }
    [work[col], work[pivot]] = [work[pivot], work[col]];
    const scale2 = divide2({ real: 1, imaginary: 0 }, work[col][col]);
    work[col] = work[col].map((value) => mul(value, scale2));
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const factor = work[r][col];
      work[r] = work[r].map((value, c) => subtract2(value, mul(factor, work[col][c])));
    }
  }
  return work.map((row) => row.slice(n));
}

// src/analysis/real-eigen.ts
var EigenConvergenceError = class extends Error {
  constructor() {
    super("real eigenvalue QR iteration did not converge");
    this.name = "EigenConvergenceError";
  }
};
var MAX_ITERATIONS_PER_EIGENVALUE = 60;
function realEigenvalues(matrix) {
  const size = matrix.length;
  if (size === 0) return [];
  for (const row of matrix) {
    if (row.length !== size) throw new Error("realEigenvalues requires a square matrix");
    for (const value of row) {
      if (!Number.isFinite(value)) throw new Error("realEigenvalues requires finite entries");
    }
  }
  const work = matrix.map((row) => [...row]);
  balance(work);
  reduceToHessenberg(work);
  return hessenbergQr(work);
}
function rangeFactor(matrix, tolerance) {
  const rows = matrix.length;
  const columns = rows === 0 ? 0 : matrix[0].length;
  const residual = Array.from({ length: columns }, (_, column) => matrix.map((row) => row[column]));
  const used = new Array(columns).fill(false);
  const vectors = [];
  for (; ; ) {
    let best = -1;
    let bestNorm = tolerance;
    for (let column = 0; column < columns; column++) {
      if (used[column]) continue;
      const norm2 = vectorNorm(residual[column]);
      if (norm2 > bestNorm) {
        best = column;
        bestNorm = norm2;
      }
    }
    if (best < 0) break;
    used[best] = true;
    const vector = residual[best].map((value) => value / bestNorm);
    for (let pass = 0; pass < 2; pass++) {
      for (const previous of vectors) {
        const projection = dot(previous, vector);
        for (let row = 0; row < rows; row++) vector[row] -= projection * previous[row];
      }
    }
    const norm = vectorNorm(vector);
    if (norm === 0) continue;
    for (let row = 0; row < rows; row++) vector[row] /= norm;
    vectors.push(vector);
    for (let column = 0; column < columns; column++) {
      if (used[column]) continue;
      const projection = dot(vector, residual[column]);
      for (let row = 0; row < rows; row++) residual[column][row] -= projection * vector[row];
    }
  }
  const basis = Array.from({ length: rows }, (_, row) => vectors.map((vector) => vector[row]));
  const coefficients = vectors.map((vector) => Array.from({ length: columns }, (_, column) => {
    let sum = 0;
    for (let row = 0; row < rows; row++) sum += vector[row] * matrix[row][column];
    return sum;
  }));
  return { basis, coefficients, rank: vectors.length };
}
function rankTolerance(matrix) {
  let scale2 = 0;
  let size = matrix.length;
  for (const row of matrix) {
    size = Math.max(size, row.length);
    for (const value of row) scale2 = Math.max(scale2, Math.abs(value));
  }
  return scale2 * size * Number.EPSILON * 100;
}
function deflateZeroEigenvalues(matrix) {
  let current = matrix.map((row) => [...row]);
  let removed = 0;
  const tolerance = rankTolerance(matrix);
  while (current.length > 0) {
    const factor = rangeFactor(current, tolerance);
    if (factor.rank === current.length) break;
    removed += current.length - factor.rank;
    current = multiply3(factor.coefficients, factor.basis);
  }
  return { matrix: current, removed };
}
function irreducibleBlocks(matrix) {
  const size = matrix.length;
  const index = new Array(size).fill(-1);
  const low = new Array(size).fill(0);
  const onStack = new Array(size).fill(false);
  const stack = [];
  const blocks = [];
  let counter = 0;
  const visit = (vertex) => {
    index[vertex] = counter;
    low[vertex] = counter;
    counter++;
    stack.push(vertex);
    onStack[vertex] = true;
    for (let next = 0; next < size; next++) {
      if (next === vertex || matrix[vertex][next] === 0) continue;
      if (index[next] < 0) {
        visit(next);
        low[vertex] = Math.min(low[vertex], low[next]);
      } else if (onStack[next]) {
        low[vertex] = Math.min(low[vertex], index[next]);
      }
    }
    if (low[vertex] === index[vertex]) {
      const block = [];
      let member;
      do {
        member = stack.pop();
        onStack[member] = false;
        block.push(member);
      } while (member !== vertex);
      blocks.push(block.sort((left, right) => left - right));
    }
  };
  for (let vertex = 0; vertex < size; vertex++) if (index[vertex] < 0) visit(vertex);
  return blocks.sort((left, right) => left[0] - right[0]);
}
function equilibratedRangeFactor(matrix) {
  const rows = matrix.length;
  const columns = rows === 0 ? 0 : matrix[0].length;
  const rowScale = new Array(rows).fill(1);
  const columnScale = new Array(columns).fill(1);
  const scaled = matrix.map((row) => [...row]);
  for (let iteration = 0; iteration < 20; iteration++) {
    let changed = false;
    for (let row = 0; row < rows; row++) {
      const factor2 = powerOfTwoScale(Math.max(...scaled[row].map(Math.abs)));
      if (factor2 === 1) continue;
      changed = true;
      rowScale[row] *= factor2;
      for (let column = 0; column < columns; column++) scaled[row][column] *= factor2;
    }
    for (let column = 0; column < columns; column++) {
      let maximum = 0;
      for (let row = 0; row < rows; row++) maximum = Math.max(maximum, Math.abs(scaled[row][column]));
      const factor2 = powerOfTwoScale(maximum);
      if (factor2 === 1) continue;
      changed = true;
      columnScale[column] *= factor2;
      for (let row = 0; row < rows; row++) scaled[row][column] *= factor2;
    }
    if (!changed) break;
  }
  const factor = rangeFactor(scaled, rankTolerance(scaled));
  const left = factor.basis.map((row, rowIndex) => row.map((value) => value / rowScale[rowIndex]));
  const right = factor.coefficients.map((row) => row.map((value, column) => value / columnScale[column]));
  return { left, right, rank: factor.rank };
}
function powerOfTwoScale(maximum) {
  if (maximum === 0 || !Number.isFinite(maximum)) return 1;
  const exponent = Math.round(Math.log2(maximum) / 2);
  return exponent === 0 ? 1 : 2 ** -exponent;
}
function multiply3(left, right) {
  const rows = left.length;
  const inner = right.length;
  const columns = inner === 0 ? 0 : right[0].length;
  const product = Array.from({ length: rows }, () => new Array(columns).fill(0));
  for (let row = 0; row < rows; row++) {
    for (let index = 0; index < inner; index++) {
      const value = left[row][index];
      if (value === 0) continue;
      for (let column = 0; column < columns; column++) {
        product[row][column] += value * right[index][column];
      }
    }
  }
  return product;
}
function dot(left, right) {
  let sum = 0;
  for (let index = 0; index < left.length; index++) sum += left[index] * right[index];
  return sum;
}
function vectorNorm(vector) {
  let scale2 = 0;
  for (const value of vector) scale2 = Math.max(scale2, Math.abs(value));
  if (scale2 === 0) return 0;
  let sum = 0;
  for (const value of vector) sum += (value / scale2) ** 2;
  return scale2 * Math.sqrt(sum);
}
function balance(a) {
  const size = a.length;
  const radix = 2;
  const radixSquared = radix * radix;
  let converged = false;
  while (!converged) {
    converged = true;
    for (let i = 0; i < size; i++) {
      let columnNorm = 0;
      let rowNorm = 0;
      for (let j = 0; j < size; j++) {
        if (j === i) continue;
        columnNorm += Math.abs(a[j][i]);
        rowNorm += Math.abs(a[i][j]);
      }
      if (columnNorm === 0 || rowNorm === 0) continue;
      const sum = columnNorm + rowNorm;
      let factor = 1;
      let threshold = rowNorm / radix;
      while (columnNorm < threshold) {
        factor *= radix;
        columnNorm *= radixSquared;
      }
      threshold = rowNorm * radix;
      while (columnNorm > threshold) {
        factor /= radix;
        columnNorm /= radixSquared;
      }
      if ((columnNorm + rowNorm) / factor < 0.95 * sum) {
        converged = false;
        const inverse2 = 1 / factor;
        for (let j = 0; j < size; j++) a[i][j] *= inverse2;
        for (let j = 0; j < size; j++) a[j][i] *= factor;
      }
    }
  }
}
function reduceToHessenberg(a) {
  const size = a.length;
  for (let k = 0; k < size - 2; k++) {
    let scale2 = 0;
    for (let i = k + 1; i < size; i++) scale2 = Math.max(scale2, Math.abs(a[i][k]));
    if (scale2 === 0) continue;
    const v = [];
    let normSquared = 0;
    for (let i = k + 1; i < size; i++) {
      const value = a[i][k] / scale2;
      v.push(value);
      normSquared += value * value;
    }
    const alpha = (v[0] >= 0 ? -1 : 1) * Math.sqrt(normSquared);
    v[0] -= alpha;
    const vNormSquared = v.reduce((sum, value) => sum + value * value, 0);
    if (vNormSquared === 0) continue;
    for (let j = k; j < size; j++) {
      let s = 0;
      for (let i = 0; i < v.length; i++) s += v[i] * a[k + 1 + i][j];
      s = 2 * s / vNormSquared;
      for (let i = 0; i < v.length; i++) a[k + 1 + i][j] -= s * v[i];
    }
    for (let i = 0; i < size; i++) {
      let s = 0;
      for (let j = 0; j < v.length; j++) s += a[i][k + 1 + j] * v[j];
      s = 2 * s / vNormSquared;
      for (let j = 0; j < v.length; j++) a[i][k + 1 + j] -= s * v[j];
    }
    a[k + 1][k] = alpha * scale2;
    for (let i = k + 2; i < size; i++) a[i][k] = 0;
  }
}
function sign(magnitude2, reference) {
  return reference >= 0 ? Math.abs(magnitude2) : -Math.abs(magnitude2);
}
function hessenbergQr(hessenberg) {
  const n = hessenberg.length;
  const a = [new Array(n + 1).fill(0)];
  for (const row of hessenberg) a.push([0, ...row]);
  const wr = new Array(n + 1).fill(0);
  const wi = new Array(n + 1).fill(0);
  let anorm = 0;
  for (let i = 1; i <= n; i++) {
    for (let j = Math.max(i - 1, 1); j <= n; j++) anorm += Math.abs(a[i][j]);
  }
  let nn = n;
  let t = 0;
  let p = 0;
  let q = 0;
  let r = 0;
  let s = 0;
  let w = 0;
  let x = 0;
  let y = 0;
  let z = 0;
  while (nn >= 1) {
    let its = 0;
    let l;
    do {
      for (l = nn; l >= 2; l--) {
        s = Math.abs(a[l - 1][l - 1]) + Math.abs(a[l][l]);
        if (s === 0) s = anorm;
        if (Math.abs(a[l][l - 1]) + s === s) {
          a[l][l - 1] = 0;
          break;
        }
      }
      x = a[nn][nn];
      if (l === nn) {
        wr[nn] = x + t;
        wi[nn] = 0;
        nn--;
      } else {
        y = a[nn - 1][nn - 1];
        w = a[nn][nn - 1] * a[nn - 1][nn];
        if (l === nn - 1) {
          p = 0.5 * (y - x);
          q = p * p + w;
          z = Math.sqrt(Math.abs(q));
          x += t;
          if (q >= 0) {
            z = p + sign(z, p);
            wr[nn - 1] = x + z;
            wr[nn] = z !== 0 ? x - w / z : x + z;
            wi[nn - 1] = 0;
            wi[nn] = 0;
          } else {
            wr[nn - 1] = x + p;
            wr[nn] = x + p;
            wi[nn - 1] = -z;
            wi[nn] = z;
          }
          nn -= 2;
        } else {
          if (its === MAX_ITERATIONS_PER_EIGENVALUE) throw new EigenConvergenceError();
          if (its > 0 && its % 10 === 0) {
            t += x;
            for (let i = 1; i <= nn; i++) a[i][i] -= x;
            s = Math.abs(a[nn][nn - 1]) + Math.abs(a[nn - 1][nn - 2]);
            x = 0.75 * s;
            y = x;
            w = -0.4375 * s * s;
          }
          its++;
          let m;
          for (m = nn - 2; m >= l; m--) {
            z = a[m][m];
            r = x - z;
            s = y - z;
            p = (r * s - w) / a[m + 1][m] + a[m][m + 1];
            q = a[m + 1][m + 1] - z - r - s;
            r = a[m + 2][m + 1];
            s = Math.abs(p) + Math.abs(q) + Math.abs(r);
            p /= s;
            q /= s;
            r /= s;
            if (m === l) break;
            const u = Math.abs(a[m][m - 1]) * (Math.abs(q) + Math.abs(r));
            const v = Math.abs(p) * (Math.abs(a[m - 1][m - 1]) + Math.abs(z) + Math.abs(a[m + 1][m + 1]));
            if (u + v === v) break;
          }
          for (let i = m + 2; i <= nn; i++) {
            a[i][i - 2] = 0;
            if (i !== m + 2) a[i][i - 3] = 0;
          }
          for (let k = m; k <= nn - 1; k++) {
            if (k !== m) {
              p = a[k][k - 1];
              q = a[k + 1][k - 1];
              r = 0;
              if (k !== nn - 1) r = a[k + 2][k - 1];
              x = Math.abs(p) + Math.abs(q) + Math.abs(r);
              if (x !== 0) {
                p /= x;
                q /= x;
                r /= x;
              }
            }
            s = sign(Math.sqrt(p * p + q * q + r * r), p);
            if (s !== 0) {
              if (k === m) {
                if (l !== m) a[k][k - 1] = -a[k][k - 1];
              } else {
                a[k][k - 1] = -s * x;
              }
              p += s;
              x = p / s;
              y = q / s;
              z = r / s;
              q /= p;
              r /= p;
              for (let j = k; j <= nn; j++) {
                p = a[k][j] + q * a[k + 1][j];
                if (k !== nn - 1) {
                  p += r * a[k + 2][j];
                  a[k + 2][j] -= p * z;
                }
                a[k + 1][j] -= p * y;
                a[k][j] -= p * x;
              }
              const mmin = nn < k + 3 ? nn : k + 3;
              for (let i = l; i <= mmin; i++) {
                p = x * a[i][k] + y * a[i][k + 1];
                if (k !== nn - 1) {
                  p += z * a[i][k + 2];
                  a[i][k + 2] -= p * r;
                }
                a[i][k + 1] -= p * q;
                a[i][k] -= p;
              }
            }
          }
        }
      }
    } while (l < nn - 1);
  }
  const values = [];
  for (let i = 1; i <= n; i++) values.push({ real: wr[i], imaginary: wi[i] });
  return values;
}

// src/analysis/pole-zero.ts
var MAX_DYNAMIC_ORDER = 12;
function solvePoleZero(compiled, analysis, options, convergence) {
  const inputPositive = nodeIndex(compiled, analysis.inputPositive, "input");
  const inputNegative = nodeIndex(compiled, analysis.inputNegative, "input");
  const outputPositive = nodeIndex(compiled, analysis.outputPositive, "output");
  const outputNegative = nodeIndex(compiled, analysis.outputNegative, "output");
  assertTerminalsNotDegenerate(analysis, inputPositive, inputNegative, outputPositive, outputNegative);
  const dcSolution = solveDCOperatingPoint(
    compiled,
    options,
    void 0,
    convergence
  ).assembler.solution;
  const assembler = buildLinearizedSystem(compiled, options, dcSolution);
  const conductance = sparseToDense(assembler.G);
  const storage = sparseToDense(assembler.C);
  const dynamicOrder = matrixRank(storage);
  if (dynamicOrder > MAX_DYNAMIC_ORDER) {
    throw new InvalidCircuitError(
      `.pz dynamic order ${dynamicOrder} exceeds bounded limit ${MAX_DYNAMIC_ORDER}`
    );
  }
  if (dynamicOrder === 0) {
    return new PoleZeroResult(
      analysis.inputPositive,
      analysis.inputNegative,
      analysis.outputPositive,
      analysis.outputNegative,
      [],
      []
    );
  }
  const naturalRoots = pencilRootsOrThrow(
    conductance,
    storage,
    maximumAbsolute(conductance) / maximumAbsolute(storage),
    ".pz requires a nonsingular DC small-signal matrix"
  );
  if (naturalRoots.length === 0) {
    return new PoleZeroResult(
      analysis.inputPositive,
      analysis.inputNegative,
      analysis.outputPositive,
      analysis.outputNegative,
      [],
      []
    );
  }
  const shiftScale = geometricMeanMagnitude(naturalRoots);
  const input = new Float64Array(compiled.nodeCount + compiled.branchCount);
  if (inputPositive >= 0) input[inputPositive] -= 1;
  if (inputNegative >= 0) input[inputNegative] += 1;
  const output = new Float64Array(input.length);
  if (outputPositive >= 0) output[outputPositive] += 1;
  if (outputNegative >= 0) output[outputNegative] -= 1;
  let poleRoots = naturalRoots;
  if (analysis.inputType === "vol") {
    const inputVoltage = new Float64Array(input.length);
    if (inputPositive >= 0) inputVoltage[inputPositive] += 1;
    if (inputNegative >= 0) inputVoltage[inputNegative] -= 1;
    poleRoots = transferZeros(conductance, storage, input, inputVoltage, shiftScale);
  }
  const poles = analysis.mode === "zer" ? [] : orderedValues(poleRoots);
  let zeros2 = [];
  if (analysis.mode !== "pol") {
    zeros2 = orderedValues(
      transferZeros(conductance, storage, input, output, shiftScale),
      maximumMagnitude(orderedValues(poleRoots))
    );
  }
  return new PoleZeroResult(
    analysis.inputPositive,
    analysis.inputNegative,
    analysis.outputPositive,
    analysis.outputNegative,
    poles,
    zeros2
  );
}
function assertTerminalsNotDegenerate(analysis, inputPositive, inputNegative, outputPositive, outputNegative) {
  if (inputPositive === inputNegative) throw new InvalidCircuitError(".pz Input is shorted");
  if (outputPositive === outputNegative) throw new InvalidCircuitError(".pz Output is shorted");
  if (analysis.inputType !== "vol") return;
  if (inputPositive === outputPositive && inputNegative === outputNegative) {
    throw new InvalidCircuitError(".pz Transfer function is unity");
  }
  if (inputPositive === outputNegative && inputNegative === outputPositive) {
    throw new InvalidCircuitError(".pz Transfer function is -1");
  }
}
function stampPoleZeroVoltageSource(device, context) {
  if (device.port || device.getACExcitation() === null) return false;
  const branch = context.numNodes + device.branchIndex;
  const [positive, negative] = device.nodes;
  if (positive >= 0) context.stampG(positive, branch, 1);
  if (negative >= 0) context.stampG(negative, branch, -1);
  context.stampG(branch, branch, 1);
  return true;
}
function buildLinearizedSystem(compiled, options, dcSolution) {
  const assembler = new MNAAssembler(compiled.nodeCount, compiled.branchCount);
  assembler.solution.set(dcSolution);
  const context = assembler.getStampContext();
  for (const device of compiled.devices) {
    if (device instanceof VoltageSource) {
      if (!stampPoleZeroVoltageSource(device, context)) device.stamp(context);
      continue;
    }
    if (device.stampSmallSignal) device.stampSmallSignal(context);
    else device.stamp(context);
  }
  for (const device of compiled.devices) device.stampDynamic?.(context);
  for (let index = 0; index < compiled.nodeCount; index++) {
    assembler.G.add(index, index, options.gmin);
  }
  return assembler;
}
function nodeIndex(compiled, name, terminal) {
  if (name === "0") return -1;
  for (const [nodeName, index] of compiled.nodeIndexMap) {
    if (nodeName.toLowerCase() === name.toLowerCase() && index >= 0) return index;
  }
  throw new InvalidCircuitError(`.pz ${terminal} node '${name}' does not exist`);
}
function sparseToDense(matrix) {
  const dense = Array.from({ length: matrix.size }, () => Array(matrix.size).fill(0));
  for (let row = 0; row < matrix.size; row++) {
    for (const [column, value] of matrix.getRow(row)) dense[row][column] = value;
  }
  return dense;
}
function solveColumns(matrix, right) {
  const size = matrix.length;
  const columns = right[0]?.length ?? 0;
  const result = Array.from({ length: size }, () => Array(columns).fill(0));
  for (let column = 0; column < columns; column++) {
    const rhs = right.map((row) => row[column]);
    const solution = solveReal(matrix, rhs);
    for (let row = 0; row < size; row++) result[row][column] = solution[row];
  }
  return result;
}
function solveReal(matrix, rhs) {
  const size = matrix.length;
  const augmented = matrix.map((row, index) => [...row, rhs[index]]);
  const scale2 = Math.max(...matrix.flat().map(Math.abs), 1);
  for (let column = 0; column < size; column++) {
    let pivot = column;
    for (let row = column + 1; row < size; row++) {
      if (Math.abs(augmented[row][column]) > Math.abs(augmented[pivot][column])) pivot = row;
    }
    if (Math.abs(augmented[pivot][column]) <= Number.EPSILON * scale2 * size) {
      throw new Error("singular matrix");
    }
    [augmented[column], augmented[pivot]] = [augmented[pivot], augmented[column]];
    for (let row = column + 1; row < size; row++) {
      const factor = augmented[row][column] / augmented[column][column];
      for (let index = column; index <= size; index++) {
        augmented[row][index] -= factor * augmented[column][index];
      }
    }
  }
  const solution = Array(size).fill(0);
  for (let row = size - 1; row >= 0; row--) {
    let value = augmented[row][size];
    for (let column = row + 1; column < size; column++) {
      value -= augmented[row][column] * solution[column];
    }
    solution[row] = value / augmented[row][row];
  }
  return solution;
}
function matrixRank(matrix) {
  const work = matrix.map((row) => [...row]);
  const size = matrix.length;
  const scale2 = Math.max(...work.flat().map(Math.abs), 0);
  if (scale2 === 0) return 0;
  const tolerance = scale2 * size * Number.EPSILON * 100;
  let rank = 0;
  for (let column = 0; column < size && rank < size; column++) {
    let pivot = rank;
    for (let row = rank + 1; row < size; row++) {
      if (Math.abs(work[row][column]) > Math.abs(work[pivot][column])) pivot = row;
    }
    if (Math.abs(work[pivot][column]) <= tolerance) continue;
    [work[rank], work[pivot]] = [work[pivot], work[rank]];
    for (let row = rank + 1; row < size; row++) {
      const factor = work[row][column] / work[rank][column];
      for (let index = column; index < size; index++) {
        work[row][index] -= factor * work[rank][index];
      }
    }
    rank++;
  }
  return rank;
}
function transferZeros(conductance, storage, input, output, shiftScale) {
  const size = conductance.length;
  const borderedConductance = conductance.map((row, index) => [...row, input[index]]);
  borderedConductance.push([...output, 0]);
  const borderedStorage = storage.map((row) => [...row, 0]);
  borderedStorage.push(Array(size + 1).fill(0));
  return pencilRootsOrThrow(
    borderedConductance,
    borderedStorage,
    shiftScale,
    ".pz transfer is identically zero"
  );
}
var SingularPencilError = class extends Error {
};
function pencilRootsOrThrow(conductance, storage, shiftScale, singularMessage) {
  try {
    return pencilRoots(conductance, storage, shiftScale);
  } catch (error) {
    if (error instanceof SingularPencilError) throw new InvalidCircuitError(singularMessage);
    if (error instanceof EigenConvergenceError) {
      throw new InvalidCircuitError(".pz eigenvalue iteration did not converge");
    }
    throw error;
  }
}
var SHIFT_FACTORS = [0, 0.7236067977499789, -1.381966011250105, 2.23606797749979, -0.4472135954999579];
function pencilRoots(a, b, shiftScale) {
  const range = equilibratedRangeFactor(b);
  if (range.rank === 0) return [];
  const scale2 = Number.isFinite(shiftScale) && shiftScale > 0 ? shiftScale : 1;
  for (const factor of SHIFT_FACTORS) {
    const shift = factor * scale2;
    const shifted = shift === 0 ? a : a.map((row, rowIndex) => row.map((value, column) => value + shift * b[rowIndex][column]));
    let solved;
    try {
      solved = solveColumns(shifted, range.left);
    } catch {
      continue;
    }
    if (!solved.every((row) => row.every(Number.isFinite))) continue;
    const reduced = multiply3(range.right, solved);
    const roots = [];
    for (const block of irreducibleBlocks(reduced)) {
      const finite = deflateZeroEigenvalues(
        block.map((row) => block.map((column) => reduced[row][column]))
      ).matrix;
      if (shift === 0) {
        roots.push(...realEigenvalues(finite).map(negativeReciprocal));
        continue;
      }
      const complement = finite.map((row, rowIndex) => row.map((value, column) => (rowIndex === column ? 1 : 0) - shift * value));
      const { matrix: remaining, removed } = deflateZeroEigenvalues(complement);
      roots.push(...realEigenvalues(remaining).map((kappa) => fromComplement(kappa, shift)));
      for (let index = 0; index < removed; index++) roots.push({ real: 0, imaginary: 0 });
    }
    return roots;
  }
  throw new SingularPencilError();
}
function negativeReciprocal(value) {
  if (value.imaginary === 0) return { real: -1 / value.real, imaginary: 0 };
  const squared = value.real * value.real + value.imaginary * value.imaginary;
  return { real: -value.real / squared, imaginary: value.imaginary / squared };
}
function fromComplement(kappa, shift) {
  const denominatorReal = kappa.real - 1;
  if (kappa.imaginary === 0) return { real: shift * kappa.real / denominatorReal, imaginary: 0 };
  const squared = denominatorReal * denominatorReal + kappa.imaginary * kappa.imaginary;
  return {
    real: shift * (kappa.real * denominatorReal + kappa.imaginary * kappa.imaginary) / squared,
    imaginary: shift * (kappa.imaginary * denominatorReal - kappa.real * kappa.imaginary) / squared
  };
}
function orderedValues(values, zeroScale = maximumMagnitude(values)) {
  const threshold = Math.max(zeroScale, 1) * 1e-12;
  return values.map((value) => ({
    real: Math.abs(value.real) <= threshold ? 0 : value.real,
    imaginary: Math.abs(value.imaginary) <= threshold ? 0 : value.imaginary
  })).sort((left, right) => left.real - right.real || right.imaginary - left.imaginary);
}
function maximumMagnitude(values) {
  return Math.max(...values.map(magnitude), 0);
}
function maximumAbsolute(matrix) {
  let maximum = 0;
  for (const row of matrix) for (const value of row) maximum = Math.max(maximum, Math.abs(value));
  return maximum;
}
function geometricMeanMagnitude(values) {
  const logs = values.map(magnitude).filter((value) => value > 0).map(Math.log);
  if (logs.length === 0) return 1;
  return Math.exp(logs.reduce((sum, value) => sum + value, 0) / logs.length);
}
function magnitude(value) {
  return Math.hypot(value.real, value.imaginary);
}

// src/analysis/sensitivity.ts
function solveSensitivity(compiled, analysis, options, convergence) {
  const outputIndex = findOutputIndex(compiled, analysis.outputNode);
  const targets = collectTargets(compiled, analysis.mode);
  if (analysis.mode === "ac") assertSingleACExcitation(compiled);
  if (analysis.mode === "dc") {
    const entries2 = targets.map((target) => ({
      device: target.device,
      parameter: target.parameter,
      dc: differentiateScalar(target, (value) => {
        target.set(value);
        return solveDCOperatingPoint(compiled, options, void 0, convergence).assembler.solution[outputIndex];
      })
    }));
    return new SensitivityResult(analysis.outputNode, "dc", [], entries2);
  }
  const frequencies = frequencyGrid(analysis, options.reltol, "sens");
  const entries = targets.map((target) => ({
    device: target.device,
    parameter: target.parameter,
    ac: differentiateComplex(target, (value) => {
      target.set(value);
      return solveACAtOutput(compiled, frequencies, options, outputIndex, convergence);
    })
  }));
  return new SensitivityResult(analysis.outputNode, "ac", frequencies, entries);
}
function assertSingleACExcitation(compiled) {
  const acSources = compiled.devices.filter((device) => (device instanceof VoltageSource || device instanceof CurrentSource) && device.waveform.type === "ac");
  const excitations = acSources.filter((device) => device.waveform.type === "ac" && device.waveform.magnitude !== 0).map((device) => device.name).sort((left, right) => left.localeCompare(right, "en", { sensitivity: "base" }));
  if (excitations.length > 1) {
    throw new InvalidCircuitError(
      `.sens AC supports at most one non-zero AC excitation; found ${excitations.join(", ")}`
    );
  }
  if (acSources.length > 1) {
    const names = acSources.map((device) => device.name).sort((left, right) => left.localeCompare(right, "en", { sensitivity: "base" }));
    const sourceKind = acSources.every((device) => device instanceof VoltageSource) ? "voltage source" : "independent source";
    throw new InvalidCircuitError(
      `.sens AC supports only one AC-form ${sourceKind}; found ${names.join(", ")}`
    );
  }
}
function collectTargets(compiled, mode) {
  const targets = [];
  for (const device of compiled.devices) {
    const target = parameterTarget(device, mode);
    if (target && target.value !== 0) targets.push(target);
    targets.push(...scalingTargets(device));
  }
  return targets.sort(
    (left, right) => left.device.localeCompare(right.device, "en", { sensitivity: "base" })
  );
}
function scalingTargets(device) {
  if (device instanceof Resistor) {
    return [
      mutable(device, "multiplier", device.multiplier, (value) => device.setMultiplier(value)),
      mutable(device, "scale", device.scale, (value) => device.setScale(value))
    ];
  }
  if (device instanceof Capacitor) {
    const capacitance = device.capacitance;
    const { multiplier, scale: scale2 } = device;
    return [
      mutable(device, "multiplier", multiplier, (value) => device.setParameter(
        rescaled(capacitance, value, multiplier)
      )),
      mutable(device, "scale", scale2, (value) => device.setParameter(rescaled(capacitance, value, scale2)))
    ];
  }
  if (device instanceof Inductor) {
    const inductance = device.inductance;
    const { multiplier, scale: scale2 } = device;
    return [
      mutable(device, "multiplier", multiplier, (value) => device.setParameter(
        rescaled(inductance, multiplier, value)
      )),
      mutable(device, "scale", scale2, (value) => device.setParameter(rescaled(inductance, value, scale2)))
    ];
  }
  if (device instanceof CurrentSource) {
    return [mutable(device, "multiplier", device.multiplier, (value) => {
      device.multiplier = value;
    })];
  }
  return [];
}
function rescaled(base, numerator, denominator) {
  return numerator === denominator ? base : base * numerator / denominator;
}
function parameterTarget(device, mode) {
  if (device instanceof Resistor) {
    if (mode === "ac" && device.hasAcResistance) {
      throw unsupported(device, "AC sensitivity of a resistor with an ac= resistance is not supported");
    }
    return mutable(device, "resistance", device.getParameter(), (value) => device.setParameter(value));
  }
  if (device instanceof Capacitor) {
    if (mode === "dc") return null;
    return mutable(device, "capacitance", device.capacitance, (value) => device.setParameter(value));
  }
  if (device instanceof Inductor) {
    if (mode === "dc") return null;
    return mutable(device, "inductance", device.inductance, (value) => device.setParameter(value));
  }
  if (device instanceof VoltageSource) {
    if (mode === "ac") {
      if (device.waveform.type !== "ac") {
        throw unsupported(device, "AC sensitivity requires an AC voltage-source waveform");
      }
      return mutable(
        device,
        "acMagnitude",
        device.waveform.magnitude,
        (value) => {
          if (device.waveform.type === "ac") device.waveform.magnitude = value;
        }
      );
    }
    if (device.waveform.type !== "dc" && device.waveform.type !== "ac") {
      throw unsupported(device, "DC sensitivity requires a DC-capable voltage source");
    }
    return mutable(device, "dc", device.getParameter(), (value) => device.setParameter(value));
  }
  if (device instanceof CurrentSource) {
    if (mode === "ac") {
      if (device.waveform.type !== "ac") {
        throw unsupported(device, "AC sensitivity requires an AC current-source waveform");
      }
      return mutable(
        device,
        "acMagnitude",
        device.waveform.magnitude,
        (value) => {
          if (device.waveform.type === "ac") device.waveform.magnitude = value;
        }
      );
    }
    if (device.waveform.type === "ac") {
      return mutable(
        device,
        "dc",
        device.waveform.dc ?? 0,
        (value) => {
          if (device.waveform.type === "ac") device.waveform.dc = value;
        }
      );
    }
    if (device.waveform.type !== "dc") {
      throw unsupported(device, "DC current-source sensitivity requires a DC waveform");
    }
    return mutable(
      device,
      "dc",
      device.waveform.value,
      (value) => {
        if (device.waveform.type === "dc") device.waveform.value = value;
      }
    );
  }
  if (device instanceof VCCS || device instanceof VCVS || device instanceof CCCS || device instanceof CCVS) {
    const controlled = device;
    const key = device instanceof VCCS ? "gm" : "gain";
    const value = controlled[key];
    if (value === void 0) throw unsupported(device, "controlled-source gain is unavailable");
    return mutable(device, "gain", value, (next) => {
      controlled[key] = next;
    });
  }
  throw unsupported(device, `device type ${device.constructor.name} is outside the bounded slice`);
}
function mutable(device, parameter, value, set) {
  if (!Number.isFinite(value)) throw unsupported(device, `${parameter} must be finite`);
  return { device: device.name, parameter, value, set };
}
function unsupported(device, detail) {
  return new InvalidCircuitError(`.sens does not support '${device.name}': ${detail}`);
}
function differentiateScalar(target, evaluate) {
  const step = perturbation(target.value);
  try {
    const high = evaluate(target.value + step);
    const low = evaluate(target.value - step);
    return (high - low) / (2 * step);
  } finally {
    target.set(target.value);
  }
}
function differentiateComplex(target, evaluate) {
  const step = perturbation(target.value);
  try {
    const high = evaluate(target.value + step);
    const low = evaluate(target.value - step);
    return high.map((value, index) => ({
      real: (value.real - low[index].real) / (2 * step),
      imaginary: (value.imaginary - low[index].imaginary) / (2 * step)
    }));
  } finally {
    target.set(target.value);
  }
}
function perturbation(value) {
  return Math.max(Math.abs(value) * 1e-5, 1e-12);
}
function solveACAtOutput(compiled, frequencies, options, outputIndex, convergence) {
  const dc = solveDCOperatingPoint(compiled, options, void 0, convergence).assembler.solution;
  const system = createLinearizedFrequencySystem(compiled, options, dc);
  const rhs = buildACRHS(compiled);
  return frequencies.map((frequency) => {
    const { real, imaginary } = system.solve(2 * Math.PI * frequency, rhs);
    return { real: real[outputIndex], imaginary: imaginary[outputIndex] };
  });
}
function findOutputIndex(compiled, name) {
  for (const [nodeName, index] of compiled.nodeIndexMap) {
    if (nodeName.toLowerCase() === name.toLowerCase() && index >= 0) return index;
  }
  throw new InvalidCircuitError(`.sens output node '${name}' does not exist`);
}

// src/analysis/distortion.ts
function solveDistortion(compiled, analysis, options, dcSolution, guard) {
  const frequencies = generateFrequencies(analysis);
  const diodes = compiled.devices.filter((device) => device instanceof Diode);
  if (diodes.length > 0) {
    return solveDiodeDistortion(
      compiled,
      analysis,
      options,
      dcSolution,
      frequencies,
      diodes,
      guard
    );
  }
  for (const _frequency of frequencies) {
    guard?.checkpoint("solve:ac-point");
    guard?.recordResultPoint();
  }
  const products = analysis.f2OverF1 === void 0 ? [2, 3] : ["f1+f2", "f1-f2", "2f1-f2"];
  return new DistortionResult(
    frequencies,
    zeroProductArrays(products, compiled.nodeNames, frequencies.length),
    zeroProductArrays(products, compiled.branchNames, frequencies.length),
    analysis.f2OverF1
  );
}
function assertDistortionSupported(compiled, analysis) {
  assertSupportedDevices(compiled);
  assertExcitations(compiled, analysis);
}
function assertSupportedDevices(compiled) {
  for (const device of compiled.devices) {
    if (device instanceof Diode) {
      device.assertDistortionSupported();
      continue;
    }
    if (device instanceof Resistor && device.hasAcResistance) {
      throw new InvalidCircuitError(
        `.disto does not support a resistor with an ac= resistance; found ${device.name}`
      );
    }
    if (device instanceof Resistor || device instanceof Capacitor || device instanceof Inductor || device instanceof VoltageSource || device instanceof CurrentSource) continue;
    throw new InvalidCircuitError(
      `.disto supports only independent sources, ideal R, L, C devices, and bounded diodes; found ${device.name} (${device.constructor.name})`
    );
  }
}
function assertExcitations(compiled, analysis) {
  const sources = compiled.devices.filter((device) => device instanceof VoltageSource || device instanceof CurrentSource);
  const activeF1 = sources.filter((source) => source.waveform.distortionF1?.magnitude !== void 0 && source.waveform.distortionF1.magnitude !== 0);
  if (activeF1.length !== 1) {
    const found = activeF1.length === 0 ? "0" : activeF1.map((source) => source.name).join(", ");
    throw new InvalidCircuitError(
      `.disto requires exactly one non-zero DISTOF1 excitation; found ${found}`
    );
  }
  assertValidExcitation(activeF1[0], "DISTOF1");
  const activeF2 = sources.filter((source) => source.waveform.distortionF2?.magnitude !== void 0 && source.waveform.distortionF2.magnitude !== 0);
  if (analysis.f2OverF1 === void 0) {
    if (activeF2.length > 0) {
      throw new InvalidCircuitError(
        `Non-zero DISTOF2 on source '${activeF2[0].name}' requires .disto f2overf1`
      );
    }
    return;
  }
  if (activeF2.length !== 1) {
    const found = activeF2.length === 0 ? "0" : activeF2.map((source) => source.name).join(", ");
    throw new InvalidCircuitError(
      `.disto two-tone requires exactly one non-zero DISTOF2 excitation; found ${found}`
    );
  }
  assertValidExcitation(activeF2[0], "DISTOF2");
}
function assertValidExcitation(source, field) {
  const excitation = field === "DISTOF1" ? source.waveform.distortionF1 : source.waveform.distortionF2;
  if (!Number.isFinite(excitation.magnitude) || excitation.magnitude <= 0 || !Number.isFinite(excitation.phase)) {
    throw new InvalidCircuitError(`Invalid ${field} excitation on source '${source.name}'`);
  }
}
function solveDiodeDistortion(compiled, analysis, options, dcSolution, frequencies, diodes, guard) {
  const coefficients = new Map(diodes.map((diode) => [
    diode,
    diode.distortionCoefficients(dcSolution)
  ]));
  const system = createLinearizedFrequencySystem(compiled, options, dcSolution, "distortion");
  const products = analysis.f2OverF1 === void 0 ? [2, 3] : ["f1+f2", "f1-f2", "2f1-f2"];
  const voltageArrays = zeroProductArrays(
    products,
    compiled.nodeNames,
    frequencies.length
  );
  const currentArrays = zeroProductArrays(
    products,
    compiled.branchNames,
    frequencies.length
  );
  const f1Rhs = buildDistortionRhs(compiled, "DISTOF1");
  const f2Rhs = analysis.f2OverF1 === void 0 ? void 0 : buildDistortionRhs(compiled, "DISTOF2");
  const omega2 = analysis.f2OverF1 === void 0 ? void 0 : 2 * Math.PI * analysis.startFreq * analysis.f2OverF1;
  const tone2 = omega2 === void 0 ? void 0 : system.solve(omega2, f2Rhs);
  for (let index = 0; index < frequencies.length; index++) {
    guard?.checkpoint("solve:ac-point");
    guard?.recordResultPoint();
    const omega1 = 2 * Math.PI * frequencies[index];
    const tone1 = system.solve(omega1, f1Rhs);
    const second = solveForcedProduct(
      system,
      2 * omega1,
      diodes,
      coefficients,
      (diode, coefficient) => multiply4(
        coefficientAt(coefficient, 2 * omega1),
        square(diodeVoltage(tone1, diode))
      )
    );
    if (tone2 === void 0 || omega2 === void 0) {
      const third = solveForcedProduct(
        system,
        3 * omega1,
        diodes,
        coefficients,
        (diode, coefficient) => {
          const v1 = diodeVoltage(tone1, diode);
          return add3(
            scale(multiply4(
              coefficientAt(coefficient, 3 * omega1),
              multiply4(v1, diodeVoltage(second, diode))
            ), 2),
            multiply4(
              cubicCoefficientAt(coefficient, 3 * omega1),
              multiply4(square(v1), v1)
            )
          );
        }
      );
      storeSolution(voltageArrays.get(2), currentArrays.get(2), second, compiled, index, 2);
      storeSolution(voltageArrays.get(3), currentArrays.get(3), third, compiled, index, 2);
      continue;
    }
    const sumOmega = omega1 + omega2;
    const differenceOmega = omega1 - omega2;
    const sum = solveForcedProduct(
      system,
      sumOmega,
      diodes,
      coefficients,
      (diode, coefficient) => multiply4(
        coefficientAt(coefficient, sumOmega),
        multiply4(diodeVoltage(tone1, diode), diodeVoltage(tone2, diode))
      )
    );
    const difference = solveForcedProduct(
      system,
      differenceOmega,
      diodes,
      coefficients,
      (diode, coefficient) => multiply4(
        coefficientAt(coefficient, differenceOmega),
        multiply4(diodeVoltage(tone1, diode), conjugate(diodeVoltage(tone2, diode)))
      )
    );
    const thirdDifferenceOmega = 2 * omega1 - omega2;
    const thirdDifference = solveForcedProduct(
      system,
      thirdDifferenceOmega,
      diodes,
      coefficients,
      (diode, coefficient) => {
        const v1 = diodeVoltage(tone1, diode);
        const conjugateV2 = conjugate(diodeVoltage(tone2, diode));
        const quadraticMix = add3(
          scale(multiply4(v1, diodeVoltage(difference, diode)), 4),
          scale(multiply4(conjugateV2, diodeVoltage(second, diode)), 2)
        );
        return add3(
          scale(multiply4(
            coefficientAt(coefficient, thirdDifferenceOmega),
            quadraticMix
          ), 1 / 3),
          multiply4(
            cubicCoefficientAt(coefficient, thirdDifferenceOmega),
            multiply4(square(v1), conjugateV2)
          )
        );
      }
    );
    storeSolution(
      voltageArrays.get("f1+f2"),
      currentArrays.get("f1+f2"),
      sum,
      compiled,
      index,
      4
    );
    storeSolution(
      voltageArrays.get("f1-f2"),
      currentArrays.get("f1-f2"),
      difference,
      compiled,
      index,
      4
    );
    storeSolution(
      voltageArrays.get("2f1-f2"),
      currentArrays.get("2f1-f2"),
      thirdDifference,
      compiled,
      index,
      6
    );
  }
  return new DistortionResult(
    frequencies,
    voltageArrays,
    currentArrays,
    analysis.f2OverF1
  );
}
function buildDistortionRhs(compiled, field) {
  const real = new Float64Array(compiled.nodeCount + compiled.branchCount);
  const imaginary = new Float64Array(real.length);
  for (const device of compiled.devices) {
    if (!(device instanceof VoltageSource || device instanceof CurrentSource)) continue;
    const excitation = field === "DISTOF1" ? device.waveform.distortionF1 : device.waveform.distortionF2;
    if (!excitation || excitation.magnitude === 0) continue;
    const phase = excitation.phase * Math.PI / 180;
    const value = {
      real: excitation.magnitude * Math.cos(phase) / 2,
      imaginary: excitation.magnitude * Math.sin(phase) / 2
    };
    if (device instanceof VoltageSource) {
      const row = compiled.nodeCount + device.branchIndex;
      real[row] += value.real;
      imaginary[row] += value.imaginary;
      continue;
    }
    const [positive, negative] = device.nodes;
    if (positive >= 0) {
      real[positive] += value.real;
      imaginary[positive] += value.imaginary;
    }
    if (negative >= 0) {
      real[negative] -= value.real;
      imaginary[negative] -= value.imaginary;
    }
  }
  return { real, imaginary };
}
function solveForcedProduct(system, omega, diodes, coefficients, force) {
  const rhs = {
    real: new Float64Array(system.size),
    imaginary: new Float64Array(system.size)
  };
  for (const diode of diodes) {
    const current = force(diode, coefficients.get(diode));
    const [positive, negative] = diode.nodes;
    if (positive >= 0) {
      rhs.real[positive] -= current.real;
      rhs.imaginary[positive] -= current.imaginary;
    }
    if (negative >= 0) {
      rhs.real[negative] += current.real;
      rhs.imaginary[negative] += current.imaginary;
    }
  }
  return system.solve(omega, rhs);
}
function diodeVoltage(solution, diode) {
  const [positive, negative] = diode.nodes;
  return {
    real: (positive >= 0 ? solution.real[positive] : 0) - (negative >= 0 ? solution.real[negative] : 0),
    imaginary: (positive >= 0 ? solution.imaginary[positive] : 0) - (negative >= 0 ? solution.imaginary[negative] : 0)
  };
}
function coefficientAt(coefficient, omega) {
  return { real: coefficient.current2, imaginary: omega * coefficient.charge2 };
}
function cubicCoefficientAt(coefficient, omega) {
  return { real: coefficient.current3, imaginary: omega * coefficient.charge3 };
}
function multiply4(a, b) {
  return {
    real: a.real * b.real - a.imaginary * b.imaginary,
    imaginary: a.real * b.imaginary + a.imaginary * b.real
  };
}
function add3(a, b) {
  return { real: a.real + b.real, imaginary: a.imaginary + b.imaginary };
}
function scale(value, factor) {
  return { real: value.real * factor, imaginary: value.imaginary * factor };
}
function square(value) {
  return multiply4(value, value);
}
function conjugate(value) {
  return { real: value.real, imaginary: -value.imaginary };
}
function storeSolution(voltages, currents, solution, compiled, index, factor) {
  for (let node = 0; node < compiled.nodeNames.length; node++) {
    voltages.get(compiled.nodeNames[node])[index] = {
      real: factor * solution.real[node],
      imaginary: factor * solution.imaginary[node]
    };
  }
  for (let branch = 0; branch < compiled.branchNames.length; branch++) {
    currents.get(compiled.branchNames[branch])[index] = {
      real: factor * solution.real[compiled.nodeCount + branch],
      imaginary: factor * solution.imaginary[compiled.nodeCount + branch]
    };
  }
}
function generateFrequencies(analysis) {
  const frequencies = [];
  for (let index = 0; ; index++) {
    const frequency = analysis.startFreq * Math.pow(10, index / analysis.points);
    if (frequency > analysis.stopFreq) break;
    frequencies.push(frequency);
  }
  return frequencies;
}
function zeroArrays(names, count2) {
  return new Map(names.map((name) => [
    name,
    Array.from({ length: count2 }, () => ({ real: 0, imaginary: 0 }))
  ]));
}
function zeroProductArrays(products, names, count2) {
  return new Map(products.map((product) => [product, zeroArrays(names, count2)]));
}

// src/analysis/step-scheduler.ts
function abortReason(signal) {
  if (signal.reason !== void 0) return signal.reason;
  const error = new Error("Step task scheduling aborted");
  error.name = "AbortError";
  return error;
}
function clampWorkerCount(maxWorkers, taskCount) {
  const integral = Math.floor(maxWorkers);
  const lowerBounded = Number.isNaN(integral) ? 1 : Math.max(1, integral);
  return Math.min(taskCount, lowerBounded);
}
async function settleAll(actions) {
  await Promise.allSettled(actions.map((action) => Promise.resolve().then(action)));
}
async function scheduleStepTasks(tasks, factory, options) {
  if (tasks.length === 0) return [];
  const workerCount = clampWorkerCount(options.maxWorkers, tasks.length);
  const executors = [];
  const disposalPromises = /* @__PURE__ */ new Map();
  const results = new Array(tasks.length);
  let nextIndex = 0;
  let stopped = false;
  let firstFailure;
  let resolveStopped;
  const stoppedPromise = new Promise((resolve) => {
    resolveStopped = resolve;
  });
  let failureCleanup;
  const dispose = (executor) => {
    const existing = disposalPromises.get(executor);
    if (existing) return existing;
    const disposal = Promise.resolve().then(() => executor.dispose());
    disposalPromises.set(executor, disposal);
    return disposal;
  };
  const cleanUpExecutor = async (executor, reason) => {
    await settleAll([() => executor.cancel(reason)]);
    await settleAll([() => dispose(executor)]);
  };
  const cleanUpFailure = (reason) => {
    const snapshot = executors.slice();
    return (async () => {
      await settleAll(snapshot.map((executor) => () => executor.cancel(reason)));
      await settleAll(snapshot.map((executor) => () => dispose(executor)));
    })();
  };
  const fail = (reason) => {
    if (stopped) return;
    stopped = true;
    firstFailure = reason;
    resolveStopped();
    failureCleanup = cleanUpFailure(reason);
  };
  const onAbort = () => fail(abortReason(options.signal));
  options.signal?.addEventListener("abort", onAbort, { once: true });
  try {
    if (options.signal?.aborted) fail(abortReason(options.signal));
    for (let workerIndex = 0; workerIndex < workerCount && !stopped; workerIndex++) {
      let executor;
      try {
        executor = await factory.create(workerIndex);
      } catch (error) {
        fail(error);
        break;
      }
      if (stopped) {
        await cleanUpExecutor(executor, firstFailure);
        break;
      }
      executors.push(executor);
    }
    if (!stopped) {
      const runExecutor = async (executor) => {
        while (!stopped) {
          const index = nextIndex++;
          if (index >= tasks.length) return;
          const task = tasks[index];
          const execution = Promise.resolve().then(() => executor.execute(task, index)).then(
            (result) => ({ kind: "completed", result }),
            (error) => ({ kind: "failed", error })
          );
          const outcome = await Promise.race([
            execution,
            stoppedPromise.then(() => ({ kind: "stopped" }))
          ]);
          if (outcome.kind === "stopped") return;
          if (outcome.kind === "failed") {
            fail(outcome.error);
            return;
          }
          results[index] = outcome.result;
          try {
            options.onComplete?.({ index, task, result: outcome.result });
          } catch (error) {
            fail(error);
            return;
          }
        }
      };
      await Promise.all(executors.map(runExecutor));
    }
    if (stopped) {
      await failureCleanup;
      throw firstFailure;
    }
    try {
      await Promise.all(executors.map(dispose));
    } catch (error) {
      if (!stopped) throw error;
    }
    if (stopped) {
      await failureCleanup;
      throw firstFailure;
    }
    return results;
  } finally {
    options.signal?.removeEventListener("abort", onAbort);
  }
}

// src/analysis/step-parallel.ts
function reviveStepResult(step) {
  const plain = step;
  return {
    paramName: step.paramName,
    paramValue: step.paramValue,
    dc: plain.dc && !(plain.dc instanceof DCResult) ? new DCResult(plain.dc.voltageMap, plain.dc.currentMap) : step.dc,
    transient: plain.transient && !(plain.transient instanceof TransientResult) ? new TransientResult(
      plain.transient.time,
      plain.transient.voltageArrays,
      plain.transient.currentArrays
    ) : step.transient,
    ac: plain.ac && !(plain.ac instanceof ACResult) ? new ACResult(
      plain.ac.frequencies,
      plain.ac.voltageArrays,
      plain.ac.currentArrays
    ) : step.ac,
    dcSweep: plain.dcSweep && !(plain.dcSweep instanceof DCSweepResult) ? new DCSweepResult(
      plain.dcSweep.sweepValues,
      plain.dcSweep.voltageArrays,
      plain.dcSweep.currentArrays,
      plain.dcSweep.secondarySweepValues
    ) : step.dcSweep,
    transferFunction: plain.transferFunction && !(plain.transferFunction instanceof TransferFunctionResult) ? new TransferFunctionResult(
      plain.transferFunction.outputNode,
      plain.transferFunction.inputSource,
      plain.transferFunction.transfer,
      plain.transferFunction.inputResistance,
      plain.transferFunction.outputResistance,
      plain.transferFunction.outputSource
    ) : step.transferFunction
  };
}
function singleStepNetlist(netlist, step, value) {
  const replacement = `.step param ${step.param} list ${value}`;
  return netlist.replace(/^\s*\.step\b.*$/im, replacement);
}
function mergeConvergence(target, source) {
  if (!source) return;
  const dcKeys = [
    "newtonIterations",
    "acceptedSolves",
    "rejectedSolves",
    "sourceStepAttempts",
    "sourceStepFailures",
    "gminStepAttempts",
    "gminStepFailures"
  ];
  for (const key of dcKeys) target.dc[key] += source.dc[key];
  target.dc.failure ??= source.dc.failure;
  const transientKeys = [
    "acceptedSteps",
    "rejectedSteps",
    "newtonIterations",
    "nrRetries",
    "lteRetries"
  ];
  for (const key of transientKeys) target.transient[key] += source.transient[key];
  const minimum = source.transient.minimumAcceptedTimestep;
  if (minimum !== null) {
    target.transient.minimumAcceptedTimestep = target.transient.minimumAcceptedTimestep === null ? minimum : Math.min(target.transient.minimumAcceptedTimestep, minimum);
  }
  target.transient.failure ??= source.transient.failure;
}
function siblingModuleUrl(filename) {
  return new URL(filename, import.meta.url);
}
function adaptMessageWorker(worker) {
  return {
    run(task) {
      return new Promise((resolve, reject) => {
        const cleanup = () => {
          worker.removeEventListener?.("message", onBrowserMessage);
          worker.removeEventListener?.("error", onBrowserError);
          worker.off?.("message", onNodeMessage);
          worker.off?.("error", onNodeError);
        };
        const settle = (message) => {
          cleanup();
          if (message.type === "result") resolve(message.result);
          else reject(new Error(message.message ?? "Step worker failed"));
        };
        const onBrowserMessage = (value) => {
          const event = value;
          settle(event.data);
        };
        const onBrowserError = (value) => {
          const event = value;
          cleanup();
          reject(event.error instanceof Error ? event.error : new Error(event.message ?? "Step worker failed to load"));
        };
        const onNodeMessage = (value) => settle(value);
        const onNodeError = (value) => {
          cleanup();
          reject(value);
        };
        worker.addEventListener?.("message", onBrowserMessage);
        worker.addEventListener?.("error", onBrowserError);
        worker.on?.("message", onNodeMessage);
        worker.on?.("error", onNodeError);
        try {
          worker.postMessage({ type: "run", task });
        } catch (error) {
          cleanup();
          reject(error);
        }
      });
    },
    terminate: () => {
      worker.terminate();
    }
  };
}
async function createAutomaticWorker() {
  const globalScope = globalThis;
  if (globalScope.Worker) {
    try {
      return adaptMessageWorker(new Worker(
        new URL("./step-worker-browser.js", import.meta.url),
        { type: "module" }
      ));
    } catch {
      return null;
    }
  }
  try {
    const [{ Worker: Worker2 }, { pathToFileURL }] = await Promise.all([
      import("worker_threads"),
      import("url")
    ]);
    const workerUrl = typeof __filename === "string" ? pathToFileURL(`${__dirname}/step-worker.cjs`) : siblingModuleUrl("step-worker.js");
    return adaptMessageWorker(new Worker2(workerUrl));
  } catch {
    return null;
  }
}
async function solveStepInWorkers(netlist, step, options, warnings, convergence) {
  const workerOptions = options.stepWorkers;
  if (!workerOptions) return null;
  if (options.resolveInclude || options.simulator && options.simulator !== "spice-ts") return null;
  const values = generateStepValues(step);
  const maxWorkers = Math.max(1, Math.min(
    values.length,
    Math.floor(workerOptions.maxWorkers ?? 4)
  ));
  const factory = workerOptions.workerFactory ?? createAutomaticWorker;
  const workers = [];
  for (let index = 0; index < maxWorkers; index++) {
    const worker = await factory(index);
    if (!worker) {
      await Promise.allSettled(workers.map((existing) => Promise.resolve(existing.terminate())));
      return null;
    }
    workers.push(worker);
  }
  if (workerOptions.signal?.aborted) {
    await Promise.allSettled(workers.map((worker) => Promise.resolve(
      worker.terminate(workerOptions.signal.reason)
    )));
    throw workerOptions.signal.reason ?? new Error("Step worker execution aborted");
  }
  const { stepWorkers: _stepWorkers, resolveInclude: _resolveInclude, simulator: _simulator, ...cloneable } = options;
  const tasks = values.map((value, index) => ({
    index,
    netlist: singleStepNetlist(netlist, step, value),
    options: cloneable
  }));
  const outputs = await scheduleStepTasks(tasks, {
    create: (workerIndex) => {
      let terminated = false;
      const terminate = (reason) => {
        if (terminated) return;
        terminated = true;
        return workers[workerIndex].terminate(reason);
      };
      return {
        execute: (task) => workers[workerIndex].run(task),
        cancel: terminate,
        dispose: terminate
      };
    }
  }, {
    maxWorkers,
    signal: workerOptions.signal,
    onComplete: ({ index, result }) => {
      const revived = reviveStepResult(result.steps[0]);
      workerOptions.onComplete?.({ index, result: revived });
    }
  });
  const results = [];
  for (const output of outputs) {
    if (!output.steps?.[0]) throw new Error("Step worker returned no step result");
    results.push(reviveStepResult(output.steps[0]));
    warnings.push(...output.warnings);
    mergeConvergence(convergence, output.convergence);
  }
  return results;
}

// src/simulate.ts
var UnsupportedStreamAnalysisError = class extends InvalidCircuitError {
  code = "UNSUPPORTED_FEATURE";
  details;
  constructor(analysis) {
    super(`simulateStream() does not support '.${analysis}' analysis`);
    this.name = "UnsupportedStreamAnalysisError";
    this.details = { api: "simulateStream", analysis };
  }
};
function withoutSimulator(options) {
  if (!options) return void 0;
  const { simulator: _simulator, ...rest } = options;
  return rest;
}
function selectedExternalSimulator(options) {
  const simulator = options?.simulator;
  if (!simulator || simulator === "spice-ts") return null;
  return createSimulator(simulator);
}
async function simulate(input, options, guard) {
  const simulator = selectedExternalSimulator(options);
  if (simulator) {
    return simulator.simulate(input, withoutSimulator(options));
  }
  let circuit;
  if (typeof input === "string") {
    circuit = await parseAsync(input, options?.resolveInclude);
  } else {
    circuit = input;
  }
  const measures = measureCards(circuit);
  if (circuit.controlScript) {
    return simulateControlScript(circuit, circuit.controlScript, options, guard, measures);
  }
  const compiled = circuit.compile(guard);
  options = withNetlistOptions(compiled.simulationOptions, options);
  const warnings = parseWarnings(circuit);
  const convergence = createConvergenceTelemetry();
  if (options.bypass) {
    warnings.push({
      type: "option",
      message: "bypass: native solver always evaluates nonlinear devices; ngspice evaluation reuse is not implemented. Iteration counts and tolerance-level results may differ."
    });
  }
  validateCircuit(compiled, warnings);
  if (compiled.steps.length > 0) {
    if (measures.length > 0) {
      throw new UnsupportedMeasureError(
        ".meas with .step is not implemented (ngspice measures each step run separately)",
        measures[0].line,
        measures[0].text
      );
    }
    if (compiled.steps.length > 1) {
      throw new InvalidCircuitError(
        "Multiple .step directives are not supported; nested or multi-dimensional stepping is unsupported"
      );
    }
    const parallelResults = typeof input === "string" ? await solveStepInWorkers(input, compiled.steps[0], options, warnings, convergence) : null;
    const stepResults = parallelResults ?? solveStep(compiled, compiled.steps[0], options, warnings, convergence, guard);
    return { steps: stepResults, warnings, convergence };
  }
  const result = solveCompiledAnalyses(compiled, options, warnings, convergence, guard, measures, /* @__PURE__ */ new Map());
  warnUnmeasuredAnalyses(measures, compiled.analyses, warnings);
  return result;
}
function warnUnmeasuredAnalyses(measures, analyses, warnings) {
  const ran = new Set(analyses.map((analysis) => analysis.type));
  for (const type of measuredAnalyses(measures)) {
    if (!ran.has(type)) {
      warnings.push({ type: "measure", message: `.meas ${type} cards were not evaluated: the deck runs no .${type} analysis` });
    }
  }
}
function solveCompiledAnalyses(compiled, options, warnings, convergence, guard, measures, measureValues) {
  const result = { warnings, convergence };
  const measure = (analysis) => {
    if (measures.length === 0) return;
    const plot = measurePlot(analysis, result);
    if (!plot) return;
    const measurements = evaluateMeasureCards(measures, analysis.type, plot, measureValues);
    if (measurements.length > 0) result.measurements = [...result.measurements ?? [], ...measurements];
  };
  for (const analysis of compiled.analyses) {
    switch (analysis.type) {
      case "op": {
        const opts = resolveOptions(options);
        const { result: dcResult } = solveDCOperatingPoint(
          compiled,
          opts,
          void 0,
          convergence,
          "operating-point",
          guard
        );
        guard?.recordResultPoint();
        result.dc = dcResult;
        break;
      }
      case "dc": {
        const opts = resolveOptions(options);
        result.dcSweep = solveDCSweep(compiled, analysis, opts, convergence, guard);
        measure(analysis);
        break;
      }
      case "tran": {
        const opts = resolveOptions(options, analysis.stopTime);
        const seed = transientInitialSolution(compiled, analysis, opts, void 0, convergence, guard);
        result.transient = solveTransient(
          compiled,
          runnableTransient(analysis, options),
          opts,
          seed,
          convergence,
          guard
        );
        measure(analysis);
        break;
      }
      case "ac": {
        const opts = resolveOptions(options);
        const { assembler: dcAsm } = solveDCOperatingPoint(
          compiled,
          opts,
          void 0,
          convergence,
          "operating-point",
          guard
        );
        result.ac = solveAC(compiled, analysis, opts, dcAsm.solution, guard);
        measure(analysis);
        break;
      }
      case "noise": {
        assertNoiseDevicesSupported(compiled);
        const opts = resolveOptions(options);
        const { assembler: dcAsm } = solveDCOperatingPoint(
          compiled,
          opts,
          void 0,
          convergence
        );
        result.noise = solveNoise(compiled, analysis, opts, dcAsm.solution);
        break;
      }
      case "sp": {
        const opts = resolveOptions(options);
        const { assembler: dcAsm } = solveDCOperatingPoint(
          compiled,
          opts,
          void 0,
          convergence,
          "operating-point",
          guard
        );
        result.sParameters = solveSParameters(compiled, analysis, opts, dcAsm.solution, guard);
        break;
      }
      case "disto": {
        assertDistortionSupported(compiled, analysis);
        const opts = resolveOptions(options);
        const diodes = compiled.devices.filter((device) => device instanceof Diode);
        for (const diode of diodes) diode.setDistortionMode(true);
        try {
          const { assembler: dcAsm } = solveDCOperatingPoint(
            compiled,
            opts,
            void 0,
            convergence,
            "operating-point",
            guard
          );
          result.distortion = solveDistortion(
            compiled,
            analysis,
            opts,
            dcAsm.solution,
            guard
          );
        } finally {
          for (const diode of diodes) diode.setDistortionMode(false);
        }
        break;
      }
      case "tf": {
        const opts = resolveOptions(options);
        result.transferFunction = solveTransferFunction(
          compiled,
          analysis,
          opts,
          convergence
        );
        break;
      }
      case "sens": {
        const opts = resolveOptions(options);
        result.sensitivity = solveSensitivity(
          compiled,
          analysis,
          opts,
          convergence
        );
        break;
      }
    }
  }
  for (const analysis of compiled.poleZeroAnalyses) {
    const opts = resolveOptions(options);
    result.poleZero = solvePoleZero(compiled, analysis, opts, convergence);
  }
  return result;
}
var ANALYSIS_RESULT_FIELDS = [
  "dc",
  "dcSweep",
  "transient",
  "ac",
  "noise",
  "sParameters",
  "distortion",
  "transferFunction",
  "poleZero",
  "sensitivity"
];
function simulateControlScript(circuit, script, options, guard, measures) {
  const warnings = parseWarnings(circuit);
  const convergence = createConvergenceTelemetry();
  const measureValues = /* @__PURE__ */ new Map();
  const deckAnalyses = [...circuit.analyses];
  const deckPoleZero = [...circuit.poleZeroAnalyses];
  let operatingState;
  const solve = (analyses, poleZero) => {
    const savedAnalyses = circuit.analyses.splice(0, circuit.analyses.length, ...analyses);
    const savedPoleZero = circuit.poleZeroAnalyses.splice(0, circuit.poleZeroAnalyses.length, ...poleZero);
    let compiled;
    try {
      compiled = circuit.compile(guard);
    } finally {
      circuit.analyses.splice(0, circuit.analyses.length, ...savedAnalyses);
      circuit.poleZeroAnalyses.splice(0, circuit.poleZeroAnalyses.length, ...savedPoleZero);
    }
    compiled = { ...compiled, analyses: [...analyses], poleZeroAnalyses: [...poleZero] };
    validateCircuit(compiled, warnings);
    const resolved = withNetlistOptions(compiled.simulationOptions, options);
    operatingState = void 0;
    const result2 = solveCompiledAnalyses(compiled, resolved, warnings, convergence, guard, measures, measureValues);
    operatingState = analyses.length === 1 && poleZero.length === 0 ? controlOperatingState(compiled, analyses[0], result2) : void 0;
    return result2;
  };
  const runDeck = () => [
    ...deckAnalyses.map((directive) => ({ directive, result: solve([directive], []) })),
    ...deckPoleZero.map((analysis) => ({ directive: { type: "pz" }, result: solve([], [analysis]) }))
  ];
  const unsupported2 = (command, reason, line) => new UnsupportedControlCommandError(command, reason, line.lineNumber, line.text);
  const host = {
    runAnalysis(tokens, line) {
      const directive = parseControlAnalysisCard(tokens, line.lineNumber, line.text);
      return { directive, result: solve([directive], []) };
    },
    runDeck(line) {
      if (deckAnalyses.length === 0 && deckPoleZero.length === 0) {
        throw new ControlScriptError("run: the deck has no analysis cards", line.lineNumber, line.text);
      }
      return runDeck();
    },
    alterInstance(device, parameter, values, line) {
      const reason = circuit.alterInstance(device, parameter, values);
      if (reason !== void 0) throw unsupported2("alter", reason, line);
    },
    alterModel(model, parameter, value, line) {
      const reason = circuit.alterModel(model, parameter, value);
      if (reason !== void 0) throw unsupported2("altermod", reason, line);
    },
    parameterVector: (device, parameter) => deviceOutputVector(operatingState, device, parameter) ?? circuit.parameterVector(device, parameter),
    setOptions(tokens, line) {
      circuit.setSimulationOptions(parseControlOptions(tokens, line.lineNumber, line.text));
    }
  };
  const restore = circuit.snapshotControlState();
  let outcome;
  let finalRuns;
  try {
    outcome = runControlScript(script, host);
    finalRuns = outcome.quit ? [] : runDeck();
  } finally {
    restore();
  }
  for (const message of outcome.warnings) warnings.push({ type: "control", message });
  const result = {
    warnings,
    convergence,
    control: { runs: outcome.runs, output: outcome.output, quit: outcome.quit, measurements: outcome.measurements }
  };
  const latestMeasurements = /* @__PURE__ */ new Map();
  for (const { result: run } of [...outcome.runs, ...finalRuns]) {
    for (const field of ANALYSIS_RESULT_FIELDS) {
      if (run[field] !== void 0) Object.assign(result, { [field]: run[field] });
    }
    for (const measurement of run.measurements ?? []) latestMeasurements.delete(measurement.analysis);
    for (const measurement of run.measurements ?? []) {
      latestMeasurements.set(measurement.analysis, [...latestMeasurements.get(measurement.analysis) ?? [], measurement]);
    }
  }
  if (latestMeasurements.size > 0) result.measurements = [...latestMeasurements.values()].flat();
  const seen = /* @__PURE__ */ new Set();
  result.warnings = warnings.filter((warning) => {
    const key = `${warning.type}:${warning.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  return result;
}
async function* simulateStream(input, options) {
  if (selectedExternalSimulator(options)) {
    const result = await simulate(input, options);
    yield* streamFromSimulationResult(result);
    return;
  }
  let circuit;
  if (typeof input === "string") {
    circuit = await parseAsync(input, options?.resolveInclude);
  } else {
    circuit = input;
  }
  if (circuit.controlScript) throw new UnsupportedStreamAnalysisError("control");
  const compiled = circuit.compile();
  options = withNetlistOptions(compiled.simulationOptions, options);
  const warnings = [];
  validateCircuit(compiled, warnings);
  for (const type of ["disto", "sp"]) {
    if (compiled.analyses.some((analysis) => analysis.type === type)) {
      throw new UnsupportedStreamAnalysisError(type);
    }
  }
  if (compiled.steps.length > 0) {
    for (const event of streamWithSteps(compiled, compiled.steps[0], options)) {
      yield event.point;
    }
    return;
  }
  for (const analysis of compiled.analyses) {
    switch (analysis.type) {
      case "tran": {
        const opts = resolveOptions(options, analysis.stopTime);
        const seed = transientInitialSolution(compiled, analysis, opts);
        yield* streamTransient(compiled, runnableTransient(analysis, options), opts, seed);
        break;
      }
      case "ac": {
        const opts = resolveOptions(options);
        const { assembler: dcAsm } = solveDCOperatingPoint(compiled, opts);
        yield* streamAC(compiled, analysis, opts, dcAsm.solution);
        break;
      }
    }
  }
}
async function* simulateStepStream(input, options) {
  if (selectedExternalSimulator(options)) {
    const result = await simulate(input, options);
    if (result.steps) {
      for (let stepIndex = 0; stepIndex < result.steps.length; stepIndex++) {
        const step = result.steps[stepIndex];
        yield* streamEventsFromStepResult(step, stepIndex, step.paramName, step.paramValue);
      }
    } else {
      yield* streamEventsFromStepResult(result, 0, "", 0);
    }
    return;
  }
  let circuit;
  if (typeof input === "string") {
    circuit = await parseAsync(input, options?.resolveInclude);
  } else {
    circuit = input;
  }
  if (circuit.controlScript) throw new UnsupportedStreamAnalysisError("control");
  const compiled = circuit.compile();
  options = withNetlistOptions(compiled.simulationOptions, options);
  const warnings = [];
  validateCircuit(compiled, warnings);
  if (compiled.steps.length > 0) {
    yield* streamWithSteps(compiled, compiled.steps[0], options);
  } else {
    for (const analysis of compiled.analyses) {
      switch (analysis.type) {
        case "tran": {
          const opts = resolveOptions(options, analysis.stopTime);
          const seed = transientInitialSolution(compiled, analysis, opts);
          for (const point of streamTransient(compiled, runnableTransient(analysis, options), opts, seed)) {
            yield { stepIndex: 0, paramName: "", paramValue: 0, point };
          }
          break;
        }
        case "ac": {
          const opts = resolveOptions(options);
          const { assembler: dcAsm } = solveDCOperatingPoint(compiled, opts);
          for (const point of streamAC(compiled, analysis, opts, dcAsm.solution)) {
            yield { stepIndex: 0, paramName: "", paramValue: 0, point };
          }
          break;
        }
      }
    }
  }
}
function* streamWithSteps(compiled, step, options) {
  const values = generateStepValues(step);
  const target = resolveStepTarget(compiled, step);
  let prevDCSolution;
  try {
    for (let stepIndex = 0; stepIndex < values.length; stepIndex++) {
      const value = values[stepIndex];
      target.set(value);
      if (target.resetsContinuation) prevDCSolution = void 0;
      for (const analysis of compiled.analyses) {
        switch (analysis.type) {
          case "tran": {
            const opts = resolveOptions(options, analysis.stopTime);
            const seed = transientInitialSolution(compiled, analysis, opts, prevDCSolution);
            if (!analysis.useInitialConditions) prevDCSolution = new Float64Array(seed);
            for (const point of streamTransient(compiled, runnableTransient(analysis, options), opts, seed)) {
              yield { stepIndex, paramName: target.paramName, paramValue: value, point };
            }
            break;
          }
          case "ac": {
            const opts = resolveOptions(options);
            const { assembler: dcAsm } = solveDCOperatingPoint(compiled, opts, prevDCSolution);
            prevDCSolution = new Float64Array(dcAsm.solution);
            for (const point of streamAC(compiled, analysis, opts, dcAsm.solution)) {
              yield { stepIndex, paramName: target.paramName, paramValue: value, point };
            }
            break;
          }
        }
      }
    }
  } finally {
    target.restore();
  }
}
function parseWarnings(circuit) {
  return circuit.parseWarnings.map((message) => ({ type: "parse", message }));
}
function validateCircuit(compiled, warnings) {
  if (compiled.nodeCount === 0 && !compiled.devices.some((device) => device.eventDriven !== void 0)) {
    throw new InvalidCircuitError("Circuit has no nodes");
  }
  if (compiled.analyses.length === 0 && compiled.poleZeroAnalyses.length === 0) {
    throw new InvalidCircuitError("No analysis command specified");
  }
  if (compiled.steps.length > 0 && compiled.poleZeroAnalyses.length > 0) {
    throw new InvalidCircuitError(".step cannot be combined with .pz");
  }
  if (compiled.steps.length > 0 && compiled.analyses.some((analysis) => analysis.type === "sens")) {
    throw new InvalidCircuitError(".step cannot be combined with .sens");
  }
  if (compiled.steps.length > 0 && compiled.analyses.some((analysis) => analysis.type === "disto")) {
    throw new InvalidCircuitError(".step cannot be combined with .disto");
  }
  if (compiled.steps.length > 0 && compiled.analyses.some((analysis) => analysis.type === "sp")) {
    throw new InvalidCircuitError(".step cannot be combined with .sp");
  }
  for (const device of compiled.devices) {
    for (const message of device.modelWarnings ?? []) {
      warnings.push({ type: "model", message });
    }
  }
}
function transientInitialSolution(compiled, analysis, options, initialGuess, convergence, guard) {
  if (analysis.useInitialConditions) return computeUICInitialSolution(compiled);
  return solveDCOperatingPoint(
    compiled,
    options,
    initialGuess,
    convergence,
    "transient",
    guard
  ).assembler.solution;
}
function* streamFromSimulationResult(result) {
  if (result.steps) {
    for (const step of result.steps) {
      yield* streamPointsFromStepResult(step);
    }
    return;
  }
  yield* streamPointsFromStepResult(result);
}
function* streamPointsFromStepResult(result) {
  if (result.transient) {
    const voltages = result.transient.voltages;
    const currents = result.transient.currents;
    for (let i = 0; i < result.transient.time.length; i++) {
      yield {
        time: result.transient.time[i],
        voltages: mapAtIndex(voltages, i),
        currents: mapAtIndex(currents, i)
      };
    }
  }
  if (result.ac) {
    const voltages = result.ac.voltages;
    const currents = result.ac.currents;
    for (let i = 0; i < result.ac.frequencies.length; i++) {
      yield {
        frequency: result.ac.frequencies[i],
        voltages: mapAtIndex(voltages, i),
        currents: mapAtIndex(currents, i)
      };
    }
  }
}
function* streamEventsFromStepResult(result, stepIndex, paramName, paramValue) {
  for (const point of streamPointsFromStepResult(result)) {
    yield { stepIndex, paramName, paramValue, point };
  }
}
function mapAtIndex(arrays, index) {
  const result = /* @__PURE__ */ new Map();
  for (const [name, values] of arrays) {
    result.set(name, values[index]);
  }
  return result;
}
function* streamTransient(compiled, analysis, options, initialSolution) {
  const driver = createDriverFromCompiled(compiled, options, {
    stopTime: analysis.stopTime,
    timestep: analysis.timestep,
    // SPICE convention: when `.tran` doesn't supply `tmax` (4th arg), bound
    // dt by `min(tstep, tstop/50)` — shared with solveTransient and
    // createTransientSim so every entry point steps the same grid.
    maxTimestep: transientStepCap(analysis),
    initialSolution,
    useInitialConditions: analysis.useInitialConditions
  });
  try {
    const initialStep = driver.peekInitialStep();
    if (isSavedTransientPoint(analysis, initialStep.time)) yield initialStep;
    while (!driver.isDone) {
      const step = driver.advance();
      if (isSavedTransientPoint(analysis, step.time)) yield step;
    }
  } finally {
    driver.dispose();
  }
}
function* streamAC(compiled, analysis, options, dcSolution) {
  const { devices, nodeCount, branchCount, nodeNames, branchNames } = compiled;
  const assembler = new MNAAssembler(nodeCount, branchCount);
  assembler.solution.set(dcSolution);
  const ctx = assembler.getStampContext();
  for (const device of devices) device.stamp(ctx);
  for (const device of devices) device.stampDynamic?.(ctx);
  for (let i = 0; i < nodeCount; i++) {
    assembler.G.add(i, i, options.gmin ?? 1e-12);
  }
  const G = assembler.G;
  const C = assembler.C;
  const frequencies = frequencyGrid(analysis, options.reltol, "ac");
  const { csc: gCsc } = toCsc(G);
  const { csc: cCsc } = toCsc(C);
  const solver = new ComplexSparseSolver();
  solver.analyzePattern(
    gCsc,
    cCsc,
    createMatrixVariableIdentities(nodeNames, branchNames)
  );
  const { real: bReal, imaginary: bImag } = buildACRHS(compiled);
  for (const freq of frequencies) {
    const omega = 2 * Math.PI * freq;
    solver.factorize(gCsc, cCsc, omega);
    const [xReal, xImag] = solver.solve(bReal, bImag);
    const voltages = /* @__PURE__ */ new Map();
    for (let i = 0; i < nodeNames.length; i++) {
      const re = xReal[i], im = xImag[i];
      voltages.set(nodeNames[i], {
        magnitude: Math.sqrt(re * re + im * im),
        phase: Math.atan2(im, re) * 180 / Math.PI
      });
    }
    const currents = /* @__PURE__ */ new Map();
    for (let i = 0; i < branchNames.length; i++) {
      const re = xReal[nodeCount + i], im = xImag[nodeCount + i];
      currents.set(branchNames[i], {
        magnitude: Math.sqrt(re * re + im * im),
        phase: Math.atan2(im, re) * 180 / Math.PI
      });
    }
    yield { frequency: freq, voltages, currents };
  }
}

export {
  simulate,
  simulateStream,
  simulateStepStream
};
//# sourceMappingURL=chunk-BLWJHVLO.js.map