/**
 * Context provided to device models during MNA matrix assembly.
 *
 * Devices use `stampG`, `stampB`, and `stampC` to contribute their
 * conductance, excitation, and dynamic (capacitance) terms to the system.
 */
interface StampContext {
    /** Add a value to the conductance matrix G at (row, col). Row/col are node or branch indices. */
    stampG(row: number, col: number, value: number): void;
    /** Add a value to the right-hand-side vector b at the given row. */
    stampB(row: number, value: number): void;
    /** Add a value to the dynamic (capacitance) matrix C at (row, col). */
    stampC(row: number, col: number, value: number): void;
    /** Get the current solution voltage at a node index (-1 for ground returns 0). */
    getVoltage(node: number): number;
    /** Get the current solution current for a branch index. */
    getCurrent(branch: number): number;
    /** Current simulation time in seconds. */
    time: number;
    /** Current timestep in seconds (0 for DC). */
    dt: number;
    /** Total number of non-ground nodes in the system. */
    numNodes: number;
    /** Scale factor for source values (used during DC sweep ramping). */
    sourceScale: number;
    /** Use an explicit DC value instead of a transient waveform when available. */
    useDcSourceValue: boolean;
    /**
     * Device minimum conductance (ngspice `CKTgmin`) to add across pn junctions.
     * Absent means {@link DEVICE_GMIN}; the DC operating point's true gmin
     * stepping raises it temporarily.
     */
    gmin?: number;
}
/**
 * Receives breakpoints a device creates while accepting a transient
 * timepoint (ngspice CKTsetBreak from DEVaccept).
 */
interface TransientBreakpointSink {
    /** Request a breakpoint at absolute time `time`; times not after the accepted point are ignored. */
    schedule(time: number): void;
}
/**
 * Integration rule for one transient step, after the order-1 bootstrap at
 * starts, breakpoints and history resets has been applied.
 */
interface ChargeIntegration {
    readonly method: 'euler' | 'trapezoidal' | 'gear2';
    /** Step being solved, t(n+1) - t(n). */
    readonly dt: number;
    /** Previous accepted step t(n) - t(n-1); required for `gear2`. */
    readonly prevDt?: number;
}
/**
 * Inputs of the ngspice charge truncation-error estimate (cktterr.c CKTterr)
 * for one converged trial timepoint.
 */
interface ChargeTruncation {
    /**
     * Step history, newest first (ngspice CKTdeltaOld): the trial step
     * t(n+1) - t(n), then t(n) - t(n-1) and t(n-1) - t(n-2).
     */
    readonly deltas: readonly [number, number, number];
    readonly reltol: number;
    /** Current tolerance (A). */
    readonly abstol: number;
    /** Charge tolerance (C). */
    readonly chgtol: number;
    readonly trtol: number;
    /**
     * Integration order CKTterr evaluates the error at (ngspice CKTorder).
     * Absent: the order of the step's own rule. ngspice dctran.c repeats
     * CKTtrunc at order 2 after an accepted order-1 step to decide whether to
     * raise the order.
     */
    readonly order?: 1 | 2;
}
/** Newton convergence tolerances (ngspice RELTOL, ABSTOL, VNTOL). */
interface ConvergenceTolerances {
    readonly reltol: number;
    /** Current tolerance (A). */
    readonly abstol: number;
    /** Voltage tolerance (V). */
    readonly vntol: number;
}
/** A frequency-independent contribution to the complex AC right-hand side. */
type ACRHSContribution = {
    kind: 'branch';
    branch: number;
    magnitude: number;
    phase: number;
} | {
    kind: 'node-pair';
    positiveNode: number;
    negativeNode: number;
    magnitude: number;
    phase: number;
};
/**
 * Interface that all device models must implement.
 *
 * Each device stamps its contributions into the MNA system via
 * the {@link StampContext} during each Newton-Raphson iteration.
 */
interface DeviceModel {
    /** Device instance name (e.g., `'R1'`, `'M1'`). */
    readonly name: string;
    /** Node indices this device is connected to (-1 for ground). */
    readonly nodes: number[];
    /** Branch indices owned by this device (e.g., voltage sources, inductors). */
    readonly branches: number[];
    /** Stamp the device's DC/resistive contributions into the MNA system. */
    stamp(ctx: StampContext): void;
    /**
     * Stamp the small-signal conductances used by AC, noise and pole-zero
     * analyses in place of {@link stamp} (e.g. a resistor's `ac=` value, ngspice
     * RESacload). Absent means `stamp` is used.
     */
    stampSmallSignal?(ctx: StampContext): void;
    /** Restrict a Newton candidate while preserving its global step direction. */
    limitNewtonStep?(previous: Float64Array, candidate: Float64Array): number;
    /** Stamp dynamic (reactive) contributions for AC and transient analysis. */
    stampDynamic?(ctx: StampContext): void;
    /**
     * False when `stampDynamic` stamps nothing for this instance (e.g. a diode
     * without CJO, CJSW or TT). Transient integration then treats the device
     * as purely static and uses the exact accepted static-current history.
     */
    readonly storesCharge?: boolean;
    /**
     * Non-fatal model-card diagnostics found while building the device, such as
     * a parameter ngspice-47 warns about and ignores. Surfaced as `'model'`
     * simulation warnings.
     */
    readonly modelWarnings?: readonly string[];
    /**
     * True when the device integrates its own nonlinear charge in transient
     * analysis (ngspice NIintegrate on q(v)) through {@link stampTransientCharge}
     * instead of stamping C(v) via {@link stampDynamic}. `stampDynamic` is then
     * still used for AC, noise and other small-signal analyses.
     */
    readonly integratesTransientCharge?: boolean;
    /**
     * Stamp the integrated charge companion (G and b) for one transient Newton
     * iteration. Called after `stamp` with the same context.
     */
    stampTransientCharge?(ctx: StampContext, integration: ChargeIntegration): void;
    /**
     * Stamp the charge current accepted at the last committed timepoint as a
     * constant current. Used to build the trapezoidal history of other
     * reactive elements that share its nodes.
     */
    stampAcceptedChargeCurrent?(ctx: StampContext): void;
    /** Stamp AC small-signal contributions at angular frequency omega. */
    stampAC?(ctx: StampContext, omega: number): void;
    /**
     * Commit state from a transient timepoint after NR and LTE acceptance.
     * `breakpoints` (transient analysis only) schedules breakpoints the
     * accepted state creates later in the run (ngspice DEVaccept + CKTsetBreak).
     */
    acceptTransientStep?(ctx: StampContext, breakpoints?: TransientBreakpointSink): void;
    /**
     * ngspice DEVtrunc: the largest next timestep the truncation error of the
     * device's integrated charges allows, evaluated at the converged but not yet
     * accepted solution in `ctx`. Must not change accepted state.
     */
    truncateTransientStep?(ctx: StampContext, truncation: ChargeTruncation): number;
    /**
     * True when {@link truncateTransientStep} bounds every charge the device
     * stores, as the device's ngspice DEVtrunc does. ngspice-47 controls the
     * transient timestep with CKTtrunc alone (no node-voltage truncation), so
     * the node-voltage LTE skips nodes on which every charge-storing device
     * sets this.
     */
    readonly truncationCoversCharges?: boolean;
    /**
     * True when the device limits every junction voltage it reads relative to
     * its previous Newton iterate (ngspice DEVpnjlim). Transient Newton leaves
     * the nodes of such devices undamped, because a damped node cannot follow
     * the limited junction and the iterate-relative limit would ratchet away.
     */
    readonly limitsOwnJunctions?: boolean;
    /**
     * True when transient Newton must not damp the device's nodes, because
     * ngspice neither damps node voltages nor limits this device (ASRC `B`
     * sources): a capped node cannot reach the large first-step jump of a UIC
     * start, so Newton ratchets to the timestep floor.
     */
    readonly undampedNodes?: boolean;
    /**
     * Start a transient Newton solve at a new or retried timepoint: limit the
     * first iterate against the last accepted junction state (ngspice
     * MODEINITPRED), not against an iterate of a rejected attempt. `dt` is the
     * step of the attempt (ngspice CKTdelta) and `accepted` the solution at the
     * last accepted point it starts from.
     */
    beginTransientNewton?(dt: number, accepted: Float64Array): void;
    /**
     * Receive the undamped transient Newton solution. A self-limiting device
     * limits its next junction voltage from this solve, not from the damped
     * iterate: node damping may hold a terminal back, and limiting against that
     * lagging node would ratchet the junction away from the Newton step.
     */
    observeTransientNewton?(solution: Float64Array): void;
    /**
     * Whether the last `stamp` limited a junction (ngspice CKTnoncon). Newton
     * cannot be declared converged on an iterate that was limited, because the
     * stamp then linearised a voltage the solution does not have.
     */
    limitedLastStamp?(): boolean;
    /**
     * ngspice DEVconvTest: whether the device's own quantity has converged at
     * the Newton solution `solution`, beyond the node-voltage test. Newton
     * cannot be declared converged while any device returns false.
     */
    convergenceTest?(solution: Float64Array, tolerances: ConvergenceTolerances): boolean;
    /**
     * Nodes whose voltage the device sets algebraically from other unknowns
     * (e.g. the output of a grounded B-source `V=` expression). ngspice has no
     * truncation error on them, so the transient node-voltage LTE skips them.
     */
    readonly algebraicNodes?: readonly number[];
    /**
     * Start a DC operating point solve (ngspice MODEINITJCT): a device with
     * state chosen at the start of the operating point (e.g. a switch's ON/OFF
     * flag) re-initialises it here.
     */
    beginOperatingPoint?(): void;
    /**
     * Receive the transient TSTEP and TSTOP (ngspice CKTstep/CKTfinalTime) used
     * by SPICE waveform defaults (e.g. zero PULSE TR/TF, SFFM/AM frequencies).
     * `stopTime` is undefined for an open-ended stepping run.
     */
    setTransientTimestep?(timestep: number, stopTime?: number): void;
    /** Clear device-owned transient history before restarting at t=0. */
    resetTransient?(): void;
    /** Whether this device requires Newton-Raphson iteration (nonlinear). */
    readonly isNonlinear: boolean;
    /** Return this device's AC right-hand-side contribution, or null. */
    getACExcitation?(): ACRHSContribution | null;
    /** Set the device's primary parameter value (resistance, capacitance, etc.). */
    setParameter?(value: number): void;
    /** Get the device's primary parameter value. */
    getParameter?(): number;
    /** Apply a circuit temperature in degrees Celsius to temperature-sensitive behavior. */
    setTemperature?(value: number): void;
    /** Return the currently applied circuit temperature in degrees Celsius. */
    getTemperature?(): number;
    /**
     * Return times in [currentTime, stopTime] at which this device has a
     * discontinuity in its waveform or its derivatives. The transient driver
     * uses these as breakpoints — it will step exactly to each one, reset
     * integration history, and cut dt. Optional; devices without
     * discontinuities (resistors, capacitors, diodes, MOSFETs with DC gates)
     * should omit this method.
     */
    getBreakpoints?(stopTime: number): number[];
    /**
     * The XSPICE event-driven network of the circuit (ngspice evt/), present on
     * one compiled device when the circuit has digital code-model instances.
     */
    readonly eventDriven?: EventDrivenNetwork;
}
/**
 * How the analog solvers drive the XSPICE event-driven network: the
 * operating point (ngspice EVTop) and the transient coordination of
 * dctran.c (EVTnext_time/EVTdequeue/EVTiter before a step, EVTbackup on a
 * rejected step, EVTcall_hybrids and EVTaccept after an accepted one).
 */
interface EventDrivenNetwork {
    /**
     * Alternate event iterations with `solveAnalog` (the analog operating
     * point; `first` is the first solve) until no event output changes.
     */
    operatingPoint(solveAnalog: (first: boolean) => void): void;
    /** Start transient event processing after the operating point; `breakpoint` is CKTsetBreak. */
    beginTransient(breakpoint: (time: number) => void, minBreak: number): void;
    /** EVTnext_time: the earliest queued event, or Infinity. */
    nextEventTime(): number;
    /** EVTdequeue + EVTiter at event time `time`; `now` is the last accepted analog time (CKTtime). */
    processEvents(time: number, now: number): void;
    /** EVTbackup: drop every event processed after `time`. */
    backup(time: number): void;
    /** An accepted point: EVTcall_hybrids (unless the first step), then EVTaccept. */
    acceptStep(time: number, callHybrids: boolean): void;
}

/**
 * Base class for all spice-ts errors.
 */
declare class SpiceError extends Error {
    constructor(message: string);
}
/**
 * Thrown when a netlist cannot be parsed due to syntax errors.
 *
 * Contains the line number and raw text of the offending line.
 */
declare class ParseError extends SpiceError {
    /** 1-based line number where the error occurred */
    readonly line: number;
    /** Raw text of the line that caused the error */
    readonly context: string;
    constructor(message: string, 
    /** 1-based line number where the error occurred */
    line: number, 
    /** Raw text of the line that caused the error */
    context: string);
}
/**
 * Thrown when the circuit structure is invalid (e.g., no nodes or no analysis command).
 */
declare class InvalidCircuitError extends SpiceError {
    constructor(message: string);
}
/**
 * Thrown when the MNA system matrix is singular and cannot be solved.
 *
 * Typically indicates a topology error such as a voltage source loop
 * or a floating node.
 */
interface MatrixVariableIdentity {
    /** Whether this MNA unknown is a node voltage or branch current. */
    kind: 'node' | 'branch';
    /** Circuit-level node or branch/source name. */
    name: string;
}
declare class SingularMatrixError extends SpiceError {
    /** Node names involved in the singularity */
    readonly involvedNodes: string[];
    /** Branch or source names involved in the singularity */
    readonly involvedBranches: string[];
    /** Zero-based MNA matrix index of the failed pivot */
    readonly pivotIndex?: number | undefined;
    constructor(message: string, 
    /** Node names involved in the singularity */
    involvedNodes: string[], 
    /** Branch or source names involved in the singularity */
    involvedBranches?: string[], 
    /** Zero-based MNA matrix index of the failed pivot */
    pivotIndex?: number | undefined);
    /** Build a bounded diagnostic directly from the failed matrix variable. */
    static atPivot(pivotIndex: number, variables?: readonly MatrixVariableIdentity[]): SingularMatrixError;
}
/** Discriminator for {@link ConvergenceError} subclasses. */
type ConvergenceFailureKind = 'nr-divergence' | 'lte-cascade' | 'dt-floor';
/**
 * Thrown when Newton-Raphson iteration fails to converge within the
 * allowed number of iterations, when LTE rejects too many steps in a row,
 * or when the adaptive timestep shrinks below the floor.
 *
 * Contains diagnostic information including the oscillating nodes,
 * the last two solution vectors, the timestep and GMIN value in effect,
 * and a `kind` discriminator identifying the failure mode.
 */
declare class ConvergenceError extends SpiceError {
    /** Simulation time at which convergence failed (undefined for DC) */
    readonly time: number | undefined;
    /** Nodes that were oscillating at the time of failure */
    readonly oscillatingNodes: string[];
    /** Solution vector from the last iteration */
    readonly lastSolution: Float64Array;
    /** Solution vector from the second-to-last iteration */
    readonly prevSolution: Float64Array;
    /** Timestep in effect when the failure occurred (undefined for DC) */
    readonly dt?: number | undefined;
    /** GMIN value in effect at the time of failure */
    readonly gmin?: number | undefined;
    readonly kind: ConvergenceFailureKind;
    /** Bounded counters accumulated before this terminal failure. */
    convergence?: ConvergenceTelemetry;
    constructor(message: string, 
    /** Simulation time at which convergence failed (undefined for DC) */
    time: number | undefined, 
    /** Nodes that were oscillating at the time of failure */
    oscillatingNodes: string[], 
    /** Solution vector from the last iteration */
    lastSolution: Float64Array, 
    /** Solution vector from the second-to-last iteration */
    prevSolution: Float64Array, 
    /** Failure mode discriminator. Defaults to `'nr-divergence'`. */
    kind?: ConvergenceFailureKind, 
    /** Timestep in effect when the failure occurred (undefined for DC) */
    dt?: number | undefined, 
    /** GMIN value in effect at the time of failure */
    gmin?: number | undefined);
}
/**
 * Thrown during transient analysis when the adaptive timestep shrinks
 * below the minimum threshold (see `MIN_TIMESTEP` in `transient-driver.ts`).
 *
 * Subclass of {@link ConvergenceError} with `kind === 'dt-floor'`.
 */
declare class TimestepTooSmallError extends ConvergenceError {
    /** The timestep that was too small */
    readonly timestep: number;
    constructor(
    /** Simulation time at which the error occurred */
    time: number, 
    /** The timestep that was too small */
    timestep: number, convergence?: ConvergenceTelemetry);
}
/**
 * Thrown when a circular dependency is detected in `.include`/`.lib`
 * directives or subcircuit instantiation.
 */
declare class CycleError extends SpiceError {
    /** The dependency chain that forms the cycle */
    readonly chain: string[];
    constructor(
    /** The dependency chain that forms the cycle */
    chain: string[]);
}
/**
 * Thrown when a MOSFET model card selects a `LEVEL` that spice-ts does not
 * implement (for example MOS level 7). Such cards used to run the
 * Level-1 equations silently.
 */
declare class UnsupportedModelLevelError extends InvalidCircuitError {
    /** Instance name, e.g. `M1` */
    readonly deviceName: string;
    /** Model card name, when the instance was compiled from a netlist */
    readonly modelName: string | undefined;
    /** Requested `LEVEL` value */
    readonly level: number;
    /** Levels spice-ts implements for this device kind */
    readonly supportedLevels: readonly number[];
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_LEVEL";
    constructor(
    /** Instance name, e.g. `M1` */
    deviceName: string, 
    /** Model card name, when the instance was compiled from a netlist */
    modelName: string | undefined, 
    /** Requested `LEVEL` value */
    level: number, 
    /** Levels spice-ts implements for this device kind */
    supportedLevels: readonly number[]);
}
/**
 * Thrown when a MOSFET model card selects, through its `VERSION=` string, a revision of a
 * supported `LEVEL` that spice-ts does not implement. ngspice picks BSIM3v0/v1 for
 * `LEVEL=8/49 VERSION=3.0/3.1`; spice-ts implements the BSIM3v32 (3.2.x) and default BSIM3
 * 3.3 revisions only and never runs those cards with other equations silently.
 */
declare class UnsupportedModelVersionError extends InvalidCircuitError {
    /** Instance name, e.g. `M1` */
    readonly deviceName: string;
    /** Model card name, when the instance was compiled from a netlist */
    readonly modelName: string | undefined;
    /** Model `LEVEL` value */
    readonly level: number;
    /** Requested `VERSION=` string */
    readonly version: string;
    /** Version prefixes spice-ts implements for this level */
    readonly supportedVersions: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_VERSION";
    constructor(
    /** Instance name, e.g. `M1` */
    deviceName: string, 
    /** Model card name, when the instance was compiled from a netlist */
    modelName: string | undefined, 
    /** Model `LEVEL` value */
    level: number, 
    /** Requested `VERSION=` string */
    version: string, 
    /** Version prefixes spice-ts implements for this level */
    supportedVersions: readonly string[]);
}
/**
 * Thrown when a model registered through the Circuit API, a subcircuit body
 * or the JSON protocol declares a `.model` type that no spice-ts device
 * implements. The netlist parser raises the {@link ParseError} subclass
 * `UnsupportedModelTypeError` (same `code`) for the same condition, with a
 * line number.
 */
declare class UnsupportedCircuitModelTypeError extends InvalidCircuitError {
    /** Model name */
    readonly modelName: string;
    /** Upper-cased model type */
    readonly modelType: string;
    /** Model types spice-ts implements */
    readonly supportedTypes: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_TYPE";
    constructor(
    /** Model name */
    modelName: string, 
    /** Upper-cased model type */
    modelType: string, 
    /** Model types spice-ts implements */
    supportedTypes: readonly string[]);
}
/**
 * Thrown when an instance references a model whose type belongs to another
 * device kind, e.g. a MOSFET (`M`) card naming an `NPN` model. ngspice rejects
 * these; simulating them would silently run the wrong device equations.
 */
declare class ModelTypeMismatchError extends InvalidCircuitError {
    /** Instance name, e.g. `M1` */
    readonly deviceName: string;
    /** SPICE instance letter, e.g. `M` */
    readonly deviceKind: string;
    /** Referenced model name */
    readonly modelName: string;
    /** Upper-cased type of the referenced model */
    readonly modelType: string;
    /** Model types this device kind accepts */
    readonly expectedTypes: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "MODEL_TYPE_MISMATCH";
    constructor(
    /** Instance name, e.g. `M1` */
    deviceName: string, 
    /** SPICE instance letter, e.g. `M` */
    deviceKind: string, 
    /** Referenced model name */
    modelName: string, 
    /** Upper-cased type of the referenced model */
    modelType: string, 
    /** Model types this device kind accepts */
    expectedTypes: readonly string[]);
}
/**
/**
 * Thrown when a device instance or its model card sets a parameter that
 * ngspice-47 honours (or that the selected device model does not define) but
 * spice-ts does not implement, e.g. the diode sidewall resistance `RSW` or a
 * BSIM1 card's `VTO`. Such parameters used to be accepted and silently ignored.
 */
declare class UnsupportedModelParameterError extends InvalidCircuitError {
    /** Instance name, e.g. `D1` (empty when the model card itself is rejected) */
    readonly deviceName: string;
    /** Parameter name as written on the card */
    readonly parameter: string;
    /** What the parameter does in ngspice and why it cannot be simulated */
    readonly reason: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_PARAMETER";
    /** Model card name, when known */
    readonly modelName: string | undefined;
    /** Device model, e.g. `BSIM1`, when known */
    readonly model: string | undefined;
    constructor(
    /** Instance name, e.g. `D1` (empty when the model card itself is rejected) */
    deviceName: string, 
    /** Parameter name as written on the card */
    parameter: string, 
    /** What the parameter does in ngspice and why it cannot be simulated */
    reason: string, context?: {
        modelName?: string;
        model?: string;
    });
}
/**
 * Thrown when a circuit temperature other than the nominal one (`.options
 * TEMP`, `.step TEMP`) reaches a device, or a model parameter, whose ngspice
 * temperature law spice-ts does not implement. Such devices used to run at
 * 27 C silently (#374).
 */
declare class UnsupportedTemperatureError extends InvalidCircuitError {
    /** Instance name, e.g. `D1` */
    readonly deviceName: string;
    /** Requested device temperature in degrees Celsius */
    readonly temperature: number;
    /** Model parameter without a temperature law; undefined when the whole device has none */
    readonly parameter?: string | undefined;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_TEMPERATURE";
    constructor(
    /** Instance name, e.g. `D1` */
    deviceName: string, 
    /** Requested device temperature in degrees Celsius */
    temperature: number, 
    /** Model parameter without a temperature law; undefined when the whole device has none */
    parameter?: string | undefined);
}
/**
 * Thrown when a subcircuit instance with multiplicity `m` (the X-line `m=`,
 * including one inherited from an enclosing instance) contains a card that
 * ngspice-47 scales by `m` but spice-ts cannot (e.g. a G, F, current B or
 * JFET card). Simulating it with m = 1 would silently model a different
 * circuit.
 */
declare class UnsupportedMultiplicityError extends InvalidCircuitError {
    /** Flattened device name, e.g. `x1.g1` */
    readonly deviceName: string;
    /** SPICE instance letter, e.g. `G` */
    readonly deviceKind: string;
    /** Subcircuit instance path whose multiplicity reaches the device, e.g. `x1` */
    readonly instanceName: string;
    /** Effective multiplicity of that instance */
    readonly multiplicity: number;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MULTIPLICITY";
    constructor(
    /** Flattened device name, e.g. `x1.g1` */
    deviceName: string, 
    /** SPICE instance letter, e.g. `G` */
    deviceKind: string, 
    /** Subcircuit instance path whose multiplicity reaches the device, e.g. `x1` */
    instanceName: string, 
    /** Effective multiplicity of that instance */
    multiplicity: number);
}

/** Structural subset shared by DOM AbortSignal and Node's AbortSignal. */
interface StepTaskAbortSignal {
    readonly aborted: boolean;
    readonly reason?: unknown;
    addEventListener(type: 'abort', listener: () => void, options?: {
        once?: boolean;
    }): void;
    removeEventListener(type: 'abort', listener: () => void): void;
}

/** One recorded digital node value: the time it took effect and its state/strength. */
interface DigitalNodeEvent {
    readonly time: number;
    readonly state: '0' | '1' | 'U';
    readonly strength: 's' | 'r' | 'z' | 'u';
}

/**
 * Result of a DC operating point (`.op`) analysis.
 *
 * Contains the steady-state node voltages and branch currents.
 */
declare class DCResult {
    private readonly voltageMap;
    private readonly currentMap;
    constructor(voltageMap: Map<string, number>, currentMap: Map<string, number>);
    /**
     * Get the DC voltage at a node.
     *
     * @param node - Node name as it appears in the netlist
     * @returns Voltage in volts
     * @throws Error if the node name is not found in the result
     */
    voltage(node: string): number;
    /**
     * Get the DC current through a voltage source or inductor branch.
     *
     * @param source - Branch device name (e.g., `'V1'`)
     * @returns Current in amps
     * @throws Error if the branch name is not found in the result
     */
    current(source: string): number;
    /** Copy of all node voltages as a Map. */
    get voltages(): Map<string, number>;
    /** Copy of all branch currents as a Map. */
    get currents(): Map<string, number>;
}
/**
 * Result of a transient (`.tran`) analysis.
 *
 * Contains time-domain waveforms for all nodes and branches.
 */
declare class TransientResult {
    /** Array of time points in seconds. */
    readonly time: number[];
    private readonly voltageArrays;
    private readonly currentArrays;
    private readonly digitalHistories;
    constructor(
    /** Array of time points in seconds. */
    time: number[], voltageArrays: Map<string, number[]>, currentArrays: Map<string, number[]>, digitalHistories?: Map<string, DigitalNodeEvent[]>);
    /**
     * Get the value changes of an XSPICE digital (event-driven) node: its
     * operating-point value at time 0, then one entry per accepted change,
     * like ngspice `eprint`.
     *
     * @param node - Digital node name as it appears in the netlist
     * @throws Error if the node is not a digital node of the circuit
     */
    digital(node: string): DigitalNodeEvent[];
    /** Copy of every digital node's value changes as a Map. */
    get digitalNodes(): Map<string, DigitalNodeEvent[]>;
    /**
     * Get the voltage waveform at a node over time.
     *
     * @param node - Node name as it appears in the netlist
     * @returns Array of voltage values (one per time point)
     * @throws Error if the node name is not found in the result
     */
    voltage(node: string): number[];
    /**
     * Get the current waveform through a branch over time.
     *
     * @param source - Branch device name (e.g., `'V1'`)
     * @returns Array of current values (one per time point)
     * @throws Error if the branch name is not found in the result
     */
    current(source: string): number[];
    /** Copy of all node voltage waveforms as a Map. */
    get voltages(): Map<string, number[]>;
    /** Copy of all branch current waveforms as a Map. */
    get currents(): Map<string, number[]>;
}
/**
 * Result of an AC small-signal (`.ac`) analysis.
 *
 * Contains frequency-domain magnitude and phase data for all nodes and branches.
 */
declare class ACResult {
    /** Array of frequency points in Hz. */
    readonly frequencies: number[];
    private readonly voltageArrays;
    private readonly currentArrays;
    constructor(
    /** Array of frequency points in Hz. */
    frequencies: number[], voltageArrays: Map<string, {
        magnitude: number;
        phase: number;
    }[]>, currentArrays: Map<string, {
        magnitude: number;
        phase: number;
    }[]>);
    /**
     * Get the AC voltage response at a node across all frequencies.
     *
     * @param node - Node name as it appears in the netlist
     * @returns Array of `{ magnitude, phase }` objects (one per frequency point; phase in degrees)
     * @throws Error if the node name is not found in the result
     */
    voltage(node: string): {
        magnitude: number;
        phase: number;
    }[];
    /**
     * Get the AC current response through a branch across all frequencies.
     *
     * @param source - Branch device name (e.g., `'V1'`)
     * @returns Array of `{ magnitude, phase }` objects (one per frequency point; phase in degrees)
     * @throws Error if the branch name is not found in the result
     */
    current(source: string): {
        magnitude: number;
        phase: number;
    }[];
    /** Copy of all node voltage phasors as a Map. */
    get voltages(): Map<string, {
        magnitude: number;
        phase: number;
    }[]>;
    /** Copy of all branch current phasors as a Map. */
    get currents(): Map<string, {
        magnitude: number;
        phase: number;
    }[]>;
}
/** Spectral output-voltage and input-referred noise densities from a `.noise` analysis. */
declare class NoiseResult {
    /** Frequency points in Hz. */
    readonly frequencies: number[];
    /** Output node named by the `.noise` command. */
    readonly outputNode: string;
    /** Input source named by the `.noise` command. */
    readonly inputSource: string;
    /** Output-referred voltage-noise density in V/sqrt(Hz). */
    readonly outputNoiseDensity: number[];
    /**
     * Input-referred noise density: V/sqrt(Hz) for a voltage input source or
     * A/sqrt(Hz) for a current input source.
     */
    readonly inputNoiseDensity: number[];
    /** Integrated output-referred RMS noise in V, absent for a zero-width sweep. */
    readonly integratedOutputNoise: number | undefined;
    /**
     * Integrated input-referred RMS noise: V for a voltage input source or A
     * for a current input source; absent for a zero-width sweep.
     */
    readonly integratedInputNoise: number | undefined;
    /** Optional negative output node for a differential voltage result. */
    readonly outputReferenceNode?: string | undefined;
    constructor(
    /** Frequency points in Hz. */
    frequencies: number[], 
    /** Output node named by the `.noise` command. */
    outputNode: string, 
    /** Input source named by the `.noise` command. */
    inputSource: string, 
    /** Output-referred voltage-noise density in V/sqrt(Hz). */
    outputNoiseDensity: number[], 
    /**
     * Input-referred noise density: V/sqrt(Hz) for a voltage input source or
     * A/sqrt(Hz) for a current input source.
     */
    inputNoiseDensity: number[], 
    /** Integrated output-referred RMS noise in V, absent for a zero-width sweep. */
    integratedOutputNoise: number | undefined, 
    /**
     * Integrated input-referred RMS noise: V for a voltage input source or A
     * for a current input source; absent for a zero-width sweep.
     */
    integratedInputNoise: number | undefined, 
    /** Optional negative output node for a differential voltage result. */
    outputReferenceNode?: string | undefined);
}
/** Rectangular complex value of an S-parameter analysis vector. */
interface ComplexValue {
    real: number;
    imaginary: number;
}
/**
 * S-parameter analysis result (from `.sp`), with ngspice-47's vector names:
 * `S_i_j`, `Y_i_j`, `Z_i_j` for every port pair, plus with `donoise = 1` the
 * port noise-current correlation matrix `Cy_i_j` (A²/Hz; ngspice writes these
 * as `i(Cy_i_j)`) and, for exactly two ports, `NF`, `SOpt`, `NFmin` (dB) and
 * `Rn` (ohms).
 */
declare class SParameterResult {
    /** Frequency points in Hz. */
    readonly frequencies: number[];
    /** Port source names; entry `i` is port `i + 1`. */
    readonly ports: string[];
    /** Complex vectors keyed by ngspice name, one value per frequency. */
    readonly vectors: Map<string, ComplexValue[]>;
    constructor(
    /** Frequency points in Hz. */
    frequencies: number[], 
    /** Port source names; entry `i` is port `i + 1`. */
    ports: string[], 
    /** Complex vectors keyed by ngspice name, one value per frequency. */
    vectors: Map<string, ComplexValue[]>);
    /**
     * Get a vector by ngspice name, case-insensitively (`'S_2_1'`, `'cy_1_1'`).
     *
     * @throws Error if the analysis produced no such vector
     */
    vector(name: string): ComplexValue[];
}
/** Rectangular complex distortion component. */
interface ComplexDistortionValue {
    real: number;
    imaginary: number;
}
/** Harmonic products included in the bounded single-tone result. */
type DistortionOrder = 2 | 3;
/** Intermodulation products included in the bounded two-tone result. */
type DistortionIntermodulationProduct = 'f1+f2' | 'f1-f2' | '2f1-f2';
/** Product selector for a bounded single- or two-tone distortion result. */
type DistortionProduct = DistortionOrder | DistortionIntermodulationProduct;
/** Deterministic harmonic or intermodulation results from a bounded `.disto`. */
declare class DistortionResult {
    /** Swept F1 frequencies in ascending order. */
    readonly frequencies: number[];
    private readonly voltageArrays;
    private readonly currentArrays;
    /** Fixed F2/start-F1 ratio for two-tone results. */
    readonly f2OverF1?: number | undefined;
    readonly products: readonly DistortionProduct[];
    constructor(
    /** Swept F1 frequencies in ascending order. */
    frequencies: number[], voltageArrays: Map<DistortionProduct, Map<string, ComplexDistortionValue[]>>, currentArrays: Map<DistortionProduct, Map<string, ComplexDistortionValue[]>>, 
    /** Fixed F2/start-F1 ratio for two-tone results. */
    f2OverF1?: number | undefined);
    voltage(node: string, product: DistortionProduct): ComplexDistortionValue[];
    current(branch: string, product: DistortionProduct): ComplexDistortionValue[];
}
/** Scalar small-signal quantities from a bounded `.tf` analysis. */
declare class TransferFunctionResult {
    /** Output node for voltage-output analysis; undefined for current output. */
    readonly outputNode: string | undefined;
    /** Independent input source named by the `.tf` command. */
    readonly inputSource: string;
    /** Voltage/current gain or transimpedance/transconductance. */
    readonly transfer: number;
    /** Small-signal resistance seen by the input source, in ohms. */
    readonly inputResistance: number;
    /** Ngspice-compatible small-signal output resistance, in ohms. */
    readonly outputResistance: number;
    /** Output voltage source for current-output analysis; undefined for voltage output. */
    readonly outputSource?: string | undefined;
    constructor(
    /** Output node for voltage-output analysis; undefined for current output. */
    outputNode: string | undefined, 
    /** Independent input source named by the `.tf` command. */
    inputSource: string, 
    /** Voltage/current gain or transimpedance/transconductance. */
    transfer: number, 
    /** Small-signal resistance seen by the input source, in ohms. */
    inputResistance: number, 
    /** Ngspice-compatible small-signal output resistance, in ohms. */
    outputResistance: number, 
    /** Output voltage source for current-output analysis; undefined for voltage output. */
    outputSource?: string | undefined);
}
/** One finite pole or zero in radians per second. */
interface PoleZeroValue {
    real: number;
    imaginary: number;
}
/** Deterministically ordered finite poles and zeros from a bounded `.pz` analysis. */
declare class PoleZeroResult {
    readonly inputPositive: string;
    readonly inputNegative: string;
    readonly outputPositive: string;
    readonly outputNegative: string;
    readonly poles: PoleZeroValue[];
    readonly zeros: PoleZeroValue[];
    constructor(inputPositive: string, inputNegative: string, outputPositive: string, outputNegative: string, poles: PoleZeroValue[], zeros: PoleZeroValue[]);
}
/** One rectangular complex sensitivity value. */
interface ComplexSensitivityValue {
    real: number;
    imaginary: number;
}
/**
 * Sensitivity to one device parameter: a non-zero primary value, or the instance
 * multiplier `m` (ngspice `<dev>_m`) or `scale` (ngspice `<dev>_scale`) of a
 * resistor, capacitor, inductor or current source (`scale`: R, C and L only).
 */
interface SensitivityEntry {
    device: string;
    parameter: 'resistance' | 'capacitance' | 'inductance' | 'dc' | 'acMagnitude' | 'gain' | 'multiplier' | 'scale';
    dc?: number;
    ac?: ComplexSensitivityValue[];
}
/** Deterministically ordered results from the bounded `.sens` slice. */
declare class SensitivityResult {
    readonly outputNode: string;
    readonly mode: 'dc' | 'ac';
    readonly frequencies: number[];
    readonly entries: SensitivityEntry[];
    constructor(outputNode: string, mode: 'dc' | 'ac', frequencies: number[], entries: SensitivityEntry[]);
}
/**
 * Result of a DC sweep (`.dc`) analysis.
 *
 * Contains node voltages and branch currents at each sweep point.
 */
declare class DCSweepResult {
    /** Array of swept source values (e.g., voltage in volts). */
    readonly sweepValues: Float64Array;
    private readonly voltageArrays;
    private readonly currentArrays;
    /** Point-aligned outer sweep coordinates, when a second source is swept. */
    readonly secondarySweepValues?: Float64Array | undefined;
    constructor(
    /** Array of swept source values (e.g., voltage in volts). */
    sweepValues: Float64Array, voltageArrays: Map<string, Float64Array>, currentArrays: Map<string, Float64Array>, 
    /** Point-aligned outer sweep coordinates, when a second source is swept. */
    secondarySweepValues?: Float64Array | undefined);
    /**
     * Get the voltage at a node across all sweep points.
     *
     * @param node - Node name as it appears in the netlist
     * @returns Float64Array of voltage values (one per sweep point)
     * @throws Error if the node name is not found in the result
     */
    voltage(node: string): Float64Array;
    /**
     * Get the current through a branch across all sweep points.
     *
     * @param source - Branch device name (e.g., `'V1'`)
     * @returns Float64Array of current values (one per sweep point)
     * @throws Error if the branch name is not found in the result
     */
    current(source: string): Float64Array;
    /** Copy of all node voltage sweeps as a Map. */
    get voltages(): Map<string, Float64Array>;
    /** Copy of all branch current sweeps as a Map. */
    get currents(): Map<string, Float64Array>;
}
/**
 * Result of a single parametric step.
 * Contains the same result fields as a non-stepped simulation.
 */
interface StepResult {
    /** Name of the swept parameter or device */
    paramName: string;
    /** Value of the parameter for this step */
    paramValue: number;
    /** DC operating point result (from .op) */
    dc?: DCResult;
    /** DC sweep result (from .dc) */
    dcSweep?: DCSweepResult;
    /** Transient analysis result (from .tran) */
    transient?: TransientResult;
    /** AC small-signal analysis result (from .ac) */
    ac?: ACResult;
    /** DC small-signal transfer function (from .tf) */
    transferFunction?: TransferFunctionResult;
}
/**
 * Aggregate result object returned by {@link simulate}.
 *
 * Each field is populated only if the corresponding analysis was requested
 * in the netlist. For example, `.op` populates `dc`, `.tran` populates `transient`.
 */
interface SimulationResult {
    /** DC operating point result (from `.op`) */
    dc?: DCResult;
    /** DC sweep result (from `.dc`) */
    dcSweep?: DCSweepResult;
    /** Transient analysis result (from `.tran`) */
    transient?: TransientResult;
    /** AC small-signal analysis result (from `.ac`) */
    ac?: ACResult;
    /** Resistor-noise spectral result (from `.noise`) */
    noise?: NoiseResult;
    /** S-, Y-, Z-parameters over the RF ports (from `.sp`). */
    sParameters?: SParameterResult;
    /** Bounded harmonic or intermodulation result (from `.disto`). */
    distortion?: DistortionResult;
    /** DC small-signal transfer function (from `.tf`) */
    transferFunction?: TransferFunctionResult;
    /** Finite poles and zeros (in rad/s) from `.pz`. */
    poleZero?: PoleZeroResult;
    /** Primary-value sensitivities from the bounded `.sens` slice. */
    sensitivity?: SensitivityResult;
    /** Parametric sweep results (from .step). When present, top-level result fields are empty. */
    steps?: StepResult[];
    /**
     * `.meas`/`.measure` results, evaluated like ngspice-47 after each `.tran`,
     * `.ac` and `.dc` analysis, in card order. A measurement ngspice fails
     * (out of interval, bad syntax, unknown vector, ...) is listed with
     * `status: 'failed'` and ngspice's reason.
     */
    measurements?: MeasurementResult[];
    /**
     * Execution record of an interpreted ngspice `.control` script. When present,
     * each top-level analysis field holds the latest run of that analysis type:
     * the deck's own dot-card run that ngspice performs after the script (unless
     * the script ends with `quit`), otherwise the script's last run of that type.
     */
    control?: ControlScriptResult;
    /** Warnings collected during simulation */
    warnings: SimulationWarning[];
    /** Native-solver convergence counters. External adapters may omit them. */
    convergence?: ConvergenceTelemetry;
}
/** One evaluated `.meas` card. Names follow ngspice: lower-cased as in the deck. */
interface MeasurementResult {
    /** Result name (second word of the card), lower-cased. */
    name: string;
    /** Analysis the card measures: `tran`, `ac` or `dc`. */
    analysis: string;
    /** Measure function as written (third word), lower-cased: `trig`, `find`, `when`, `avg`, `param`, ... */
    function: string;
    /** 1-based netlist line of the card. */
    line: number;
    /** `failed` when ngspice-47 reports the measurement as failed. */
    status: 'ok' | 'failed';
    /** Measured value (`targ - trig` for TRIG/TARG, the x position for MIN_AT/MAX_AT). */
    value?: number;
    /** TRIG/TARG: trigger and target positions on the analysis scale. */
    trig?: number;
    targ?: number;
    /** MIN/MAX: scale position of the extremum. */
    at?: number;
    /** MIN_AT/MAX_AT: the extremum value. */
    with?: number;
    /** AVG/RMS/INTEG/PP: the window ngspice reports. */
    from?: number;
    to?: number;
    /** Why the measurement failed, in ngspice-47's words. */
    error?: string;
}
/** One analysis run by an ngspice `.control` script. */
interface ControlScriptRun {
    /** ngspice plot name of the run, e.g. `tran1`, `dc3`, `noise2`. */
    plot: string;
    /** Analysis type: `op`, `dc`, `ac`, `tran`, `noise`, ... */
    analysis: string;
    /** Result fields of this one run. */
    result: SimulationResult;
}
/** What an interpreted `.control` script did. */
interface ControlScriptResult {
    /** Every analysis the script ran, in execution order. */
    runs: ControlScriptRun[];
    /** Lines the script printed with `echo`. */
    output: string[];
    /** True when the script ended with `quit`/`exit` status 0, so the deck's own analyses were not run afterwards. */
    quit: boolean;
    /** Every `meas` command the script ran, in order (failed ones with ngspice's reason). */
    measurements: MeasurementResult[];
}

/** Node identifier — string name from netlist (e.g., '1', 'out', '0' for ground) */
type NodeName = string;
/** DC operating point analysis (`.op`). */
interface DCAnalysis {
    type: 'op';
}
/** One source range in a DC sweep (`.dc`). */
interface DCSweepDimension {
    /** Name of the source to sweep (e.g., `'V1'`) */
    source: string;
    /** Start value of the sweep (volts or amps) */
    start: number;
    /** Stop value of the sweep */
    stop: number;
    /** Step size between sweep points */
    step: number;
}
/** DC sweep analysis (`.dc`). The primary source varies fastest. */
interface DCSweepAnalysis extends DCSweepDimension {
    type: 'dc';
    /** Optional outer source range. Exactly two dimensions are supported. */
    secondary?: DCSweepDimension;
}
/** Transient analysis (`.tran`). Time-domain simulation. */
interface TransientAnalysis {
    type: 'tran';
    /** Suggested timestep in seconds */
    timestep: number;
    /** Simulation end time in seconds */
    stopTime: number;
    /** Simulation start time in seconds (default: 0) */
    startTime?: number;
    /** Maximum allowed timestep in seconds */
    maxTimestep?: number;
    /** Skip the DC operating point and use `.ic` values as the transient state. */
    useInitialConditions?: boolean;
}
/** A node voltage supplied by `.ic` or `.nodeset`. */
interface NodeInitialState {
    /** Node name as declared in the netlist. */
    node: NodeName;
    /** Initial voltage or Newton guess in volts. */
    value: number;
}
/** AC small-signal analysis (`.ac`). Frequency sweep. */
interface ACAnalysis {
    type: 'ac';
    /** Frequency sweep variation: `'dec'` (decades), `'oct'` (octaves), or `'lin'` (linear) */
    variation: 'dec' | 'oct' | 'lin';
    /** Number of points per decade/octave, or total for linear */
    points: number;
    /** Start frequency in Hz */
    startFreq: number;
    /** Stop frequency in Hz */
    stopFreq: number;
}
/** Bounded resistor-noise analysis (`.noise v(node[,reference]) source ...`). */
interface NoiseAnalysis {
    type: 'noise';
    /** Positive output node whose voltage-noise density is reported. */
    outputNode: string;
    /** Optional negative output node for a differential voltage result. */
    outputReferenceNode?: string;
    /** Independent voltage source used to refer output noise back to the input. */
    inputSource: string;
    /** Frequency sweep spacing. */
    variation: 'dec' | 'oct' | 'lin';
    /** Number of points per decade/octave, or total points for a linear sweep. */
    points: number;
    /** Start frequency in Hz. */
    startFreq: number;
    /** Stop frequency in Hz. */
    stopFreq: number;
    /** Optional interval between per-generator summary points in classic SPICE output. */
    pointsPerSummary?: number;
}
/**
 * S-parameter analysis over the circuit's RF ports
 * (`.sp {dec|oct|lin} points fstart fstop [donoise]`, ngspice-47 span.c).
 */
interface SParameterAnalysis {
    type: 'sp';
    /** Frequency sweep spacing. */
    variation: 'dec' | 'oct' | 'lin';
    /** Number of points per decade/octave, or total points for a linear sweep. */
    points: number;
    /** Start frequency in Hz. */
    startFreq: number;
    /** Stop frequency in Hz. */
    stopFreq: number;
    /** `donoise = 1`: also compute the port noise-current correlation matrix Cy (and NF/SOpt/NFmin/Rn for two ports). */
    noise: boolean;
}
/** Bounded distortion analysis (`.disto dec ... [f2overf1]`). */
interface DistortionAnalysis {
    type: 'disto';
    variation: 'dec';
    /** Points per decade. */
    points: number;
    /** Fundamental-frequency sweep start in Hz. */
    startFreq: number;
    /** Fundamental-frequency sweep stop in Hz. */
    stopFreq: number;
    /** Fixed F2/start-F1 ratio. Its presence selects the bounded two-tone mode. */
    f2OverF1?: number;
}
/** Bounded DC transfer-function analysis. */
type TransferFunctionAnalysis = VoltageTransferFunctionAnalysis | CurrentTransferFunctionAnalysis;
/** Single-node voltage-output transfer function (`.tf v(node) source`). */
interface VoltageTransferFunctionAnalysis {
    type: 'tf';
    /** Single output node whose small-signal voltage is measured. */
    outputNode: string;
    /** Independent voltage or current source used as the small-signal input. */
    inputSource: string;
}
/** Independent-voltage-source current-output transfer function (`.tf i(source) input`). */
interface CurrentTransferFunctionAnalysis {
    type: 'tf';
    /** Independent voltage source whose small-signal branch current is measured. */
    outputSource: string;
    /** Independent voltage or current source used as the small-signal input. */
    inputSource: string;
}
/** Bounded pole-zero analysis (`.pz input 0 output 0 {cur|vol} {pol|pz}`). */
interface PoleZeroAnalysis {
    type: 'pz';
    /** Positive input terminal. */
    inputPositive: string;
    /** Negative input terminal (`'0'` for ground). */
    inputNegative: string;
    /** Positive voltage-output terminal. */
    outputPositive: string;
    /** Negative voltage-output terminal (`'0'` for ground). */
    outputNegative: string;
    /** Current or voltage input. */
    inputType: 'cur' | 'vol';
    /** Compute poles only, zeros only, or both poles and zeros. */
    mode: 'pol' | 'zer' | 'pz';
}
/** Bounded single-node voltage sensitivity analysis. */
type SensitivityAnalysis = DCSensitivityAnalysis | ACSensitivityAnalysis;
/** DC operating-point sensitivity (`.sens v(node)`). */
interface DCSensitivityAnalysis {
    type: 'sens';
    outputNode: string;
    mode: 'dc';
}
/** Small-signal AC sensitivity (`.sens v(node) ac {dec|oct|lin} ...`). */
interface ACSensitivityAnalysis {
    type: 'sens';
    outputNode: string;
    mode: 'ac';
    variation: 'dec' | 'oct' | 'lin';
    points: number;
    startFreq: number;
    stopFreq: number;
}
/** Established time/frequency analysis command types. */
type AnalysisCommand = DCAnalysis | DCSweepAnalysis | TransientAnalysis | ACAnalysis;
/** Every analysis directive executable by the native simulator. */
type AnalysisDirective = AnalysisCommand | NoiseAnalysis | SParameterAnalysis | DistortionAnalysis | TransferFunctionAnalysis | SensitivityAnalysis;
/** Integration methods for transient analysis */
type IntegrationMethod = 'euler' | 'trapezoidal' | 'gear2';
/**
 * Options for controlling simulation behavior.
 *
 * All fields are optional; SPICE-convention defaults are used when omitted.
 */
interface SimulationOptions {
    /** ngspice nonlinear-device bypass request. Native solver always evaluates devices and warns when nonzero. */
    bypass?: number;
    /** ngspice-47 RAMPTIME breakpoint (s). Ordinary V/I sources do not ramp in the release build. Default: 0. */
    rampTime?: number;
    /**
     * ngspice `.options seed=N` (positive integer): seeds the uniform random
     * streams of TRNOISE RTS noise and TRRANDOM sources as ngspice-47 does.
     * Absent keeps spice-ts's fixed default streams, so runs stay reproducible.
     */
    seed?: number;
    /** Absolute current tolerance (A). Default: 1e-12 */
    abstol?: number;
    /** Absolute voltage tolerance (V). Default: 1e-6 */
    vntol?: number;
    /** Relative tolerance. Default: 1e-3 */
    reltol?: number;
    /** Max Newton-Raphson iterations (DC). Default: 100 */
    maxIterations?: number;
    /** Max Newton-Raphson iterations per transient step. Default: 100 (ngspice-47 NIiter floor) */
    maxTransientIterations?: number;
    /**
     * Maximum timestep for transient analyses without a `.tran` TMAX (TMAX wins,
     * as in ngspice). Default: min(TSTEP, TSTOP/50). 0 means unset, as in
     * ngspice; negative or non-finite values throw `InvalidCircuitError`.
     */
    maxTimestep?: number;
    /** Integration method. Default: 'trapezoidal' */
    integrationMethod?: IntegrationMethod;
    /** ngspice MAXORD cap (1..6). Order 1 uses backward Euler for trap and gear. Default: 2. */
    maxOrder?: number;
    /** Trapezoidal truncation error factor. Default: 7 */
    trtol?: number;
    /** Charge tolerance (C) of the device-charge truncation error (ngspice CHGTOL). Default: 1e-14 */
    chgtol?: number;
    /** Minimum conductance added to all node diagonals for gmin stepping. Default: 0 (disabled) */
    gmin?: number;
    /**
     * ngspice `.options rshunt=R` (ohms, above 1e-30): a noiseless resistor R
     * from every node, device-internal nodes included, to ground in every
     * analysis. Read from the circuit's own options (`.options` card or
     * `Circuit.setSimulationOptions`) when it is compiled. Default: none.
     */
    rshunt?: number;
    /** Resolver for .include and .lib file directives */
    resolveInclude?: IncludeResolver;
    /**
     * Simulation backend to use. Defaults to `'spice-ts'`, the TypeScript-native
     * solver. Use `'ngspice-wasm'` to run through the optional ngspice WASM
     * adapter, or pass a custom simulator adapter.
     */
    simulator?: SimulatorBackend;
    /** Optional bounded worker execution for independent `.step` iterations. */
    stepWorkers?: false | StepWorkerOptions;
}
/** Serializable work sent to one `.step` worker. */
interface StepWorkerTask {
    index: number;
    netlist: string;
    options: Omit<SimulationOptions, 'resolveInclude' | 'simulator' | 'stepWorkers'>;
}
/** Minimal worker contract supported by Node worker_threads and browser Workers. */
interface StepWorker {
    run(task: StepWorkerTask): Promise<SimulationResult>;
    terminate(reason?: unknown): void | Promise<void>;
}
interface StepWorkerCompletion {
    index: number;
    result: StepResult;
}
interface StepWorkerOptions {
    /** Maximum concurrent workers. Defaults to the runtime hardware-concurrency hint. */
    maxWorkers?: number;
    /** Abort the sweep and terminate every active worker. */
    signal?: StepTaskAbortSignal;
    /** Receives results immediately in completion order. */
    onComplete?: (completion: StepWorkerCompletion) => void;
    /** Override worker creation; returning null requests sequential fallback. */
    workerFactory?: (workerIndex: number) => StepWorker | null | Promise<StepWorker | null>;
}
/** Built-in simulator backend names. */
type SimulatorBackendName = 'spice-ts' | 'ngspice-wasm';
/** Pluggable simulator adapter compatible with {@link simulate}. */
interface SimulatorAdapter {
    /** Human-readable backend name for diagnostics. */
    readonly name?: string;
    /** Run a simulation and return the standard spice-ts result shape. */
    simulate(input: string | Circuit, options?: SimulationOptions): Promise<SimulationResult>;
}
/** Simulation backend selector accepted by {@link SimulationOptions}. */
type SimulatorBackend = SimulatorBackendName | SimulatorAdapter;
/**
 * A single transient simulation timestep, yielded by {@link simulateStream}.
 */
interface TransientStep {
    /** Simulation time in seconds */
    time: number;
    /** Node voltages at this timestep (node name to volts) */
    voltages: Map<string, number>;
    /** Branch currents at this timestep (device name to amps) */
    currents: Map<string, number>;
}
/**
 * A single AC frequency point, yielded by {@link simulateStream}.
 */
interface ACPoint {
    /** Frequency in Hz */
    frequency: number;
    /** Node voltage phasors (node name to magnitude/phase in degrees) */
    voltages: Map<string, {
        magnitude: number;
        phase: number;
    }>;
    /** Branch current phasors (device name to magnitude/phase in degrees) */
    currents: Map<string, {
        magnitude: number;
        phase: number;
    }>;
}
/**
 * Device model parameters parsed from a `.model` card.
 */
interface ModelParams {
    /** Model name as declared in the netlist */
    name: string;
    /** Model type (e.g., `'NPN'`, `'PNP'`, `'NMOS'`, `'PMOS'`, `'D'`) */
    type: string;
    /** Key-value parameter map (e.g., `{ BF: 100, IS: 1e-14 }`) */
    params: Record<string, number>;
    /**
     * Raw `VERSION=` string of the card (e.g. `'3.3.0'`). ngspice declares the BSIM version as a
     * string parameter and selects the BSIM implementation by its prefix, so it is kept verbatim.
     */
    version?: string;
}
/** DC source waveform. Constant value. */
interface DCSource {
    type: 'dc';
    /** DC value in volts (for voltage sources) or amps (for current sources) */
    value: number;
}
/** Pulse source waveform (PULSE). */
interface PulseSource {
    type: 'pulse';
    /** Explicit DC operating-point value declared before the waveform. */
    dc?: number;
    /** Initial value */
    v1: number;
    /** Pulsed value */
    v2: number;
    /** Delay before first pulse in seconds */
    delay: number;
    /** Rise time in seconds */
    rise: number;
    /** Fall time in seconds */
    fall: number;
    /** Pulse width in seconds */
    width: number;
    /** Period in seconds */
    period: number;
    /**
     * Number of pulses (ngspice's eighth PULSE field, NP). When positive, the
     * source holds V1 once `time - delay` exceeds `pulses * period`; omitted or
     * non-positive means the pulse train repeats indefinitely.
     */
    pulses?: number;
}
/** Sinusoidal source waveform (SIN). */
interface SinSource {
    type: 'sin';
    /** Explicit DC operating-point value when declared before SIN/SINE. */
    dc?: number;
    /** DC offset */
    offset: number;
    /** Peak amplitude */
    amplitude: number;
    /** Frequency in Hz */
    frequency: number;
    /** Delay before sine starts in seconds */
    delay?: number;
    /** Damping factor (1/s) */
    damping?: number;
    /** Phase offset in degrees */
    phase?: number;
}
/** One time/value pair in a piecewise-linear source waveform. */
interface PWLPoint {
    /** Time in seconds. Points are ordered by non-decreasing time. */
    time: number;
    /** Source value at this point. */
    value: number;
}
/** Piecewise-linear source waveform (PWL). */
interface PWLSource {
    type: 'pwl';
    /** Explicit DC operating-point value declared before the waveform. */
    dc?: number;
    /** Ordered time/value pairs. Equal adjacent times describe a discontinuity. */
    points: PWLPoint[];
    /** `TD=`: delay in seconds that shifts every point (ngspice VSRCrdelay). */
    delay?: number;
    /**
     * `R=`: repeat start time. After the last point the waveform repeats from
     * the point at this time (ngspice VSRCr; `R=0` repeats the whole waveform).
     * Must equal one of the point times and be before the last one.
     */
    repeat?: number;
}
/**
 * Exponential source waveform (`EXP(V1 V2 [TD1 [TAU1 [TD2 [TAU2]]]])`).
 * Omitted or zero times default as in ngspice-47 vsrcload.c: TD1, TAU1 and
 * TAU2 to the transient TSTEP, TD2 to TD1 + TSTEP.
 */
interface ExpSource {
    type: 'exp';
    /** Explicit DC operating-point value declared before the waveform. */
    dc?: number;
    /** Initial value */
    v1: number;
    /** Pulsed value */
    v2: number;
    /** Rise delay time in seconds */
    td1?: number;
    /** Rise time constant in seconds */
    tau1?: number;
    /** Fall delay time in seconds */
    td2?: number;
    /** Fall time constant in seconds */
    tau2?: number;
}
/**
 * Single-frequency FM source waveform
 * (`SFFM(VO VA [FC [MDI [FM [TD [PHASEM [PHASEC]]]]]])`), ngspice-47
 * semantics: 0 until TD, then `VO + VA*sin(2*pi*FC*t + PHASEC + MDI*sin(2*pi*FM*t + PHASEM))`
 * with `t` measured from TD. Omitted FC and FM default to `5/TSTOP` and
 * `500/TSTOP` (FM also when zero), MDI to 90, and MDI is clamped to [0, FC/FM].
 */
interface SffmSource {
    type: 'sffm';
    /** Explicit DC operating-point value declared before the waveform. */
    dc?: number;
    /** Offset */
    offset: number;
    /** Amplitude */
    amplitude: number;
    /** Carrier frequency in Hz */
    carrierFrequency?: number;
    /** Modulation index */
    modulationIndex?: number;
    /** Signal (modulating) frequency in Hz */
    signalFrequency?: number;
    /** Delay in seconds */
    delay?: number;
    /** Modulating-signal phase in degrees */
    signalPhase?: number;
    /** Carrier phase in degrees */
    carrierPhase?: number;
}
/**
 * Amplitude-modulated source waveform
 * (`AM(VO VMO [VMA [FM [FC [TD [PHASEM [PHASEC]]]]]])`), ngspice-47
 * semantics: 0 until TD, then
 * `VO + (VMO + VMA*sin(2*pi*FM*t + PHASEM)) * sin(2*pi*FC*t + PHASEC)` with `t`
 * measured from TD. Omitted VMA, FM and FC default to 1, `5/TSTOP` and `500/TSTOP`.
 */
interface AmSource {
    type: 'am';
    /** Explicit DC operating-point value declared before the waveform. */
    dc?: number;
    /** Offset */
    offset: number;
    /** Carrier amplitude (modulation offset) */
    carrierAmplitude: number;
    /** Modulation amplitude */
    modulationAmplitude?: number;
    /** Modulating frequency in Hz */
    modulationFrequency?: number;
    /** Carrier frequency in Hz */
    carrierFrequency?: number;
    /** Delay in seconds */
    delay?: number;
    /** Modulating-signal phase in degrees */
    modulationPhase?: number;
    /** Carrier phase in degrees */
    carrierPhase?: number;
}
/**
 * ngspice-47 transient noise source
 * (`TRNOISE(NA TS [NALPHA [NAMP [RTSAM [RTSCAPT [RTSEMT]]]]])`): white noise
 * of rms `amplitude` and 1/f^`alpha` noise of rms `oneOverFAmplitude`, both
 * sampled every `ts` and linearly interpolated, plus random-telegraph noise of
 * amplitude `rtsAmplitude` with exponentially distributed mean capture and
 * emission times.
 */
interface TransientNoiseSource {
    type: 'trnoise';
    /** Explicit DC value, added to the noise as in ngspice. */
    dc?: number;
    /** NA: white-noise rms value. */
    amplitude: number;
    /** TS: noise sample interval in seconds (0 disables white and 1/f noise). */
    ts: number;
    /** NALPHA: 1/f exponent (0 < alpha < 2); 0 disables 1/f noise. */
    alpha: number;
    /** NAMP: 1/f noise rms value (ignored by ngspice when NALPHA is 0). */
    oneOverFAmplitude: number;
    /** RTSAM: random-telegraph amplitude (0 disables RTS noise). */
    rtsAmplitude: number;
    /** RTSCAPT: mean trap capture time in seconds (ignored when RTSAM is 0). */
    rtsCaptureTime: number;
    /** RTSEMT: mean trap emission time in seconds (ignored when RTSAM is 0). */
    rtsEmissionTime: number;
}
/**
 * ngspice-47 random-value source (`TRRANDOM(TYPE TS [TD [PARAM1 [PARAM2]]])`):
 * a new random value every `ts` seconds after the delay `td`.
 */
interface TransientRandomSource {
    type: 'trrandom';
    /** Explicit DC value, added to the random value as in ngspice. */
    dc?: number;
    /**
     * TYPE: 1 uniform in [-PARAM1+PARAM2, PARAM1+PARAM2[; 2 Gaussian (deviation
     * PARAM1, mean PARAM2); 3 exponential (mean PARAM1, offset PARAM2); 4 Poisson
     * (lambda PARAM1, offset PARAM2). ngspice yields 0 for any other value.
     */
    distribution: number;
    /** TS: interval between new values in seconds. */
    ts: number;
    /** TD: delay before the first new value in seconds. */
    td: number;
    /** PARAM1 (default 1). */
    param1: number;
    /** PARAM2 (default 0); also the value before the first draw. */
    param2: number;
}
/** AC small-signal source (AC). Used for `.ac` analysis excitation. */
interface ACSource {
    type: 'ac';
    /** DC operating-point value used before small-signal AC excitation. */
    dc?: number;
    /** AC magnitude */
    magnitude: number;
    /** AC phase in degrees */
    phase: number;
}
/** AC small-signal excitation that coexists with a transient waveform. */
interface ACExcitation {
    magnitude: number;
    phase: number;
}
/** Optional AC term carried alongside a transient source waveform. */
interface SourceACTerm {
    ac?: ACExcitation;
}
/** One source's small-signal distortion excitation at F1 or F2. */
interface DistortionExcitation {
    magnitude: number;
    phase: number;
}
/** Distortion annotations coexist with the source's DC/AC/transient waveform. */
interface SourceDistortionTerms {
    distortionF1?: DistortionExcitation;
    distortionF2?: DistortionExcitation;
}
/**
 * ngspice-47 RF port on an independent voltage source
 * (`V1 in 0 dc 0 ac 1 portnum 1 z0 50 [pwr P] [freq F]`, RFSPICE vsrc).
 *
 * A port puts its reference impedance `z0` in series with the source through
 * an internal node `<name>.res` (ngspice `<name>#res`) in every analysis, and
 * makes the source one of the ports of an `.sp` analysis.
 */
interface RFPort {
    /** `portnum`: 1-based port index; a circuit's ports are numbered 1..N. */
    number: number;
    /** `z0`: reference impedance in ohms (default 50). */
    z0: number;
    /**
     * Present when `pwr` or `freq` is given. ngspice then evaluates the source as
     * `sqrt(4*pwr*z0) * cos(2*pi*freq*t)` (defaults 1 mW, 1 GHz) everywhere except
     * a DC operating point of a source with an explicit DC value.
     */
    power?: {
        /** `pwr`: available power in watts. */
        watts: number;
        /** `freq`: frequency in Hz. */
        frequency: number;
        /** Explicit DC value, used for `.op`, `.dc` and the small-signal operating point. */
        dc?: number;
    };
}
/** Union of all source waveform types. Discriminated on the `type` field. */
type SourceWaveform = (DCSource | PulseSource | SinSource | PWLSource | ExpSource | SffmSource | AmSource | TransientNoiseSource | TransientRandomSource | ACSource) & SourceACTerm & SourceDistortionTerms;
/** Warning collected during simulation (non-fatal). */
interface SimulationWarning {
    /** Warning category (e.g., `'convergence'`, `'topology'`) */
    type: string;
    /** Human-readable warning message */
    message: string;
    /** Related node name, if applicable */
    node?: string;
}
/** Aggregate Newton-Raphson and fallback work performed by DC analyses. */
interface DCConvergenceTelemetry {
    /** Newton-Raphson iterations across every attempted DC solve. */
    newtonIterations: number;
    /** DC solves that converged, including homotopy intermediate solves. */
    acceptedSolves: number;
    /** DC solves that exhausted their Newton iteration budget. */
    rejectedSolves: number;
    /** Source-ramping homotopy levels attempted. */
    sourceStepAttempts: number;
    /** Source-ramping levels that did not converge. */
    sourceStepFailures: number;
    /** GMIN-stepping homotopy levels attempted. */
    gminStepAttempts: number;
    /** GMIN-stepping levels that did not converge. */
    gminStepFailures: number;
    /** Terminal failure classification; recoverable retries leave this null. */
    failure: ConvergenceFailureKind | null;
}
/** Aggregate adaptive-step and Newton work performed by transient analyses. */
interface TransientConvergenceTelemetry {
    /** Timesteps committed to the output waveform (the t=0 DC point is excluded). */
    acceptedSteps: number;
    /** Attempted timesteps rejected for either Newton or LTE reasons. */
    rejectedSteps: number;
    /** Newton-Raphson iterations across accepted and rejected attempts. */
    newtonIterations: number;
    /** Timesteps retried after Newton-Raphson failed to converge. */
    nrRetries: number;
    /** Timesteps retried after the local truncation error check failed. */
    lteRetries: number;
    /** Smallest committed timestep, or null when no transient step was accepted. */
    minimumAcceptedTimestep: number | null;
    /** Terminal failure classification; recoverable retries leave this null. */
    failure: ConvergenceFailureKind | null;
}
/** Bounded, deterministic convergence counters for a simulation run. */
interface ConvergenceTelemetry {
    dc: DCConvergenceTelemetry;
    transient: TransientConvergenceTelemetry;
}
/**
 * Async function that resolves `.include` and `.lib` file paths to their contents.
 *
 * @param path - File path as it appears in the `.include` or `.lib` directive
 * @returns The file contents as a string
 */
type IncludeResolver = (path: string) => Promise<string>;
/**
 * Subcircuit definition parsed from a `.subckt`/`.ends` block.
 */
interface SubcktDefinition {
    /** Subcircuit name (case-insensitive) */
    name: string;
    /** Ordered list of port node names */
    ports: string[];
    /**
     * Default parameter values (can be overridden per instance), in declaration
     * order. A string is a numparam expression (`'20e3/stime'`), evaluated per
     * instance like ngspice-47: after the instance overrides, over the earlier
     * parameters of the same definition and the top-level `.param` values.
     */
    params: Record<string, number | string>;
    /** Raw netlist lines between `.subckt` and `.ends` */
    body: string[];
    /**
     * Deck line number of each `body` line, so errors in the body point at the
     * source card. Without it, errors give line numbers relative to the body.
     */
    bodyLines?: number[];
}
/** Sweep mode for .step directive */
type StepSweepMode = 'lin' | 'dec' | 'oct' | 'list';
/** .step directive — parametric sweep configuration. */
interface StepAnalysis {
    type: 'step';
    /** Device name to sweep (e.g., 'R1') */
    param: string;
    /** Sweep mode */
    sweepMode: StepSweepMode;
    /** Start value (lin/dec/oct) */
    start?: number;
    /** Stop value (lin/dec/oct) */
    stop?: number;
    /** Step increment (lin) */
    increment?: number;
    /** Points per decade or octave (dec/oct) */
    points?: number;
    /** Explicit list of values (list mode) */
    values?: number[];
}
/**
 * A single streaming event from a stepped simulation.
 * Wraps a TransientStep or ACPoint with step metadata.
 */
interface StepStreamEvent {
    stepIndex: number;
    paramName: string;
    paramValue: number;
    point: TransientStep | ACPoint;
}

/** SPICE device type letter. */
type ComponentType = 'R' | 'C' | 'L' | 'V' | 'I' | 'D' | 'Q' | 'M' | 'E' | 'G' | 'H' | 'F' | 'X';
/** A named connection point on a component. */
interface IRPort {
    /** Port role name: 'p', 'n', 'gate', 'drain', 'source', 'collector', 'base', 'emitter', etc. */
    name: string;
    /** Net/node name this port connects to: '1', 'out', 'vcc', '0' (ground) */
    net: string;
}
/** A circuit component with typed parameters. */
interface IRComponent {
    /** SPICE device type letter */
    type: ComponentType;
    /** Unique identifier, e.g. 'R1', 'M2' */
    id: string;
    /** Display name */
    name: string;
    /** Named connection points */
    ports: IRPort[];
    /** Device parameters (resistance, capacitance, modelName, channelType, gain, etc.) */
    params: Record<string, number | string | boolean>;
    /** Human-readable value for display: "10k", "NMOS W=10u L=1u" */
    displayValue?: string;
}
/** A flat circuit representation — components and their net connectivity. */
interface CircuitIR {
    /** All components in the circuit */
    components: IRComponent[];
    /** Unique net names (excluding ground '0') */
    nets: string[];
}

/**
 * ngspice-47 B-source (`ASRC`) expressions: parse tree, evaluation and
 * derivatives, ported from `inpptree-parser.y`, `inpptree.c`, `ifeval.c` and
 * `ptfuncs.c`.
 *
 * Supported: numbers with SPICE scale factors, the constants `pi` and `e`,
 * `time`, `temper`, `v(node)`, `v(node1,node2)`, the branch current
 * `i(vsource)` of a branch-carrying source, unary `+ - !`, binary
 * `+ - * / ^ **`, comparisons `== != <> < <= > >=`, `&&`, `||` (also `|`), the ternary
 * `c ? a : b` / `ternary_fcn(c, a, b)`, every function listed in
 * {@link BEHAVIORAL_FUNCTIONS}, and the PSpice `if`, `limit`, `pwrs`, `stp`
 * and `int` (see {@link PSPICE_FUNCTIONS}). `.param` names, `{expr}` and `'expr'` are
 * substituted before parsing, as ngspice's numparam front end does (see
 * {@link substituteBehavioralParameters}). `hertz`, `pwl(...)` and the PSPICE
 * logic operators `~ &` are rejected explicitly. Single `|` is the boolean
 * OR alias ngspice translates in included PSpice libraries (#903).
 */
type BehavioralFunction = 'abs' | 'acos' | 'acosh' | 'asin' | 'asinh' | 'atan' | 'atanh' | 'cos' | 'cosh' | 'exp' | 'ln' | 'log' | 'log10' | 'sgn' | 'sin' | 'sinh' | 'sqrt' | 'tan' | 'tanh' | 'u' | 'uramp' | 'ceil' | 'floor' | 'nint' | 'u2' | 'eq0' | 'ne0' | 'gt0' | 'lt0' | 'ge0' | 'le0' | 'pow' | 'pwr' | 'min' | 'max' | 'ddt';
type BehavioralBinaryOperator = '+' | '-' | '*' | '/' | '^';
type BehavioralComparison = '==' | '!=' | '<' | '<=' | '>' | '>=';
type BehavioralVariable = 'time' | 'temper';
type BehavioralExpression = {
    kind: 'number';
    value: number;
} | {
    kind: 'voltage';
    positive: string;
    negative?: string;
}
/** ngspice PT_CURRENT: the MNA branch current of the named source (`i(vsource)`). */
 | {
    kind: 'current';
    source: string;
} | {
    kind: 'variable';
    name: BehavioralVariable;
} | {
    kind: 'negate';
    operand: BehavioralExpression;
} | {
    kind: 'not';
    operand: BehavioralExpression;
} | {
    kind: 'binary';
    op: BehavioralBinaryOperator;
    left: BehavioralExpression;
    right: BehavioralExpression;
} | {
    kind: 'compare';
    op: BehavioralComparison;
    left: BehavioralExpression;
    right: BehavioralExpression;
} | {
    kind: 'logical';
    op: '&&' | '||';
    left: BehavioralExpression;
    right: BehavioralExpression;
} | {
    kind: 'ternary';
    condition: BehavioralExpression;
    whenTrue: BehavioralExpression;
    whenFalse: BehavioralExpression;
} | {
    kind: 'call';
    name: BehavioralFunction;
    args: BehavioralExpression[];
};
/** ASRC instance parameters (ngspice `asrc.c`); temperatures in Celsius. */
interface BehavioralInstanceParams {
    tc1?: number;
    tc2?: number;
    /** Instance temperature; replaces the circuit temperature and `dtemp`. */
    temp?: number;
    dtemp?: number;
    /** ngspice `reciproctc=1`: divide by the temperature factor instead. */
    reciproctc?: boolean;
    /**
     * spice-ts `spice2poly=1`: the source is a SPICE2 POLY(n) card, which
     * ngspice-47 runs as an XSPICE 'A' device (enhtrans.c), so the circuit takes
     * the XSPICE trtol of cktdojob.c (#862). The POLY translation sets it.
     */
    spice2poly?: boolean;
}

type XspiceParamValue = number | boolean | string;

/** Token kinds of the XSPICE MIF tokenizer (ngspice mifutil.c MIFget_token). */
type XspiceTokenKind = 'string' | 'null' | 'percent' | 'tilde' | 'larray' | 'rarray' | 'lcomplex' | 'rcomplex';
interface XspiceToken {
    readonly kind: XspiceTokenKind;
    readonly text: string;
}
/** An A-card whose connections are resolved at compile time against its model's port table. */
interface XspiceInstanceCard {
    readonly name: string;
    /** Connection tokens between the instance name and the model name. */
    readonly connectionTokens: readonly XspiceToken[];
    readonly modelName: string;
    /** The logical card text, kept for round-trip netlist output. */
    readonly raw: string;
    readonly line: number;
}
/** A `.model` card of an implemented XSPICE code model with its values typed by the parameter table. */
interface XspiceModelCard {
    readonly name: string;
    /** Lower-case code model name (ngspice Spice_Model_Name). */
    readonly codeModel: string;
    /** Parameters given on the card, by lower-case name; every value is an element list. */
    readonly params: ReadonlyMap<string, readonly XspiceParamValue[]>;
    /** ngspice-47 MIF warnings: unrecognized parameters (ignored) and clamped limits. */
    readonly warnings: readonly string[];
    readonly raw: string;
    /**
     * Translated from a PSpice `VSWITCH` (`'S'`, a pswitch) or `ISWITCH` (`'W'`,
     * an aswitch) model by ngspice-47 inpcompat.c: only instances of that switch
     * letter use it, each compiled to the code-model device.
     */
    readonly pspiceSwitch?: 'S' | 'W';
}
/**
 * Thrown for a `.model` card whose type is an ngspice XSPICE code model that
 * spice-ts does not implement (for example `d_osc` or `hyst`). The card is
 * rejected instead of being stored, so an A instance can never simulate
 * without its code model.
 */
declare class UnsupportedCodeModelError extends ParseError {
    /** Model name as written on the `.model` card */
    readonly modelName: string;
    /** Lower-case XSPICE code model type */
    readonly codeModel: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_XSPICE_CODE_MODEL";
    constructor(
    /** Model name as written on the `.model` card */
    modelName: string, 
    /** Lower-case XSPICE code model type */
    codeModel: string, line: number, context: string);
}

/** One logical line of a `.control` block (continuations joined, comments stripped). */
interface ControlSourceLine {
    /** 1-based line number of the first physical line in the caller's netlist. */
    lineNumber: number;
    /** Command text, trimmed, with `+` continuations appended. */
    text: string;
}

/**
 * Statement structure of an ngspice `.control` script and the static contract
 * of which commands spice-ts executes.
 */
type ControlStatement = {
    kind: 'command';
    name: string;
    line: ControlSourceLine;
} | {
    kind: 'if';
    line: ControlSourceLine;
    condition: string;
    then: ControlStatement[];
    otherwise: ControlStatement[];
} | {
    kind: 'while' | 'dowhile';
    line: ControlSourceLine;
    condition: string;
    body: ControlStatement[];
} | {
    kind: 'repeat';
    line: ControlSourceLine;
    count: string;
    body: ControlStatement[];
} | {
    kind: 'foreach';
    line: ControlSourceLine;
    variable: string;
    values: string;
    body: ControlStatement[];
} | {
    kind: 'break' | 'continue';
    line: ControlSourceLine;
};
/** A parsed `.control` script (all blocks of the deck, in order). */
interface ControlScript {
    statements: ControlStatement[];
    /** Deck `.csparam` values, installed before executing any control statement. */
    constants?: Readonly<Record<string, number>>;
}

/** Per-instance BJT scaling; ngspice-47 bjtsetup.c/vbicsetup.c default AREA and M to 1. */
interface BJTInstanceParams {
    /** Emitter area factor (ngspice `area`, positional or keyword). */
    AREA?: number;
    /** Base area factor (ngspice `areab`); bjtsetup.c defaults it to AREA. */
    AREAB?: number;
    /** Collector area factor (ngspice `areac`); bjtsetup.c defaults it to AREA. */
    AREAC?: number;
    /** Parallel multiplier (ngspice `m`). */
    M?: number;
}

/** Per-instance JFET parameters spice-ts accepts. */
interface JFETInstanceParams {
    /** Instance temperature in degrees Celsius (ngspice jfet/jfet2 `temp`). */
    TEMP?: number;
}

interface DiodeInstanceParams {
    AREA?: number;
    PJ?: number;
    M?: number;
}

type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonValue[] | {
    [key: string]: JsonValue;
};
type JsonObject = {
    [key: string]: JsonValue;
};
interface OperatingPointAnalysisV1 {
    type: 'op';
}
interface DcAnalysisV1 {
    type: 'dc';
    source: string;
    start: number;
    stop: number;
    step: number;
}
interface TransientAnalysisV1 {
    type: 'tran';
    timestep: number;
    stopTime: number;
    startTime?: number;
    maxTimestep?: number;
}
interface AcAnalysisV1 {
    type: 'ac';
    variation: 'dec' | 'oct' | 'lin';
    points: number;
    startFreq: number;
    stopFreq: number;
}
type AnalysisV1 = OperatingPointAnalysisV1 | DcAnalysisV1 | TransientAnalysisV1 | AcAnalysisV1;
interface CircuitPortV1 {
    name: string;
    net: string;
}
interface CircuitComponentV1 {
    type: string;
    id: string;
    name: string;
    ports: CircuitPortV1[];
    params: JsonObject;
    model?: string;
    subcircuit?: string;
}
interface CircuitModelV1 {
    name: string;
    type: string;
    params: JsonObject;
}
interface SubcircuitV1 {
    name: string;
    ports: string[];
    components: CircuitComponentV1[];
    models?: CircuitModelV1[];
}
interface SpiceTsCircuitDocumentV1 {
    format: 'spice-ts';
    schemaVersion: '1.0';
    circuit: {
        components: CircuitComponentV1[];
        nets: string[];
    };
    analyses: AnalysisV1[];
    models: CircuitModelV1[];
    subcircuits: SubcircuitV1[];
}
type SimulationInputV1 = {
    format: 'spice';
    source: string;
    virtualFiles?: Record<string, string>;
} | {
    format: 'spice-ts';
    document: SpiceTsCircuitDocumentV1;
} | {
    format: 'circuit-json';
    circuit: JsonValue[];
    analyses: AnalysisV1[];
};
interface ResourceLimitsV1 {
    maxSourceBytes?: number;
    maxVirtualFiles?: number;
    maxIncludeDepth?: number;
    maxComponents?: number;
    maxSubcircuitDepth?: number;
    maxAnalyses?: number;
    maxResultPoints?: number;
    maxSerializedResultBytes?: number;
    maxWallTimeMs?: number;
}
interface SimulationOptionsV1 {
    backend?: 'spice-ts-js' | 'spice-ts-wasm' | 'ngspice-wasm';
    determinism?: 'strict' | 'relaxed';
    limits?: ResourceLimitsV1;
    abstol?: number;
    vntol?: number;
    reltol?: number;
    maxIterations?: number;
    maxTransientIterations?: number;
    maxTimestep?: number;
    integrationMethod?: 'euler' | 'trapezoidal' | 'gear2';
    trtol?: number;
    gmin?: number;
}
interface SimulationRequestV1 {
    apiVersion: '1';
    input: SimulationInputV1;
    options?: SimulationOptionsV1;
}
interface StepCoordinateV1 {
    index: number;
    parameter: string;
    value: number;
}
interface OperatingPointResultV1 {
    type: 'op';
    analysisIndex: number;
    step?: StepCoordinateV1;
    voltagesV: Record<string, number>;
    currentsA: Record<string, number>;
}
interface DcResultV1 {
    type: 'dc';
    analysisIndex: number;
    step?: StepCoordinateV1;
    axis: {
        name: string;
        unit: 'V' | 'A';
        values: number[];
    };
    voltagesV: Record<string, number[]>;
    currentsA: Record<string, number[]>;
}
interface TransientResultV1 {
    type: 'tran';
    analysisIndex: number;
    step?: StepCoordinateV1;
    timeS: number[];
    voltagesV: Record<string, number[]>;
    currentsA: Record<string, number[]>;
}
interface ComplexPolarV1 {
    magnitude: number;
    phaseDegrees: number;
}
interface AcResultV1 {
    type: 'ac';
    analysisIndex: number;
    step?: StepCoordinateV1;
    frequencyHz: number[];
    voltagePhasors: Record<string, ComplexPolarV1[]>;
    currentPhasors: Record<string, ComplexPolarV1[]>;
}
type AnalysisResultV1 = OperatingPointResultV1 | DcResultV1 | TransientResultV1 | AcResultV1;
interface SimulationResultV1 {
    status: 'complete';
    analyses: AnalysisResultV1[];
}
type ProtocolCompletionV1 = 'complete' | 'failed' | 'limited' | 'cancelled';
type ProtocolLimitNameV1 = keyof ResourceLimitsV1;
interface ProtocolCapabilityAnalysisV1 {
    id: `analysis:${AnalysisV1['type']}`;
    type: AnalysisV1['type'];
}
interface ProtocolCapabilityInputV1 {
    id: 'input:spice' | 'input:spice-ts';
    format: 'spice' | 'spice-ts';
}
interface ProtocolCapabilityLimitV1 {
    id: `limit:${ProtocolLimitNameV1}`;
    name: ProtocolLimitNameV1;
    unit: 'bytes' | 'count' | 'depth' | 'milliseconds';
}
interface ProtocolCapabilitiesV1 {
    apiVersion: '1';
    kind: 'capabilities';
    capabilityId: 'protocol-v1';
    analyses: ProtocolCapabilityAnalysisV1[];
    inputFormats: ProtocolCapabilityInputV1[];
    limits: ProtocolCapabilityLimitV1[];
    completions: ProtocolCompletionV1[];
}
interface ProtocolExecutionMetadataV1 {
    protocolVersion: '1';
    executionId: `execution:${string}`;
    inputId: `input:${string}`;
    resultId?: `result:${string}`;
    completion: ProtocolCompletionV1;
    partial: boolean;
    timing: {
        startedAtMs: number;
        finishedAtMs: number;
        durationMs: number;
    };
    counts: {
        requestedAnalyses: number;
        completedAnalyses: number;
        resultPoints: number;
    };
}
interface PartialSimulationResultV1 {
    status: 'partial';
    analyses: AnalysisResultV1[];
}
interface ProtocolSuccessEnvelopeV1 {
    apiVersion: '1';
    kind: 'terminal';
    ok: true;
    requestId: string;
    data: SimulationResultV1;
    metadata: ProtocolExecutionMetadataV1 & {
        completion: 'complete';
        partial: false;
        resultId: `result:${string}`;
    };
}
interface ProtocolFailureEnvelopeV1 {
    apiVersion: '1';
    kind: 'terminal';
    ok: false;
    requestId: string;
    error: SpiceApiErrorV1;
    partial: PartialSimulationResultV1;
    metadata: ProtocolExecutionMetadataV1 & {
        completion: Exclude<ProtocolCompletionV1, 'complete'>;
    };
}
type ProtocolTerminalEnvelopeV1 = ProtocolSuccessEnvelopeV1 | ProtocolFailureEnvelopeV1;
type SpiceApiErrorCodeV1 = 'INVALID_REQUEST' | 'PARSE_ERROR' | 'INVALID_CIRCUIT' | 'UNSUPPORTED_FEATURE' | 'SINGULAR_MATRIX' | 'CONVERGENCE_FAILED' | 'TIMESTEP_TOO_SMALL' | 'RESOURCE_LIMIT' | 'CANCELLED' | 'BACKEND_UNAVAILABLE' | 'INTERNAL_ERROR';
interface SpiceApiErrorV1 {
    code: SpiceApiErrorCodeV1;
    message: string;
    retryable: boolean;
    phase: 'validation' | 'parse' | 'compile' | 'solve' | 'serialize' | 'transport';
    details: JsonObject;
}

/**
 * Stable cooperative boundaries for bounded protocol execution.
 *
 * Parsing checks once per preprocessed and parsed line; compilation checks once
 * per instantiated device; Newton checks before each iteration; transient and
 * AC check before each output point; serialization checks after each analysis.
 */
type ProtocolSafePointV1 = 'parse:line' | 'compile:device' | 'solve:newton-iteration' | 'solve:transient-step' | 'solve:ac-point' | 'serialize:analysis';
interface ProtocolAbortSignalV1 {
    readonly aborted: boolean;
    readonly reason?: unknown;
}
interface ProtocolExecutionOptionsV1 {
    signal?: ProtocolAbortSignalV1;
    /** Monotonic clock override for deterministic hosts and tests. */
    now?: () => number;
    /** Observability hook invoked immediately before each cooperative check. */
    onSafePoint?: (safePoint: ProtocolSafePointV1) => void;
    /** Receives each fully serialized analysis before the following cooperative check. */
    onAnalysisComplete?: (analysis: AnalysisResultV1) => void;
}
/** Shared synchronous guard used by protocol parsing, compilation, solving, and serialization. */
declare class ProtocolExecutionGuard {
    readonly limits: Readonly<ResourceLimitsV1>;
    private readonly execution;
    private readonly startedAt;
    private readonly now;
    private resultPoints;
    constructor(limits: Readonly<ResourceLimitsV1>, execution?: Readonly<ProtocolExecutionOptionsV1>);
    checkpoint(safePoint: ProtocolSafePointV1): void;
    maximum(limit: keyof ResourceLimitsV1, observed: number, phase: SpiceApiErrorV1['phase']): void;
    recordResultPoint(): void;
}

/**
 * The compiled representation of a circuit, ready for numerical simulation.
 *
 * Produced by {@link Circuit.compile}. Contains instantiated device models,
 * node/branch mappings, and analysis commands.
 */
interface CompiledCircuit {
    /** Instantiated device models with resolved node indices */
    devices: DeviceModel[];
    /** Number of non-ground nodes */
    nodeCount: number;
    /** Number of MNA branches (voltage sources, inductors, controlled sources) */
    branchCount: number;
    /** Ordered list of node names (excludes ground) */
    nodeNames: string[];
    /** Map from node name to its matrix index (-1 for ground) */
    nodeIndexMap: Map<string, number>;
    /** Ordered list of branch names */
    branchNames: string[];
    /** Analysis commands to execute */
    analyses: AnalysisDirective[];
    /** Bounded native pole-zero commands, kept outside adapters without `.pz` result support. */
    poleZeroAnalyses: PoleZeroAnalysis[];
    /** Device model parameter cards */
    models: Map<string, ModelParams>;
    /** Subcircuit definitions */
    subcircuits: Map<string, SubcktDefinition>;
    /** Step directives for parametric sweeps */
    steps: StepAnalysis[];
    /** Solver options declared by `.options` cards in the netlist */
    simulationOptions: SimulationOptions;
    /**
     * Node voltages from `.ic`: the t=0 state with transient UIC; otherwise held
     * during the transient operating point and released at t=0 (ngspice).
     */
    initialConditions: NodeInitialState[];
    /** Node-voltage Newton guesses from `.nodeset`. */
    nodeSets: NodeInitialState[];
}
/**
 * Programmatic circuit builder for constructing SPICE circuits without a netlist.
 *
 * Add devices, models, subcircuits, and analysis commands via the `add*` methods,
 * then call {@link Circuit.compile} to produce a {@link CompiledCircuit} for simulation.
 *
 * @example
 * ```ts
 * const ckt = new Circuit();
 * ckt.addVoltageSource('V1', 'in', '0', { dc: 5 });
 * ckt.addResistor('R1', 'in', 'out', 1000);
 * ckt.addResistor('R2', 'out', '0', 1000);
 * ckt.addAnalysis('op');
 * const result = await simulate(ckt);
 * ```
 */
declare class Circuit {
    private descriptors;
    private _analyses;
    private _poleZeroAnalyses;
    private _steps;
    private _models;
    /**
     * Upper-case instance-scoped names (`X1:NAME`) of `.model` cards defined
     * inside a subcircuit body. ngspice-47 subckt.c gives every subcircuit
     * instance its own copy of such a model, visible only to that body (#854).
     */
    private readonly _subcircuitModelNames;
    /** XSPICE code model cards, keyed by upper-case model name like {@link ModelTable}. */
    private _xspiceModels;
    private _subcircuits;
    /** Parser-only X cards retained until formal definitions are resolved. */
    private readonly _subcircuitCallCards;
    /** `.global` node names, keyed upper-case, valued with their first spelling. */
    private _globalNodes;
    /** Top-level `.param` values (upper-case names) visible inside subcircuits. */
    private _parameters;
    private _parameterScope;
    private _simulationOptions;
    private _temperature;
    private _xspiceTrtol;
    private _initialConditions;
    private _nodeSets;
    private nodeSet;
    private _controlScript?;
    private _parseWarnings;
    get analyses(): AnalysisDirective[];
    get poleZeroAnalyses(): PoleZeroAnalysis[];
    get simulationOptions(): Readonly<SimulationOptions>;
    setSimulationOptions(options: SimulationOptions): void;
    /**
     * Circuit temperature in degrees Celsius set by `.options TEMP=`, or
     * `undefined` for ngspice's default of 27 C.
     */
    get temperature(): number | undefined;
    /**
     * Set the circuit temperature in degrees Celsius (ngspice `.options TEMP=`).
     * Devices without an instance temperature are evaluated at it. A value other
     * than 27 C is rejected at compile time for devices whose temperature model
     * does not yet follow ngspice.
     */
    setTemperature(celsius: number): void;
    /**
     * ngspice `.options XTRTOL=` (integer, at least 1), or `undefined` when not
     * set. ngspice-47 cktdojob.c uses it instead of 1 as the trtol of a circuit
     * with XSPICE 'A' devices whose trtol is above 1; otherwise it has no effect.
     */
    get xspiceTrtol(): number | undefined;
    /**
     * Non-fatal netlist diagnostics recorded while parsing, such as ngspice's
     * "misplaced .endc card". {@link simulate} reports them as `parse` warnings.
     */
    get parseWarnings(): readonly string[];
    /** @internal Record a non-fatal parse diagnostic; see {@link parseWarnings}. */
    addParseWarning(message: string): void;
    /** Set the ngspice `.options XTRTOL=` value; see {@link xspiceTrtol}. */
    setXspiceTrtol(trtol: number | undefined): void;
    /**
     * @internal The deck's ngspice `.control` script when it needs the
     * control-language interpreter (set by the netlist parser).
     */
    get controlScript(): ControlScript | undefined;
    /** @internal */
    setControlScript(script: ControlScript | undefined): void;
    /**
     * @internal Capture everything a `.control` script can change (`alter`,
     * `altermod`, `option`) and return a function that puts it back, so running
     * a script never leaves the caller's Circuit edited.
     *
     * `alterInstance`/`alterModel`/`setSimulationOptions` replace the affected
     * fields with new objects rather than mutating them, so saving the field
     * references is a complete snapshot.
     */
    snapshotControlState(): () => void;
    /**
     * @internal ngspice `alter`: change an input parameter of a top-level
     * device, with the same effect as editing its card. `parameter` undefined
     * selects the primary value (resistance, capacitance, inductance, source DC).
     *
     * @returns undefined on success, or why the change is not supported
     */
    alterInstance(name: string, parameter: string | undefined, values: number[]): string | undefined;
    /**
     * @internal ngspice `altermod`: set a `.model` parameter, with the same effect
     * as writing it on the model card.
     *
     * @returns undefined on success, or why the change is not supported
     */
    alterModel(name: string, parameter: string, value: number): string | undefined;
    /**
     * @internal ngspice `@name[parameter]` readout of an input parameter of a
     * top-level device or `.model`, or undefined when spice-ts cannot report it
     * (operating-point quantities, internal parameters, subcircuit devices).
     */
    parameterVector(name: string, parameter: string): number[] | undefined;
    get initialConditions(): readonly NodeInitialState[];
    get nodeSets(): readonly NodeInitialState[];
    get nodeCount(): number;
    get branchCount(): number;
    getNodeIndex(name: string): number;
    /**
     * Add a resistor to the circuit.
     *
     * @param name - Device name (e.g., `'R1'`)
     * @param nodePos - Positive terminal node
     * @param nodeNeg - Negative terminal node
     * @param resistance - Resistance value in ohms. Omit when using a `.model R` card value.
     * @param instanceParams - ngspice instance parameters (e.g. `{ TC1: 1e-3, AC: 4e3, M: 2, NOISY: 0 }`)
     * @param modelName - Optional name of a `.model R` card
     */
    addResistor(name: string, nodePos: string, nodeNeg: string, resistance?: number, instanceParams?: Record<string, number>, modelName?: string): void;
    /**
     * Add a capacitor to the circuit.
     *
     * @param name - Device name (e.g., `'C1'`)
     * @param nodePos - Positive terminal node
     * @param nodeNeg - Negative terminal node
     * @param capacitance - Capacitance value in farads. Omit when using a `.model C` card value.
     * @param modelName - Optional name of a `.model C` card
     * @param instanceParams - Per-instance model parameters (e.g., `{ L: 10e-6, W: 1e-6, M: 2 }`)
     */
    addCapacitor(name: string, nodePos: string, nodeNeg: string, capacitance?: number, modelName?: string, instanceParams?: Record<string, number>, ic?: number): void;
    /**
     * Add an inductor to the circuit.
     *
     * @param name - Device name (e.g., `'L1'`)
     * @param nodePos - Positive terminal node
     * @param nodeNeg - Negative terminal node
     * @param inductance - Inductance value in henries. Omit when using a `.model L` card value.
     * @param modelName - Optional name of a `.model L` card
     * @param instanceParams - Per-instance model parameters (e.g., `{ NT: 10, SCALE: 2 }`)
     */
    addInductor(name: string, nodePos: string, nodeNeg: string, inductance?: number, modelName?: string, instanceParams?: Record<string, number>, ic?: number): void;
    /** Add a SPICE K-element coupling two previously declared inductors. */
    addInductorCoupling(name: string, indA: string, indB: string, coupling: number): void;
    /** Add a bounded ideal lossless T-element using characteristic impedance and delay. */
    addTransmissionLine(name: string, port1Positive: string, port1Negative: string, port2Positive: string, port2Negative: string, impedance: number, delay: number): void;
    /** Add a benchmark-bounded common-reference O-element backed by an LTRA model. */
    addLossyTransmissionLine(name: string, port1Positive: string, port1Negative: string, port2Positive: string, port2Negative: string, modelName: string): void;
    /**
     * Add an ngspice SWEC lossy line: a Y-element (TXL, one conductor) or a
     * P-element (CPL, `inputs.length` coupled conductors). All conductors are
     * referenced to ground, as in ngspice, which ignores the reference nodes.
     */
    addLossyLines(name: string, card: 'Y' | 'P', inputs: string[], outputs: string[], modelName: string, length?: number): void;
    /**
     * Add a voltage source to the circuit.
     *
     * @param name - Device name (e.g., `'V1'`)
     * @param nodePos - Positive terminal node
     * @param nodeNeg - Negative terminal node
     * @param waveform - Source waveform specification (DC, pulse, sine, or AC)
     * @param port - Optional ngspice RF port (`portnum`, `z0`, `pwr`, `freq`) for `.sp`
     */
    addVoltageSource(name: string, nodePos: string, nodeNeg: string, waveform: Partial<SourceWaveform> & {
        dc?: number;
    }, port?: RFPort): void;
    /**
     * Add a current source to the circuit.
     *
     * @param name - Device name (e.g., `'I1'`)
     * @param nodePos - Positive terminal node (current flows from pos to neg)
     * @param nodeNeg - Negative terminal node
     * @param waveform - Source waveform specification (DC, pulse, sine, or AC)
     * @param multiplier - ngspice `m` instance multiplier: the DC, transient and
     *   AC values are scaled by it (default 1); DISTOF terms are not.
     */
    addCurrentSource(name: string, nodePos: string, nodeNeg: string, waveform: Partial<SourceWaveform> & {
        dc?: number;
    }, multiplier?: number): void;
    /**
     * Add a voltage-controlled voltage source (VCVS, E-element).
     *
     * @param name - Device name (e.g., `'E1'`)
     * @param nOutP - Positive output node
     * @param nOutN - Negative output node
     * @param nCtrlP - Positive control (sensing) node
     * @param nCtrlN - Negative control (sensing) node
     * @param gain - Voltage gain (V/V)
     */
    addVCVS(name: string, nOutP: string, nOutN: string, nCtrlP: string, nCtrlN: string, gain: number): void;
    /**
     * Add a voltage-controlled current source (VCCS, G-element).
     *
     * @param name - Device name (e.g., `'G1'`)
     * @param nOutP - Positive output node
     * @param nOutN - Negative output node
     * @param nCtrlP - Positive control (sensing) node
     * @param nCtrlN - Negative control (sensing) node
     * @param gm - Transconductance (A/V)
     */
    addVCCS(name: string, nOutP: string, nOutN: string, nCtrlP: string, nCtrlN: string, gm: number): void;
    /**
     * Add a current-controlled voltage source (CCVS, H-element).
     *
     * @param name - Device name (e.g., `'H1'`)
     * @param nOutP - Positive output node
     * @param nOutN - Negative output node
     * @param controlSource - Name of the voltage source whose current controls this device
     * @param gain - Transresistance (V/A)
     */
    addCCVS(name: string, nOutP: string, nOutN: string, controlSource: string, gain: number): void;
    /**
     * Add a current-controlled current source (CCCS, F-element).
     *
     * @param name - Device name (e.g., `'F1'`)
     * @param nOutP - Positive output node
     * @param nOutN - Negative output node
     * @param controlSource - Name of the voltage source whose current controls this device
     * @param gain - Current gain (A/A)
     */
    addCCCS(name: string, nOutP: string, nOutN: string, controlSource: string, gain: number): void;
    /**
     * Add an ngspice voltage-controlled switch (S-element, `.model SW`).
     *
     * @param name - Device name (e.g., `'S1'`)
     * @param nodePos - Positive switch node
     * @param nodeNeg - Negative switch node
     * @param nCtrlP - Positive control node
     * @param nCtrlN - Negative control node
     * @param modelName - Name of a `.model ... SW` card
     * @param initiallyOn - Instance `ON` flag (default `OFF`)
     */
    addVoltageSwitch(name: string, nodePos: string, nodeNeg: string, nCtrlP: string, nCtrlN: string, modelName: string, initiallyOn?: boolean): void;
    /**
     * Add an ngspice current-controlled switch (W-element, `.model CSW`).
     *
     * @param name - Device name (e.g., `'W1'`)
     * @param nodePos - Positive switch node
     * @param nodeNeg - Negative switch node
     * @param controlSource - Voltage source whose current controls the switch
     * @param modelName - Name of a `.model ... CSW` card
     * @param initiallyOn - Instance `ON` flag (default `OFF`)
     */
    addCurrentSwitch(name: string, nodePos: string, nodeNeg: string, controlSource: string, modelName: string, initiallyOn?: boolean): void;
    /**
     * Add an ngspice B-source with an `I=` expression (current flows from
     * `nPlus` through the source to `nMinus`).
     *
     * @param name - Device name (e.g., `'B1'`)
     * @param nPlus - Positive node
     * @param nMinus - Negative node
     * @param expression - Parsed behavioral current expression
     */
    addBehavioralCurrentSource(name: string, nPlus: string, nMinus: string, expression: BehavioralExpression, params?: BehavioralInstanceParams): void;
    /**
     * Add an ngspice B-source with a `V=` expression: V(nPlus) - V(nMinus)
     * follows the expression, with a branch current like a `V` source.
     *
     * @param name - Device name (e.g., `'B1'`)
     * @param nPlus - Positive node
     * @param nMinus - Negative node
     * @param expression - Parsed behavioral voltage expression
     * @param params - ASRC instance parameters (`tc1`, `tc2`, `temp`, `dtemp`, `reciproctc`)
     */
    addBehavioralVoltageSource(name: string, nPlus: string, nMinus: string, expression: BehavioralExpression, params?: BehavioralInstanceParams): void;
    private addBehavioralSource;
    /**
     * Add an XSPICE A-element. Its connections are read against the port table
     * of its code model when the circuit is compiled, as ngspice does.
     *
     * @param card - Parsed A-card (see `parseXspiceInstance`)
     */
    addXspiceInstance(card: XspiceInstanceCard): void;
    /**
     * Add a `.model` card of an implemented XSPICE code model.
     *
     * @param model - Parsed card (see `parseXspiceModelCard`)
     */
    addXspiceModel(model: XspiceModelCard): void;
    /**
     * Add a Z-card device (NHFET level 5 or NMF level 2, chosen by its model).
     *
     * @param name - Device name (e.g., `'Z1'`)
     * @param nodeDrain - Drain node
     * @param nodeGate - Gate node
     * @param nodeSource - Source node
     * @param modelName - Name of an `NHFET` or `NMF` model
     * @param instanceParams - `L`/`W` instance parameters
     */
    addZDevice(name: string, nodeDrain: string, nodeGate: string, nodeSource: string, modelName: string, instanceParams?: Record<string, number>): void;
    /**
     * Add a diode to the circuit.
     *
     * @param name - Device name (e.g., `'D1'`)
     * @param nodeAnode - Anode node
     * @param nodeCathode - Cathode node
     * @param modelName - Name of a `.model D` card (optional; uses default diode model if omitted)
     * @param instanceParams - Per-instance geometry (`AREA`, `PJ`, and multiplier `M`)
     */
    addDiode(name: string, nodeAnode: string, nodeCathode: string, modelName?: string, instanceParams?: DiodeInstanceParams): void;
    /**
     * Add a bipolar junction transistor (BJT) to the circuit.
     *
     * @param name - Device name (e.g., `'Q1'`)
     * @param nodeCollector - Collector node
     * @param nodeBase - Base node
     * @param nodeEmitter - Emitter node
     * @param modelName - Name of a `.model NPN` or `.model PNP` card
     * @param nodeSubstrate - Optional substrate node. VBIC (LEVEL=4) and the
     *   Gummel-Poon BJT stamp their substrate junction to it; omitted, it is
     *   ground as in ngspice.
     * @param nodeThermal - Optional thermal node. Self-heating is not
     *   implemented, so compilation rejects it with an InvalidCircuitError.
     * @param instanceParams - Optional instance scaling (`AREA`, base/collector
     *   areas `AREAB`/`AREAC`, multiplier `M`), as in ngspice-47.
     */
    addBJT(name: string, nodeCollector: string, nodeBase: string, nodeEmitter: string, modelName: string, nodeSubstrate?: string, nodeThermal?: string, instanceParams?: BJTInstanceParams): void;
    /**
     * Add a bounded level-1/level-2 junction field-effect transistor
     * (`.model NJF` or `.model PJF`). `instanceParams.TEMP` is the ngspice
     * instance temperature; only the nominal 27 C is supported.
     */
    addJFET(name: string, nodeDrain: string, nodeGate: string, nodeSource: string, modelName: string, instanceParams?: JFETInstanceParams): void;
    /**
     * Add a MOSFET to the circuit.
     *
     * Supports Level 1 (Shichman-Hodges), Level 2 (Grove-Frohman), Level 6 (Sakurai-Newton) and
     * Level 49/8 (BSIM3v3) models.
     * Any other `LEVEL` raises {@link UnsupportedModelLevelError} at compile time.
     *
     * @param name - Device name (e.g., `'M1'`)
     * @param nodeDrain - Drain node
     * @param nodeGate - Gate node
     * @param nodeSource - Source node
     * @param modelName - Name of a `.model NMOS` or `.model PMOS` card
     * @param instanceParams - Per-instance parameters (e.g., `{ W: 1e-6, L: 0.18e-6 }`)
     * @param nodeBulk - Bulk/body node (optional; defaults to source if omitted)
     */
    addMOSFET(name: string, nodeDrain: string, nodeGate: string, nodeSource: string, modelName: string, instanceParams?: Record<string, number>, nodeBulk?: string): void;
    /**
     * Register a subcircuit definition for later instantiation with {@link addSubcircuitInstance}.
     *
     * @param def - Subcircuit definition (name, ports, default parameters, and body lines)
     */
    addSubcircuit(def: SubcktDefinition): void;
    /**
     * Declare `.global` nodes. Inside every subcircuit body these names bind to
     * the top-level net of the same name instead of an instance-local node, and
     * take precedence over a subcircuit port of the same name (ngspice
     * `gettrans`). Repeated declarations accumulate; ground (`0`) is always
     * global and is not recorded.
     */
    addGlobalNodes(names: readonly string[]): void;
    /** Declared `.global` node names, in declaration order. */
    get globalNodes(): string[];
    /**
     * Set top-level `.param` values. As in ngspice numparam, subcircuit
     * expressions (default parameter values, `{...}` values and B-source
     * expressions) see them unless a subcircuit parameter or a `.param` inside
     * the subcircuit shadows the name. {@link parseAsync} records the deck's
     * top-level parameters here. Names are case-insensitive; later values win.
     */
    setParameters(values: Readonly<Record<string, number>>): void;
    /** Top-level `.param` values visible inside subcircuits, keyed upper-case. */
    get parameters(): Record<string, number>;
    /**
     * Instantiate a subcircuit (X-element).
     *
     * The subcircuit must have been previously registered via {@link addSubcircuit}.
     * Internal nodes are automatically prefixed with the instance name.
     *
     * @param name - Instance name (e.g., `'X1'`)
     * @param ports - Actual node names to connect to the subcircuit's ports
     * @param subcktName - Name of the subcircuit definition to instantiate
     * @param params - Parameter overrides for this instance
     */
    addSubcircuitInstance(name: string, ports: string[], subcktName: string, params?: Record<string, number>, rawCard?: string): void;
    /**
     * Register a device model parameter card (`.model`).
     *
     * @param params - Model parameters including name, type (e.g., `'NPN'`, `'NMOS'`), and parameter values
     * @throws UnsupportedCircuitModelTypeError if no spice-ts device implements the model type
     */
    addModel(params: ModelParams): void;
    /** Store a model with its type upper-cased, rejecting unsupported types (#544). */
    private registerModel;
    /**
     * Add a simulation analysis command to the circuit.
     *
     * @param type - Analysis type: `'op'` (DC operating point), `'dc'` (DC sweep),
     *   `'tran'` (transient), or `'ac'` (AC small-signal)
     * @param params - Analysis-specific parameters (not required for `'op'`)
     */
    addAnalysis(type: 'op'): void;
    addAnalysis(type: 'dc', params: {
        source: string;
        start: number;
        stop: number;
        step: number;
        secondary?: DCSweepDimension;
    }): void;
    addAnalysis(type: 'tran', params: {
        timestep: number;
        stopTime: number;
        startTime?: number;
        maxTimestep?: number;
        useInitialConditions?: boolean;
    }): void;
    addAnalysis(type: 'ac', params: {
        variation: 'dec' | 'oct' | 'lin';
        points: number;
        startFreq: number;
        stopFreq: number;
    }): void;
    addAnalysis(type: 'noise', params: {
        outputNode: string;
        outputReferenceNode?: string;
        inputSource: string;
        variation: 'dec' | 'oct' | 'lin';
        points: number;
        startFreq: number;
        stopFreq: number;
        pointsPerSummary?: number;
    }): void;
    addAnalysis(type: 'sp', params: {
        variation: 'dec' | 'oct' | 'lin';
        points: number;
        startFreq: number;
        stopFreq: number;
        noise?: boolean;
    }): void;
    addAnalysis(type: 'disto', params: {
        variation: 'dec';
        points: number;
        startFreq: number;
        stopFreq: number;
        f2OverF1?: number;
    }): void;
    addAnalysis(type: 'tf', params: {
        outputNode: string;
        inputSource: string;
    } | {
        outputSource: string;
        inputSource: string;
    }): void;
    addAnalysis(type: 'pz', params: {
        inputPositive: string;
        inputNegative: string;
        outputPositive: string;
        outputNegative: string;
        inputType: 'cur' | 'vol';
        mode: 'pol' | 'zer' | 'pz';
    }): void;
    addAnalysis(type: 'sens', params: {
        outputNode: string;
        mode: 'dc';
    }): void;
    addAnalysis(type: 'sens', params: {
        outputNode: string;
        mode: 'ac';
        variation: 'dec' | 'oct' | 'lin';
        points: number;
        startFreq: number;
        stopFreq: number;
    }): void;
    /** Add a node voltage from `.ic` or `.nodeset`. */
    addInitialState(kind: 'ic' | 'nodeset', state: NodeInitialState): void;
    /**
     * Add a .step parametric sweep directive.
     *
     * @param param - Device name to sweep (e.g., 'R1')
     * @param opts - Sweep configuration
     */
    addStep(param: string, opts: {
        mode?: 'lin' | 'dec' | 'oct';
        start?: number;
        stop?: number;
        step?: number;
        points?: number;
        values?: number[];
    }): void;
    /**
     * Convert the circuit to an intermediate representation (IR).
     *
     * The IR is a flat, serialisable snapshot of every component with named ports,
     * typed parameters, and human-readable display values. It is suitable for
     * visualisation, export, or further transformation without running a simulation.
     *
     * @returns A {@link CircuitIR} with components and net names
     */
    toIR(): CircuitIR;
    /**
     * Serialize the programmatic circuit to a SPICE-like netlist.
     *
     * This is primarily used by external simulator backends that consume text
     * netlists. Raw subcircuit bodies are preserved exactly as registered.
     */
    toNetlist(): string;
    /**
     * Compile the circuit into a form ready for numerical simulation.
     *
     * Expands subcircuit instances, assigns node indices, instantiates device
     * models, and resolves model parameter cards.
     *
     * @returns A {@link CompiledCircuit} with device models and node/branch mappings
     * @throws Error if a referenced subcircuit or control source is undefined
     * @throws {@link CycleError} if subcircuit instances form a circular dependency
     */
    compile(guard?: ProtocolExecutionGuard): CompiledCircuit;
    /**
     * Evaluate the compiled devices at a non-nominal `.options TEMP` like ngspice.
     * Only devices whose temperature model follows ngspice-47 are accepted:
     * resistors (TC1/TC2 around TNOM), the bounded VBIC (vbictemp.c mapping),
     * B sources (asrctemp.c tc1/tc2 and `temper`), diodes (diotemp.c), the
     * Gummel-Poon BJT (bjttemp.c), MOS levels 1/2 (mos1temp.c/mos2temp.c) and BSIM3 (b3temp.c,
     * b3v32temp.c). Every other temperature-dependent element is rejected instead of silently
     * running at 27 C.
     */
    private applyCircuitTemperature;
    /** Top-level `.param` values as a prototype-free variable record for subcircuit scopes. */
    private parameterScope;
    /** Collect top-level and reachable subcircuit `.global` declarations. */
    private collectGlobalNodes;
    /** Expand X instances; non-X descriptors pass through unchanged. */
    private expandAllSubcircuits;
    /**
     * Validate O/LTRA instances after subcircuit expansion. Model lookup happens
     * here, not at parse time, because O cards in uncalled subcircuits may name
     * undefined models.
     */
    private expandLossyTransmissionLines;
    private expandPassiveParasitics;
    /**
     * Give a VDMOS instance its inner nodes (vdmosset.c): D'/G'/S' behind
     * RD/RG/RS and the body diode anode B' behind RB, each equal to the external
     * node when its resistance is zero. The resistors are stamped by the device,
     * because quasi saturation makes RD bias dependent.
     */
    private expandVdmosDescriptor;
    private expandCapacitorDescriptor;
    private expandInductorDescriptor;
    /**
     * Recursively expand a single subcircuit instance into flat device descriptors.
     *
     * @param instanceName  e.g. "X1" or "X0.X1" for nested
     * @param connectedPorts  actual node names connected to this instance's ports
     * @param subcktName  name of the subcircuit definition to instantiate
     * @param instanceParams  parameter overrides from the X line
     * @param visited  set of subcircuit names currently being expanded (cycle detection)
     */
    /**
     * Resolve a device's `.model` card, raising {@link InvalidCircuitError} when
     * it is undefined. ngspice refuses such instances ("Unable to find definition
     * of model"); falling back to defaults would silently simulate a different device.
     */
    /**
     * Reject instances whose model belongs to another device kind (e.g. an M
     * card naming an NPN model), before any device-specific expansion (#544).
     * Unknown model names are left to the per-device resolution paths.
     */
    private assertDeviceModelTypes;
    private requireModel;
    /**
     * ngspice-47 inp2l.c / inp2c.c applied to an expanded subcircuit card: a
     * value-less L/C line is ignored with a warning. Returns true to drop it.
     * The warning is recorded once even when compile() runs repeatedly.
     */
    private dropInvalidPassiveInstance;
    /**
     * Register the `.model` cards of one subcircuit instance body under their
     * instance-scoped names, returning upper-case local name -> scoped name.
     */
    private registerSubcircuitModels;
    private expandSubcircuit;
}

/** Load analysis engines only when an asynchronous simulation is requested. */
declare function simulate(input: string | Circuit, options?: SimulationOptions, guard?: ProtocolExecutionGuard): Promise<SimulationResult>;
declare function simulateStream(input: string | Circuit, options?: SimulationOptions): AsyncIterableIterator<TransientStep | ACPoint>;
declare function simulateStepStream(input: string | Circuit, options?: SimulationOptions): AsyncIterableIterator<StepStreamEvent>;
declare function createSimulator(simulator?: SimulatorBackend): SimulatorAdapter;

interface ProtocolValidationResultV1 {
    status: 'valid';
    nodeCount: number;
    branchCount: number;
    analysisCount: number;
}
/** Parse, compile, and validate topology without assembling or solving a matrix. */
declare function validateProtocolV1(request: SimulationRequestV1, execution?: ProtocolExecutionOptionsV1): Promise<ProtocolValidationResultV1>;
/** Execute a protocol-v1 request through the existing core simulator. */
declare function simulateProtocolV1(request: SimulationRequestV1, execution?: ProtocolExecutionOptionsV1): Promise<SimulationResultV1>;
/** Convert an existing typed core error to its stable protocol-v1 representation. */
declare function mapProtocolErrorV1(error: unknown): SpiceApiErrorV1;
/**
 * Result points a protocol run of `analyses` is estimated to produce before
 * solving, multiplied by the sweep count of the optional `.step` directive.
 * This is the count the `maxResultPoints` validation check compares. `reltol`
 * is the run's resolved relative tolerance, which sets ngspice's `.ac` DEC/OCT
 * stop tolerance.
 */
declare function estimateProtocolResultPointsV1(analyses: readonly AnalysisDirective[], step?: StepAnalysis, reltol?: number): number;

interface ProtocolEnvelopeExecutionOptionsV1 extends ProtocolExecutionOptionsV1 {
    /** Caller correlation id. Defaults to a deterministic id derived from the request. */
    requestId?: string;
}
/** Return a fresh JSON-safe capability document with stable protocol ordering. */
declare function protocolCapabilitiesV1(): ProtocolCapabilitiesV1;
/** Execute a bounded request and always resolve to a terminal protocol envelope. */
declare function executeProtocolV1(request: SimulationRequestV1, options?: ProtocolEnvelopeExecutionOptionsV1): Promise<ProtocolTerminalEnvelopeV1>;

type TopologyFailureKind = 'FLOATING_COMPONENT' | 'NO_DC_REFERENCE' | 'IDEAL_SOURCE_LOOP';
type TopologySourcePath = (deviceName: string) => string;
/** A topology failure proven without assembling or solving the MNA system. */
declare class TopologyPreflightError extends InvalidCircuitError {
    readonly kind: TopologyFailureKind;
    readonly involvedNodes: string[];
    readonly sourcePaths: string[];
    constructor(kind: TopologyFailureKind, involvedNodes: string[], sourcePaths: string[]);
}
/**
 * Reject topology singularities that can be established without numerical solve.
 * Diagnostics are code-point sorted and bounded so identical circuits produce
 * identical protocol details independent of declaration order.
 */
declare function preflightTopology(compiled: CompiledCircuit, sourcePath?: TopologySourcePath): void;

type FrequencySweep = Pick<ACAnalysis, 'variation' | 'points' | 'startFreq' | 'stopFreq'>;
/**
 * Which ngspice analysis owns the sweep. ngspice-47 `.ac` (acan.c) stretches DEC sweeps that
 * span at least one decade so the last point lands on stop, and builds every grid by
 * accumulation (see {@link acanGrid}); `.noise` (noisean.c) always steps by 10^(1/N) up to stop
 * plus a reltol tolerance; `.sens` (cktsens.c `count_steps`) also steps
 * by 10^(1/N) but counts `(int)(N * log10(stop/start) + 1.01)` points (see
 * {@link sensitivityPointCount} for OCT and LIN). `.sp` (span.c) steps DEC/OCT like `.noise`
 * and LIN like `.ac`.
 */
type FrequencySweepKind = 'ac' | 'noise' | 'sens' | 'sp';
/**
 * Number of points in an ngspice `.ac`/`.noise`/`.sens` sweep: LIN is N total points, except
 * that `.ac` (acan.c) only steps when `N - 1 > 1`, so `.ac lin 2` is the single start point;
 * DEC/OCT step by the analysis' ratio (see {@link FrequencySweepKind}); `.ac`/`.noise` keep
 * every point up to stop plus ngspice's `ratio * stop * reltol` tolerance.
 */
declare function frequencyPointCount(sweep: FrequencySweep, relativeTolerance: number, kind: FrequencySweepKind): number;
/** Frequencies of an ngspice `.ac`/`.noise`/`.sens` sweep; see {@link frequencyPointCount}. */
declare function frequencyGrid(sweep: FrequencySweep, relativeTolerance: number, kind: FrequencySweepKind): number[];

/**
 * Resumable transient simulation driver.
 *
 * Call {@link createTransientSim} to obtain one. Use {@link advance} or
 * {@link advanceUntil} to step the simulation forward, {@link reset} to
 * restart at t=0, and {@link dispose} when done.
 */
interface TransientSim {
    readonly simTime: number;
    readonly stopTime: number | undefined;
    readonly isDone: boolean;
    /** Immutable snapshot of convergence counters accumulated so far. */
    readonly convergence: ConvergenceTelemetry;
    /** Advance one converged timestep. Throws {@link ConvergenceError} on failure. */
    advance(): TransientStep;
    /** Convenience: loop {@link advance} until `simTime >= targetTime`. */
    advanceUntil(targetTime: number): TransientStep[];
    /** Re-run DC operating point, clear history, reset simTime to 0. */
    reset(): void;
    /** Release solver memory. Subsequent calls throw. */
    dispose(): void;
}
interface TransientSimOptions extends SimulationOptions {
    stopTime?: number;
    timestep?: number;
    maxTimestep?: number;
}
declare function createTransientSim(input: string | Circuit, options?: TransientSimOptions): Promise<TransientSim>;

type NgspiceComplex = {
    real: number;
    img: number;
};
type NgspiceData = {
    name: string;
    type: string;
    values: number[] | NgspiceComplex[];
};
type NgspiceResult = {
    numVariables: number;
    numPoints: number;
    dataType: 'real' | 'complex';
    data: NgspiceData[];
};
type NgspiceSimulation = {
    start(): Promise<void>;
    setNetList(input: string): void;
    runSim(): Promise<NgspiceResult>;
    getError(): string[];
};
type NgspiceSimulationClass = new () => NgspiceSimulation;
interface WasmNgspiceSimulatorOptions {
    /** Optional injected Simulation class, useful for tests or custom bundlers. */
    Simulation?: NgspiceSimulationClass;
}
/**
 * Optional ngspice WASM simulator backend powered by `eecircuit-engine`.
 *
 * The package is loaded lazily so the default TypeScript simulator remains
 * dependency-light unless this backend is selected.
 */
declare class WasmNgspiceSimulator implements SimulatorAdapter {
    private readonly options;
    readonly name = "ngspice-wasm";
    constructor(options?: WasmNgspiceSimulatorOptions);
    simulate(input: string | Circuit, options?: SimulationOptions): Promise<SimulationResult>;
    private runStepAnalyses;
    private runAnalyses;
    private runRaw;
    private loadSimulationClass;
}

/** A V/I card uses a source waveform keyword (`EXTERNAL`) spice-ts does not implement. */
declare class UnsupportedSourceWaveformError extends ParseError {
    /** Upper-cased waveform keyword, e.g. `EXTERNAL`. */
    readonly keyword: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_SOURCE_WAVEFORM";
    constructor(
    /** Upper-cased waveform keyword, e.g. `EXTERNAL`. */
    keyword: string, message: string, line: number, context: string);
}

/**
 * `.model` types that a spice-ts device consumes. Every other type is rejected
 * at parse time: storing it would let an instance that references the card
 * simulate with no model at all (issue #509).
 */
declare const SUPPORTED_MODEL_TYPES: ReadonlySet<string>;
/**
 * Model types each model-referencing instance accepts, keyed by SPICE instance
 * letter (ngspice-47 rejects an instance whose model belongs to another device
 * kind). Every listed type is in {@link SUPPORTED_MODEL_TYPES}.
 */
declare const DEVICE_MODEL_TYPES: Readonly<Record<string, readonly string[]>>;
/**
 * Thrown when a `.model` card declares a type that no spice-ts device
 * implements (for example `PHFET` or `URC`).
 */
declare class UnsupportedModelTypeError extends ParseError {
    /** Model name as written on the `.model` card */
    readonly modelName: string;
    /** Upper-cased model type from the `.model` card */
    readonly modelType: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_TYPE";
    constructor(
    /** Model name as written on the `.model` card */
    modelName: string, 
    /** Upper-cased model type from the `.model` card */
    modelType: string, line: number, context: string);
}

/**
 * Thrown for a resistor card or `.model R` parameter that spice-ts does not
 * simulate (for example PSpice `T_REL_LOCAL`, or a quoted
 * behavioral expression such as `R='res + V(x)'`). The card is rejected rather
 * than simulated without the parameter.
 */
declare class UnsupportedResistorParameterError extends ParseError {
    /** Resistor instance or `.model` name */
    readonly elementName: string;
    /** Upper-cased unsupported parameter names (or the offending value token) */
    readonly parameters: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_RESISTOR_PARAMETER";
    constructor(
    /** Resistor instance or `.model` name */
    elementName: string, 
    /** Upper-cased unsupported parameter names (or the offending value token) */
    parameters: readonly string[], line: number, context: string, detail?: string);
}

/**
 * Thrown for a bare (valueless) `.model` token that is neither an ngspice-47
 * `IF_FLAG` model parameter of the card's type nor a parameter name followed
 * by its value, or for a polarity flag that contradicts the card type. Such
 * tokens used to be dropped silently, so a card could simulate with a
 * different model than the one written.
 */
declare class UnsupportedModelFlagError extends ParseError {
    /** Model name as written on the `.model` card */
    readonly modelName: string;
    /** Upper-cased model type */
    readonly modelType: string;
    /** Upper-cased offending token */
    readonly flag: string;
    /** Bare flags ngspice-47 accepts for this model type */
    readonly acceptedFlags: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MODEL_FLAG";
    constructor(
    /** Model name as written on the `.model` card */
    modelName: string, 
    /** Upper-cased model type */
    modelType: string, 
    /** Upper-cased offending token */
    flag: string, 
    /** Bare flags ngspice-47 accepts for this model type */
    acceptedFlags: readonly string[], line: number, context: string, detail?: string);
}

/**
 * Parse a standard SPICE deck into a {@link Circuit} object.
 *
 * SPICE reserves the first physical line as the deck title. It is always
 * discarded, even when its text has the shape of a device or directive. Use
 * {@link parseTitleless} for generated fragments that omit the title line.
 *
 * Handles device lines (R, C, L, V, I, D, Q, J, M, E, G, H, F, X),
 * dot commands (`.op`, `.dc`, `.tran`, `.ac`, `.model`, `.subckt`),
 * and subcircuit definitions. Runs the same `.param`/`.func`/`.if`
 * preprocessing as {@link parseAsync} and `simulate()`, so a deck that
 * `simulate()` accepts also parses here. Does not resolve `.include` or `.lib`
 * file directives -- use {@link parseAsync} for netlists with file includes.
 *
 * @param netlist - SPICE netlist text (may include line continuations with `+`)
 * @returns A {@link Circuit} ready for compilation and simulation
 * @throws {@link ParseError} if the netlist contains syntax errors or unknown device types
 * @example
 * ```ts
 * const circuit = parse(`
 *   V1 in 0 DC 5
 *   R1 in out 1k
 *   R2 out 0 1k
 *   .op
 * `);
 * const compiled = circuit.compile();
 * ```
 */
declare function parse(netlist: string): Circuit;
/**
 * Parse a title-less SPICE fragment.
 *
 * Unlike {@link parse}, the first physical line is parsed as a device or
 * directive. Use this explicit API for generated snippets that omit the
 * standard SPICE title line.
 */
declare function parseTitleless(netlist: string): Circuit;
/**
 * Parse a SPICE netlist with async resolution of `.include` and `.lib` directives.
 *
 * Preprocesses the netlist first (resolving includes, `.param` substitution,
 * expression evaluation), then delegates to {@link parse}.
 *
 * @param netlist - SPICE netlist text, possibly containing `.include`/`.lib` directives
 * @param resolver - Async function that returns file contents given a path
 * @returns A {@link Circuit} ready for compilation and simulation
 * @throws {@link ParseError} if the netlist contains syntax errors
 * @throws {@link CycleError} if `.include`/`.lib` directives form a circular dependency
 * @example
 * ```ts
 * const circuit = await parseAsync(netlist, async (path) => {
 *   return await fs.readFile(path, 'utf-8');
 * });
 * ```
 */
declare function parseAsync(netlist: string, resolver?: IncludeResolver): Promise<Circuit>;
/** Parse and preprocess a title-less SPICE fragment. */
declare function parseTitlelessAsync(netlist: string, resolver?: IncludeResolver, guard?: ProtocolExecutionGuard): Promise<Circuit>;

/**
 * Preprocess a SPICE netlist: resolve `.include`/`.lib` directives,
 * evaluate `.param` definitions, and substitute `{expression}` tokens.
 *
 * This is called internally by {@link parseAsync} but can be used
 * standalone when you need the fully-expanded netlist text.
 *
 * @param netlist - Raw SPICE netlist text
 * @param resolver - Async function that returns file contents given a path;
 *   required if the netlist contains `.include` or `.lib` directives
 * @returns The preprocessed netlist with all includes inlined and expressions evaluated
 * @throws {@link ParseError} if include depth exceeds 64, resolver is missing,
 *   or a `{expression}` references an undefined or circular `.param`
 * @throws {@link CycleError} if includes form a circular dependency
 */
declare function preprocess(netlist: string, resolver?: IncludeResolver, guard?: ProtocolExecutionGuard): Promise<string>;

declare class VCVS implements DeviceModel {
    readonly name: string;
    readonly nodes: number[];
    readonly branchIndex: number;
    readonly gain: number;
    readonly branches: number[];
    readonly isNonlinear = false;
    constructor(name: string, nodes: number[], branchIndex: number, gain: number);
    stamp(ctx: StampContext): void;
    stampAC(ctx: StampContext, _omega: number): void;
}

declare class VCCS implements DeviceModel {
    readonly name: string;
    readonly nodes: number[];
    readonly gm: number;
    readonly branches: number[];
    readonly isNonlinear = false;
    constructor(name: string, nodes: number[], gm: number);
    stamp(ctx: StampContext): void;
    stampAC(ctx: StampContext, _omega: number): void;
}

declare class CCVS implements DeviceModel {
    readonly name: string;
    readonly nodes: number[];
    /** Controlling source's branch; see {@link bindControlBranch}. */
    controlBranchIndex: number;
    readonly branchIndex: number;
    readonly gain: number;
    readonly branches: number[];
    readonly isNonlinear = false;
    constructor(name: string, nodes: number[], 
    /** Controlling source's branch; see {@link bindControlBranch}. */
    controlBranchIndex: number, branchIndex: number, gain: number);
    /** Bind the controlling source's MNA branch (ngspice CCVSsetup), which may follow this card. */
    bindControlBranch(branch: number): void;
    stamp(ctx: StampContext): void;
    stampAC(ctx: StampContext, _omega: number): void;
}

declare class CCCS implements DeviceModel {
    readonly name: string;
    readonly nodes: number[];
    /** Controlling source's branch; see {@link bindControlBranch}. */
    controlBranchIndex: number;
    readonly gain: number;
    readonly branches: number[];
    readonly isNonlinear = false;
    constructor(name: string, nodes: number[], 
    /** Controlling source's branch; see {@link bindControlBranch}. */
    controlBranchIndex: number, gain: number);
    /** Bind the controlling source's MNA branch (ngspice CCCSsetup), which may follow this card. */
    bindControlBranch(branch: number): void;
    stamp(ctx: StampContext): void;
    stampAC(ctx: StampContext, _omega: number): void;
}

/**
 * Thrown for a `.meas`/`.measure` form ngspice-47 evaluates but spice-ts does
 * not (for example `.meas sp`, or a `par()` operand in an AC measurement).
 * Never silently skipped. A measurement ngspice itself rejects is not an
 * error: it is reported in `SimulationResult.measurements` with
 * `status: 'failed'`, as ngspice prints it and continues.
 */
declare class UnsupportedMeasureError extends ParseError {
    /** Why this measurement form is not evaluated. */
    readonly reason: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_MEASURE";
    constructor(
    /** Why this measurement form is not evaluated. */
    reason: string, line: number, context: string);
}

/**
 * Thrown for an ngspice control-language command (or a command form, function,
 * vector or variable) that spice-ts does not execute. Raised while parsing the
 * `.control` block when the command name alone decides it, and while running the
 * script when only the arguments do (for example `alter` on a device inside a
 * subcircuit). Never silently ignored.
 */
declare class UnsupportedControlCommandError extends ParseError {
    /** Control-language command name as written, e.g. `meas`. */
    readonly command: string;
    /** Why this command (or this form of it) is not executed. */
    readonly reason: string;
    /** Stable machine-readable error code. */
    readonly code = "UNSUPPORTED_CONTROL_COMMAND";
    constructor(
    /** Control-language command name as written, e.g. `meas`. */
    command: string, 
    /** Why this command (or this form of it) is not executed. */
    reason: string, line: number, context: string);
}
/**
 * Thrown when a supported control-language command fails while the script runs
 * (unknown vector, bad expression, index out of range, ...). ngspice prints such
 * errors and continues; spice-ts stops so a wrong result is never returned.
 */
declare class ControlScriptError extends SpiceError {
    /** 1-based line number of the control command */
    readonly line: number;
    /** Text of the control command */
    readonly context: string;
    /** Stable machine-readable error code. */
    readonly code = "CONTROL_SCRIPT_ERROR";
    constructor(message: string, 
    /** 1-based line number of the control command */
    line: number, 
    /** Text of the control command */
    context: string);
}
/**
 * Thrown when a `.control` script ends with a non-zero `quit`/`exit` status,
 * which ngspice's own regression decks use to report a failed self-check.
 * ngspice exits with that status in batch mode, so spice-ts fails the run too.
 */
declare class ControlScriptExitError extends SpiceError {
    /** The status passed to `quit`/`exit`. */
    readonly exitCode: number;
    /** 1-based line number of the `quit`/`exit` command */
    readonly line: number;
    /** Lines the script printed with `echo` before exiting. */
    readonly output: readonly string[];
    /** Stable machine-readable error code. */
    readonly code = "CONTROL_SCRIPT_EXIT";
    constructor(
    /** The status passed to `quit`/`exit`. */
    exitCode: number, 
    /** 1-based line number of the `quit`/`exit` command */
    line: number, 
    /** Lines the script printed with `echo` before exiting. */
    output: readonly string[]);
}

export { type ACPoint, ACResult, type AmSource, type AnalysisCommand, type AnalysisDirective, CCCS, CCVS, Circuit, type CircuitIR, type CompiledCircuit, type ComplexDistortionValue, type ComplexSensitivityValue, type ComplexValue, type ComponentType, ControlScriptError, ControlScriptExitError, type ControlScriptResult, type ControlScriptRun, ConvergenceError, type ConvergenceFailureKind, type ConvergenceTelemetry, CycleError, type DCConvergenceTelemetry, DCResult, DCSweepResult, DEVICE_MODEL_TYPES, type DeviceModel, type DigitalNodeEvent, type DistortionAnalysis, type DistortionExcitation, type DistortionIntermodulationProduct, type DistortionOrder, type DistortionProduct, DistortionResult, type ExpSource, type FrequencySweepKind, type IRComponent, type IRPort, type IncludeResolver, type IntegrationMethod, InvalidCircuitError, type MeasurementResult, type ModelParams, ModelTypeMismatchError, type NodeInitialState, type NoiseAnalysis, NoiseResult, ParseError, type PoleZeroAnalysis, PoleZeroResult, type PoleZeroValue, type ProtocolAbortSignalV1, type ProtocolCapabilitiesV1, type ProtocolCompletionV1, type ProtocolEnvelopeExecutionOptionsV1, type ProtocolExecutionMetadataV1, type ProtocolExecutionOptionsV1, type ProtocolFailureEnvelopeV1, type ProtocolSafePointV1, type ProtocolSuccessEnvelopeV1, type ProtocolTerminalEnvelopeV1, type ProtocolValidationResultV1, type RFPort, type SParameterAnalysis, SParameterResult, SUPPORTED_MODEL_TYPES, type SensitivityAnalysis, type SensitivityEntry, SensitivityResult, type SffmSource, type SimulationOptions, type SimulationResult, type SimulatorAdapter, type SimulatorBackend, type SimulatorBackendName, SingularMatrixError, type SourceWaveform, SpiceError, type StampContext, type StepAnalysis, type StepResult, type StepStreamEvent, type StepSweepMode, type StepWorker, type StepWorkerCompletion, type StepWorkerOptions, type StepWorkerTask, type SubcktDefinition, TimestepTooSmallError, type TopologyFailureKind, TopologyPreflightError, type TopologySourcePath, type TransferFunctionAnalysis, TransferFunctionResult, type TransientConvergenceTelemetry, type TransientNoiseSource, type TransientRandomSource, TransientResult, type TransientSim, type TransientSimOptions, type TransientStep, UnsupportedCircuitModelTypeError, UnsupportedCodeModelError, UnsupportedControlCommandError, UnsupportedMeasureError, UnsupportedModelFlagError, UnsupportedModelLevelError, UnsupportedModelParameterError, UnsupportedModelTypeError, UnsupportedModelVersionError, UnsupportedMultiplicityError, UnsupportedResistorParameterError, UnsupportedSourceWaveformError, UnsupportedTemperatureError, VCCS, VCVS, WasmNgspiceSimulator, type WasmNgspiceSimulatorOptions, createSimulator, createTransientSim, estimateProtocolResultPointsV1, executeProtocolV1, frequencyGrid, frequencyPointCount, mapProtocolErrorV1, parse, parseAsync, parseTitleless, parseTitlelessAsync, preflightTopology, preprocess, protocolCapabilitiesV1, simulate, simulateProtocolV1, simulateStepStream, simulateStream, validateProtocolV1 };
