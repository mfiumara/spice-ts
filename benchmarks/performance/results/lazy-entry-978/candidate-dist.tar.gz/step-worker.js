import {
  executeStepWorkerMessage
} from "./chunk-JC3KQZAV.js";
import "./chunk-BLWJHVLO.js";
import "./chunk-3G2EU3P5.js";

// src/analysis/step-worker.ts
void import("worker_threads").then(({ parentPort }) => {
  if (!parentPort) throw new Error("Step worker started without a parent port");
  const port = {
    postMessage: (message) => parentPort.postMessage(message),
    onMessage: (listener) => parentPort.on("message", listener)
  };
  port.onMessage((message) => {
    void executeStepWorkerMessage(message, port);
  });
});
//# sourceMappingURL=step-worker.js.map