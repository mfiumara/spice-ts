import {
  executeStepWorkerMessage
} from "./chunk-JC3KQZAV.js";
import "./chunk-BLWJHVLO.js";
import "./chunk-3G2EU3P5.js";

// src/analysis/step-worker-browser.ts
var scope = globalThis;
var port = {
  postMessage: (message) => scope.postMessage(message),
  onMessage: (listener) => scope.addEventListener("message", (event) => listener(event.data))
};
port.onMessage((message) => {
  void executeStepWorkerMessage(message, port);
});
//# sourceMappingURL=step-worker-browser.js.map