import {
  ACResult,
  BJT,
  BSIM3v3,
  CCCS,
  CCVS,
  Capacitor,
  Circuit,
  ClassicBsimMosfet,
  ControlScriptError,
  ControlScriptExitError,
  ConvergenceError,
  CurrentSource,
  CycleError,
  DCResult,
  DCSweepResult,
  DEFAULT_OPTIONS,
  DEVICE_MODEL_TYPES,
  DistortionResult,
  Inductor,
  InvalidCircuitError,
  MOS2,
  MOS3,
  MOS6,
  MOSFET,
  ModelTypeMismatchError,
  NodeShunt,
  NoiseResult,
  ParseError,
  PoleZeroResult,
  ProtocolExecutionError,
  ProtocolExecutionGuard,
  SParameterResult,
  SUPPORTED_MODEL_TYPES,
  SensitivityResult,
  SingularMatrixError,
  SpiceError,
  TimestepTooSmallError,
  TransferFunctionResult,
  TransientResult,
  UnsupportedCircuitModelTypeError,
  UnsupportedCodeModelError,
  UnsupportedControlCommandError,
  UnsupportedMeasureError,
  UnsupportedModelFlagError,
  UnsupportedModelLevelError,
  UnsupportedModelParameterError,
  UnsupportedModelTypeError,
  UnsupportedModelVersionError,
  UnsupportedMultiplicityError,
  UnsupportedResistorParameterError,
  UnsupportedSourceWaveformError,
  UnsupportedTemperatureError,
  VCCS,
  VCVS,
  VOLTAGE_SOURCE_MULTIPLIER_ERROR,
  VoltageSource,
  WasmNgspiceSimulator,
  accumulatedLinearPointCount,
  createSimulator,
  createTransientSim,
  directedLinearPointCount,
  frequencyGrid,
  frequencyPointCount,
  isValidMaxTimestepOption,
  parse,
  parseAsync,
  parseTitleless,
  parseTitlelessAsync,
  preprocess,
  simulate,
  simulateStepStream,
  simulateStream
} from "./chunk-S7SFAIC6.js";

// src/validation/topology-preflight.ts
var GROUND_INDEX = -1;
var MAX_DETAILS = 32;
var TopologyPreflightError = class extends InvalidCircuitError {
  constructor(kind, involvedNodes, sourcePaths) {
    super(topologyMessage(kind));
    this.kind = kind;
    this.involvedNodes = involvedNodes;
    this.sourcePaths = sourcePaths;
    this.name = "TopologyPreflightError";
  }
  kind;
  involvedNodes;
  sourcePaths;
};
function preflightTopology(compiled, sourcePath = compiledDevicePath) {
  const allNodes = [GROUND_INDEX, ...compiled.nodeNames.map((_, index) => index)];
  const physical = graph(allNodes);
  const shunted = compiled.devices.some((device) => device instanceof NodeShunt);
  for (const device of compiled.devices) connectAll(physical, device.nodes);
  if (shunted) connectAll(physical, allNodes);
  const physicallyGrounded = reachable(physical, GROUND_INDEX);
  const floating = compiled.nodeNames.map((_, index) => index).filter((index) => !physicallyGrounded.has(index));
  if (floating.length > 0) {
    throw topologyError("FLOATING_COMPONENT", compiled, floating, sourcePath);
  }
  const needsDcOperatingPoint = compiled.poleZeroAnalyses.length > 0 || compiled.analyses.some(
    (analysis) => analysis.type !== "tran" || !analysis.useInitialConditions
  );
  if (needsDcOperatingPoint) {
    const dc = graph(allNodes);
    if (shunted) connectAll(dc, allNodes);
    for (const device of compiled.devices) {
      for (const group of dcConnectionGroups(device)) connectAll(dc, group);
    }
    const dcGrounded = reachable(dc, GROUND_INDEX);
    const withoutDcReference = compiled.nodeNames.map((_, index) => index).filter((index) => !dcGrounded.has(index));
    if (withoutDcReference.length > 0) {
      throw topologyError("NO_DC_REFERENCE", compiled, withoutDcReference, sourcePath);
    }
  }
  const loop = findIdealConstraintLoop(compiled.devices, needsDcOperatingPoint);
  if (loop) {
    const nodes = uniqueSorted(loop.flatMap((edge) => [edge.left, edge.right])).map((index) => nodeName(compiled, index));
    const paths = sortedBounded(loop.map((edge) => sourcePath(edge.device.name)));
    throw new TopologyPreflightError("IDEAL_SOURCE_LOOP", nodes, paths);
  }
}
function topologyError(kind, compiled, nodeIndices, sourcePath) {
  const invalid = new Set(nodeIndices);
  const involvedNodes = sortedBounded(nodeIndices.map((index) => nodeName(compiled, index)));
  const sourcePaths = sortedBounded(compiled.devices.filter((device) => device.nodes.some((node) => invalid.has(node))).map((device) => sourcePath(device.name)));
  return new TopologyPreflightError(kind, involvedNodes, sourcePaths);
}
function dcConnectionGroups(device) {
  if (device instanceof Capacitor || device instanceof CurrentSource || device instanceof CCCS) return [];
  if (device instanceof VCCS) {
    const [outP, outN, ctrlP, ctrlN] = device.nodes;
    const hasDiagonalStamp = [...new Set(device.nodes)].some(
      (node) => node >= 0 && terminalCoefficient(node, outP, outN) !== 0 && terminalCoefficient(node, ctrlP, ctrlN) !== 0
    );
    return hasDiagonalStamp ? [[ctrlP, ctrlN]] : [];
  }
  if (device instanceof VCVS || device instanceof CCVS) {
    return [device.nodes.slice(0, 2)];
  }
  if (device instanceof MOSFET || device instanceof MOS2 || device instanceof MOS3 || device instanceof MOS6 || device instanceof BSIM3v3 || device instanceof ClassicBsimMosfet) {
    return [[device.nodes[0], device.nodes[2], device.nodes[3] ?? device.nodes[2]]];
  }
  if (device instanceof BJT) return [device.nodes];
  return device.nodes.length > 0 ? [device.nodes] : [];
}
function terminalCoefficient(node, positive, negative) {
  return Number(node === positive) - Number(node === negative);
}
function findIdealConstraintLoop(devices, includeInductors) {
  const edges = devices.filter(
    (device) => device instanceof VoltageSource || device instanceof VCVS || device instanceof CCVS || includeInductors && device instanceof Inductor
  ).map((device) => ({
    device,
    left: device instanceof VoltageSource ? device.sourceNode : device.nodes[0],
    right: device.nodes[1]
  })).sort((left, right) => compareCodePoints(left.device.name, right.device.name));
  const forest = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const path = forestPath(forest, edge.left, edge.right);
    if (path) return [...path, edge];
    addForestEdge(forest, edge.left, edge.right, edge);
    addForestEdge(forest, edge.right, edge.left, edge);
  }
  return void 0;
}
function forestPath(forest, start, target) {
  if (start === target) return [];
  const queue = [{ node: start, path: [] }];
  const seen = /* @__PURE__ */ new Set([start]);
  while (queue.length > 0) {
    const current = queue.shift();
    const neighbors = [...forest.get(current.node) ?? []].sort((left, right) => compareCodePoints(left.edge.device.name, right.edge.device.name));
    for (const next of neighbors) {
      if (seen.has(next.node)) continue;
      const path = [...current.path, next.edge];
      if (next.node === target) return path;
      seen.add(next.node);
      queue.push({ node: next.node, path });
    }
  }
  return void 0;
}
function addForestEdge(forest, from, to, edge) {
  const neighbors = forest.get(from) ?? [];
  neighbors.push({ node: to, edge });
  forest.set(from, neighbors);
}
function graph(nodes) {
  return new Map(nodes.map((node) => [node, /* @__PURE__ */ new Set()]));
}
function connectAll(adjacency, nodes) {
  const unique = [...new Set(nodes)];
  for (let index = 1; index < unique.length; index++) {
    connect(adjacency, unique[0], unique[index]);
  }
}
function connect(adjacency, left, right) {
  adjacency.get(left)?.add(right);
  adjacency.get(right)?.add(left);
}
function reachable(adjacency, start) {
  const seen = /* @__PURE__ */ new Set([start]);
  const queue = [start];
  while (queue.length > 0) {
    const current = queue.shift();
    for (const next of adjacency.get(current) ?? []) {
      if (seen.has(next)) continue;
      seen.add(next);
      queue.push(next);
    }
  }
  return seen;
}
function nodeName(compiled, index) {
  return index === GROUND_INDEX ? "0" : compiled.nodeNames[index];
}
function compiledDevicePath(name) {
  return `/compiled/devices/${jsonPointerSegment(name)}`;
}
function jsonPointerSegment(value) {
  return value.replaceAll("~", "~0").replaceAll("/", "~1");
}
function sortedBounded(values) {
  return [...new Set(values)].sort(compareCodePoints).slice(0, MAX_DETAILS);
}
function uniqueSorted(values) {
  return [...new Set(values)].sort((left, right) => left - right);
}
function compareCodePoints(left, right) {
  const a = Array.from(left, (character) => character.codePointAt(0));
  const b = Array.from(right, (character) => character.codePointAt(0));
  for (let index = 0; index < Math.min(a.length, b.length); index++) {
    if (a[index] !== b[index]) return a[index] - b[index];
  }
  return a.length - b.length;
}
function topologyMessage(kind) {
  switch (kind) {
    case "FLOATING_COMPONENT":
      return "Circuit contains a floating connected component";
    case "NO_DC_REFERENCE":
      return "Circuit contains nodes without a DC reference path";
    case "IDEAL_SOURCE_LOOP":
      return "Circuit contains an ideal voltage-source/inductor loop";
  }
}

// src/protocol/adapter.ts
var MAX_DETAIL_NAMES = 32;
var API_ERROR_CODES = /* @__PURE__ */ new Set([
  "INVALID_REQUEST",
  "PARSE_ERROR",
  "INVALID_CIRCUIT",
  "UNSUPPORTED_FEATURE",
  "SINGULAR_MATRIX",
  "CONVERGENCE_FAILED",
  "TIMESTEP_TOO_SMALL",
  "RESOURCE_LIMIT",
  "CANCELLED",
  "BACKEND_UNAVAILABLE",
  "INTERNAL_ERROR"
]);
var API_ERROR_PHASES = /* @__PURE__ */ new Set([
  "validation",
  "parse",
  "compile",
  "solve",
  "serialize",
  "transport"
]);
async function validateProtocolV1(request, execution) {
  const guard = protocolGuard(request, execution);
  enforceInputLimits(request, guard);
  const circuit = await requestCircuit(request, guard);
  guard.maximum("maxAnalyses", circuit.analyses.length, "validation");
  const compiled = circuit.compile(guard);
  enforcePointLimit(circuit.analyses, guard, requestReltol(request, circuit), compiled.steps[0]);
  if (compiled.nodeCount === 0) throw new InvalidCircuitError("Circuit has no nodes");
  if (compiled.analyses.length === 0) throw new InvalidCircuitError("No analysis command specified");
  preflightTopology(compiled, protocolSourcePath(request));
  return {
    status: "valid",
    nodeCount: compiled.nodeCount,
    branchCount: compiled.branchCount,
    analysisCount: compiled.analyses.length
  };
}
async function simulateProtocolV1(request, execution) {
  const guard = protocolGuard(request, execution);
  enforceInputLimits(request, guard);
  const circuit = await requestCircuit(request, guard);
  const analyses = circuit.analyses.map(protocolAnalysis);
  guard.maximum("maxAnalyses", analyses.length, "validation");
  const preflight = circuit.compile(guard);
  enforcePointLimit(analyses, guard, requestReltol(request, circuit), preflight.steps[0]);
  preflightTopology(preflight, protocolSourcePath(request));
  const options = coreOptions(request.options);
  const serialized = [];
  for (let analysisIndex = 0; analysisIndex < analyses.length; analysisIndex++) {
    const analysis = analyses[analysisIndex];
    circuit.analyses.splice(0, circuit.analyses.length, analysis);
    const compiled = circuit.compile(guard);
    const result = await simulate(circuit, options, guard);
    const completedBefore = serialized.length;
    appendAnalysisResult(serialized, result, analysis, analysisIndex, compiled.nodeNames, compiled.branchNames, circuit);
    for (const completed of serialized.slice(completedBefore)) execution?.onAnalysisComplete?.(completed);
    guard.checkpoint("serialize:analysis");
    guard.maximum("maxResultPoints", resultPointCount(serialized), "serialize");
    guard.maximum(
      "maxSerializedResultBytes",
      utf8Bytes(JSON.stringify({ status: "complete", analyses: serialized })),
      "serialize"
    );
  }
  circuit.analyses.splice(0, circuit.analyses.length, ...analyses);
  const response = { status: "complete", analyses: serialized };
  return response;
}
function protocolAnalysis(analysis) {
  switch (analysis.type) {
    case "op":
    case "dc":
    case "tran":
    case "ac":
      return analysis;
    case "noise":
    case "sp":
    case "disto":
    case "tf":
    case "sens":
      throw new UnsupportedProtocolAnalysisError(analysis.type);
  }
}
var UnsupportedProtocolAnalysisError = class extends Error {
  constructor(analysis) {
    super(`Protocol v1 does not support '${analysis}' analysis results`);
    this.analysis = analysis;
    this.name = "UnsupportedProtocolAnalysisError";
  }
  analysis;
};
function mapProtocolErrorV1(error) {
  if (isWireApiError(error)) return wireApiError(error);
  if (error instanceof ProtocolExecutionError) return wireApiError(error.apiError);
  if (error instanceof UnsupportedProtocolAnalysisError) {
    return apiError("UNSUPPORTED_FEATURE", error, "validation", { analysis: error.analysis });
  }
  if (error instanceof ParseError) {
    return apiError("PARSE_ERROR", error, "parse", { line: error.line, context: error.context });
  }
  if (error instanceof TimestepTooSmallError) {
    return apiError("TIMESTEP_TOO_SMALL", error, "solve", {
      ...convergenceDetails(error),
      timestep: error.timestep
    });
  }
  if (error instanceof SingularMatrixError) {
    const details = {
      involvedNodes: error.involvedNodes.slice(0, MAX_DETAIL_NAMES),
      involvedBranches: error.involvedBranches.slice(0, MAX_DETAIL_NAMES)
    };
    if (error.pivotIndex !== void 0) details.pivotIndex = error.pivotIndex;
    return apiError("SINGULAR_MATRIX", error, "solve", details);
  }
  if (error instanceof ConvergenceError) {
    return apiError("CONVERGENCE_FAILED", error, "solve", convergenceDetails(error));
  }
  if (error instanceof CycleError) {
    return apiError("INVALID_CIRCUIT", error, "compile", { chain: error.chain.slice(0, MAX_DETAIL_NAMES) });
  }
  if (error instanceof TopologyPreflightError) {
    return apiError("INVALID_CIRCUIT", error, "validation", {
      kind: error.kind,
      involvedNodes: error.involvedNodes.slice(0, MAX_DETAIL_NAMES),
      sourcePaths: error.sourcePaths.slice(0, MAX_DETAIL_NAMES)
    });
  }
  if (error instanceof UnsupportedCircuitModelTypeError) {
    return apiError("UNSUPPORTED_FEATURE", error, "validation", {
      reason: error.code,
      modelName: error.modelName,
      modelType: error.modelType
    });
  }
  if (error instanceof ModelTypeMismatchError) {
    return apiError("INVALID_CIRCUIT", error, "compile", {
      reason: error.code,
      deviceName: error.deviceName,
      deviceKind: error.deviceKind,
      modelName: error.modelName,
      modelType: error.modelType,
      expectedTypes: [...error.expectedTypes]
    });
  }
  if (error instanceof InvalidCircuitError) {
    return apiError("INVALID_CIRCUIT", error, "compile", {});
  }
  if (error instanceof SpiceError) {
    return {
      code: "INTERNAL_ERROR",
      message: "Internal simulation error",
      retryable: false,
      phase: "solve",
      details: {}
    };
  }
  return {
    code: "INTERNAL_ERROR",
    message: "Internal simulation error",
    retryable: false,
    phase: "solve",
    details: {}
  };
}
function protocolSourcePath(request) {
  const paths = /* @__PURE__ */ new Map();
  if (request.input.format === "spice") {
    request.input.source.split(/\r?\n/).forEach((line, index) => {
      const trimmed = line.trim();
      if (trimmed === "" || trimmed.startsWith("*") || trimmed.startsWith(".")) return;
      const name = trimmed.split(/\s+/, 1)[0];
      if (name) paths.set(name.toUpperCase(), `/input/source/lines/${index}`);
    });
  } else if (request.input.format === "spice-ts") {
    request.input.document.circuit.components.forEach((component, index) => {
      paths.set(component.name.toUpperCase(), `/input/document/circuit/components/${index}`);
    });
  }
  return (deviceName) => {
    const rootName = deviceName.split(".", 1)[0].toUpperCase();
    return paths.get(deviceName.toUpperCase()) ?? paths.get(rootName) ?? `/compiled/devices/${jsonPointerSegment2(deviceName)}`;
  };
}
function jsonPointerSegment2(value) {
  return value.replaceAll("~", "~0").replaceAll("/", "~1");
}
async function requestCircuit(request, guard) {
  switch (request.input.format) {
    case "spice": {
      const files = request.input.virtualFiles ?? {};
      const circuit = await parseTitlelessAsync(request.input.source, async (path) => {
        const source = files[path];
        if (source === void 0) throw new ParseError(`Virtual include '${path}' was not provided`, 0, path);
        return source;
      }, guard);
      if (circuit.controlScript) throw new UnsupportedProtocolAnalysisError(".control script");
      return circuit;
    }
    case "spice-ts":
      return circuitFromDocument(request.input.document);
    case "circuit-json":
      throw new InvalidCircuitError("circuit-json conversion is owned by @spice-ts/circuit-json and is unavailable in core");
  }
}
function protocolGuard(request, execution) {
  return new ProtocolExecutionGuard(request.options?.limits ?? {}, execution);
}
function enforceInputLimits(request, guard) {
  if (request.input.format === "spice") {
    const files = request.input.virtualFiles ?? {};
    const sourceBytes = utf8Bytes(request.input.source) + Object.values(files).reduce((total, source) => total + utf8Bytes(source), 0);
    guard.maximum("maxSourceBytes", sourceBytes, "validation");
    guard.maximum("maxVirtualFiles", Object.keys(files).length, "validation");
    return;
  }
  if (request.input.format === "spice-ts") {
    guard.maximum(
      "maxComponents",
      request.input.document.circuit.components.length,
      "compile"
    );
  }
  guard.maximum("maxSourceBytes", utf8Bytes(JSON.stringify(request.input)), "validation");
}
function enforcePointLimit(analyses, guard, reltol, step) {
  guard.maximum("maxResultPoints", estimateProtocolResultPointsV1(analyses, step, reltol), "validation");
}
function estimateProtocolResultPointsV1(analyses, step, reltol = DEFAULT_OPTIONS.reltol) {
  const analysisPoints = analyses.reduce(
    (total, analysis) => total + estimatedAnalysisPoints(analysis, reltol),
    0
  );
  return analysisPoints * estimatedStepCount(step);
}
function requestReltol(request, circuit) {
  return request.options?.reltol ?? circuit.simulationOptions.reltol ?? DEFAULT_OPTIONS.reltol;
}
function estimatedStepCount(step) {
  if (!step) return 1;
  if (step.sweepMode === "list") return step.values?.length ?? 0;
  const start = step.start;
  const stop = step.stop;
  if (start === void 0 || stop === void 0) return 0;
  if (step.sweepMode === "lin") return finiteLinearPoints(start, stop, step.increment ?? 0);
  const points = step.points ?? 0;
  const span = step.sweepMode === "dec" ? Math.log10(stop / start) : Math.log2(stop / start);
  return Number.isFinite(span) ? Math.max(0, Math.floor(span * points + 1 + 1e-12)) : 0;
}
function estimatedAnalysisPoints(analysis, reltol) {
  switch (analysis.type) {
    case "op":
      return 1;
    case "dc": {
      const primaryPoints = accumulatedLinearPointCount(analysis.start, analysis.stop, analysis.step);
      const secondaryPoints = analysis.secondary === void 0 ? 1 : accumulatedLinearPointCount(
        analysis.secondary.start,
        analysis.secondary.stop,
        analysis.secondary.step
      );
      return primaryPoints * secondaryPoints;
    }
    case "tran":
      return finiteLinearPoints(analysis.startTime ?? 0, analysis.stopTime, analysis.timestep);
    case "ac":
      return frequencyPointCount(analysis, reltol, "ac");
    case "noise":
    case "sp":
    case "disto":
    case "tf":
      return 0;
    case "sens": {
      if (analysis.mode === "dc") return 1;
      return frequencyPointCount(analysis, reltol, "sens");
    }
  }
}
function finiteLinearPoints(start, stop, step) {
  return directedLinearPointCount(start, stop, step);
}
function resultPointCount(analyses) {
  return analyses.reduce((total, analysis) => {
    switch (analysis.type) {
      case "op":
        return total + 1;
      case "dc":
        return total + analysis.axis.values.length;
      case "tran":
        return total + analysis.timeS.length;
      case "ac":
        return total + analysis.frequencyHz.length;
    }
  }, 0);
}
function utf8Bytes(value) {
  return new TextEncoder().encode(value).byteLength;
}
function coreOptions(options) {
  const backend = options?.backend ?? "spice-ts-js";
  if (backend === "spice-ts-wasm") {
    throw new InvalidCircuitError("Protocol backend 'spice-ts-wasm' is not available");
  }
  if (!isValidMaxTimestepOption(options?.maxTimestep)) {
    throw new ProtocolExecutionError({
      code: "INVALID_REQUEST",
      message: "'maxTimestep' must be a positive finite number or 0 (unset)",
      retryable: false,
      phase: "validation",
      details: { option: "maxTimestep" }
    });
  }
  return {
    simulator: backend === "spice-ts-js" ? "spice-ts" : "ngspice-wasm",
    abstol: options?.abstol,
    vntol: options?.vntol,
    reltol: options?.reltol,
    maxIterations: options?.maxIterations,
    maxTransientIterations: options?.maxTransientIterations,
    maxTimestep: options?.maxTimestep,
    integrationMethod: options?.integrationMethod,
    trtol: options?.trtol,
    gmin: options?.gmin
  };
}
function circuitFromDocument(document) {
  const circuit = new Circuit();
  for (const model of document.models) circuit.addModel(coreModel(model));
  for (const subcircuit of document.subcircuits) circuit.addSubcircuit(coreSubcircuit(subcircuit));
  for (const component of document.circuit.components) addComponent(circuit, component);
  for (const analysis of document.analyses) addAnalysis(circuit, analysis);
  return circuit;
}
function coreModel(model) {
  return { name: model.name, type: model.type, params: numberParams(model.params) };
}
function coreSubcircuit(subcircuit) {
  return {
    name: subcircuit.name,
    ports: [...subcircuit.ports],
    params: {},
    body: [
      ...(subcircuit.models ?? []).map(modelLine),
      ...subcircuit.components.map(componentLine)
    ]
  };
}
function addAnalysis(circuit, analysis) {
  switch (analysis.type) {
    case "op":
      circuit.addAnalysis("op");
      break;
    case "dc":
      circuit.addAnalysis("dc", analysis);
      break;
    case "tran":
      circuit.addAnalysis("tran", analysis);
      break;
    case "ac":
      circuit.addAnalysis("ac", analysis);
      break;
  }
}
function addComponent(circuit, component) {
  const p = component.params;
  const nodes = component.ports.map((port) => port.net);
  const named = (name, fallback) => component.ports.find((port) => port.name === name)?.net ?? nodes[fallback];
  const model = component.model ?? stringParam(p, "modelName");
  switch (component.type.toUpperCase()) {
    case "R":
      circuit.addResistor(component.name, named("p", 0), named("n", 1), numberParam(p, "resistance"));
      break;
    case "C":
      circuit.addCapacitor(component.name, named("p", 0), named("n", 1), optionalNumber(p, "capacitance"), model, numberParamsExcept(p, ["capacitance", "modelName"]));
      break;
    case "L":
      circuit.addInductor(component.name, named("p", 0), named("n", 1), optionalNumber(p, "inductance"), model, numberParamsExcept(p, ["inductance", "modelName"]));
      break;
    case "V":
      if (p.m !== void 0) throw new InvalidCircuitError(VOLTAGE_SOURCE_MULTIPLIER_ERROR);
      circuit.addVoltageSource(component.name, named("p", 0), named("n", 1), waveform(p));
      break;
    case "I":
      circuit.addCurrentSource(component.name, named("p", 0), named("n", 1), waveform(p), optionalNumber(p, "m"));
      break;
    case "D":
      circuit.addDiode(component.name, named("anode", 0), named("cathode", 1), model);
      break;
    case "Q":
      circuit.addBJT(component.name, named("collector", 0), named("base", 1), named("emitter", 2), required(model, "model"));
      break;
    case "M":
      circuit.addMOSFET(component.name, named("drain", 0), named("gate", 1), named("source", 2), required(model, "model"), numberParamsExcept(p, ["modelName", "channelType"]), component.ports.find((port) => port.name === "bulk")?.net);
      break;
    case "E":
      circuit.addVCVS(component.name, named("outP", 2), named("outN", 3), named("ctrlP", 0), named("ctrlN", 1), numberParam(p, "gain"));
      break;
    case "G":
      circuit.addVCCS(component.name, named("outP", 2), named("outN", 3), named("ctrlP", 0), named("ctrlN", 1), numberParam(p, "gm"));
      break;
    case "H":
      circuit.addCCVS(component.name, named("outP", 0), named("outN", 1), required(stringParam(p, "controlSource"), "controlSource"), numberParam(p, "gain"));
      break;
    case "F":
      circuit.addCCCS(component.name, named("outP", 0), named("outN", 1), required(stringParam(p, "controlSource"), "controlSource"), numberParam(p, "gain"));
      break;
    case "X":
      circuit.addSubcircuitInstance(component.name, nodes, required(component.subcircuit ?? stringParam(p, "subcircuit"), "subcircuit"), numberParamsExcept(p, ["subcircuit"]));
      break;
    default:
      throw new InvalidCircuitError(`Unsupported native component type '${component.type}'`);
  }
}
function appendAnalysisResult(target, result, analysis, analysisIndex, nodeNames, branchNames, circuit) {
  if (result.steps) {
    result.steps.forEach((step, index) => target.push(serializeOne(step, analysis, analysisIndex, nodeNames, branchNames, circuit, {
      index,
      parameter: step.paramName,
      value: step.paramValue
    })));
  } else {
    target.push(serializeOne(result, analysis, analysisIndex, nodeNames, branchNames, circuit));
  }
}
function serializeOne(result, analysis, analysisIndex, nodeNames, branchNames, circuit, step) {
  switch (analysis.type) {
    case "op":
      return serializeOp(required(result.dc, "operating-point result"), analysisIndex, nodeNames, branchNames, step);
    case "dc":
      return serializeDc(required(result.dcSweep, "DC-sweep result"), analysis, analysisIndex, nodeNames, branchNames, circuit, step);
    case "tran":
      return serializeTransient(required(result.transient, "transient result"), analysisIndex, nodeNames, branchNames, step);
    case "ac":
      return serializeAc(required(result.ac, "AC result"), analysisIndex, nodeNames, branchNames, step);
  }
}
function serializeOp(result, analysisIndex, nodes, branches, step) {
  return withStep({
    type: "op",
    analysisIndex,
    voltagesV: sortedRecord(nodes, (name) => result.voltage(name)),
    currentsA: sortedRecord(branches, (name) => result.current(name))
  }, step);
}
function serializeDc(result, analysis, analysisIndex, nodes, branches, circuit, step) {
  const normalizedSourceName = analysis.source.toUpperCase();
  const source = circuit.toIR().components.find(
    (component) => (component.type === "V" || component.type === "I") && component.name.toUpperCase() === normalizedSourceName
  );
  return withStep({
    type: "dc",
    analysisIndex,
    axis: { name: source?.name ?? analysis.source, unit: source?.type === "I" ? "A" : "V", values: Array.from(result.sweepValues) },
    voltagesV: sortedRecord(nodes, (name) => Array.from(result.voltage(name))),
    currentsA: sortedRecord(branches, (name) => Array.from(result.current(name)))
  }, step);
}
function serializeTransient(result, analysisIndex, nodes, branches, step) {
  return withStep({
    type: "tran",
    analysisIndex,
    timeS: [...result.time],
    voltagesV: sortedRecord(nodes, (name) => [...result.voltage(name)]),
    currentsA: sortedRecord(branches, (name) => [...result.current(name)])
  }, step);
}
function serializeAc(result, analysisIndex, nodes, branches, step) {
  const polar = (values) => values.map((value) => ({
    magnitude: value.magnitude,
    phaseDegrees: value.phase
  }));
  return withStep({
    type: "ac",
    analysisIndex,
    frequencyHz: [...result.frequencies],
    voltagePhasors: sortedRecord(nodes, (name) => polar(result.voltage(name))),
    currentPhasors: sortedRecord(branches, (name) => polar(result.current(name)))
  }, step);
}
function sortedRecord(names, value) {
  const result = {};
  for (const name of [...names].sort(compareCodePoints2)) result[name] = value(name);
  return result;
}
function compareCodePoints2(left, right) {
  const a = Array.from(left, (character) => character.codePointAt(0));
  const b = Array.from(right, (character) => character.codePointAt(0));
  for (let index = 0; index < Math.min(a.length, b.length); index++) {
    if (a[index] !== b[index]) return a[index] - b[index];
  }
  return a.length - b.length;
}
function withStep(result, step) {
  return step ? { ...result, step } : result;
}
function convergenceDetails(error) {
  const details = {
    kind: error.kind,
    oscillatingNodes: error.oscillatingNodes.slice(0, MAX_DETAIL_NAMES),
    solutionSummary: solutionSummary(error.lastSolution, error.prevSolution)
  };
  if (error.time !== void 0) details.time = error.time;
  if (error.dt !== void 0) details.dt = error.dt;
  if (error.gmin !== void 0) details.gmin = error.gmin;
  return details;
}
function solutionSummary(last, previous) {
  const extrema = (values) => values.length === 0 ? [null, null] : [Math.min(...values), Math.max(...values)];
  const [lastMinimum, lastMaximum] = extrema(last);
  const [previousMinimum, previousMaximum] = extrema(previous);
  let changedCount = Math.abs(last.length - previous.length);
  for (let index = 0; index < Math.min(last.length, previous.length); index++) {
    if (last[index] !== previous[index]) changedCount++;
  }
  return { lastMinimum, lastMaximum, previousMinimum, previousMaximum, changedCount };
}
function apiError(code, error, phase, details) {
  return { code, message: wireMessage(error.message), retryable: false, phase, details: wireObject(details) };
}
function wireApiError(error) {
  return {
    code: error.code,
    message: wireMessage(error.message),
    retryable: error.retryable,
    phase: error.phase,
    details: wireObject(error.details)
  };
}
function isWireApiError(value) {
  if (!isRecord(value)) return false;
  return typeof value.code === "string" && API_ERROR_CODES.has(value.code) && typeof value.message === "string" && typeof value.retryable === "boolean" && typeof value.phase === "string" && API_ERROR_PHASES.has(value.phase) && isJsonObject(value.details);
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function isJsonObject(value) {
  return isRecord(value) && isJsonValue(value, /* @__PURE__ */ new WeakSet());
}
function isJsonValue(value, seen) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value !== "object") return false;
  if (seen.has(value)) return false;
  seen.add(value);
  if (Array.isArray(value)) {
    const valid2 = Object.keys(value).length === value.length && value.every((entry) => isJsonValue(entry, seen));
    seen.delete(value);
    return valid2;
  }
  const valid = Object.values(value).every((entry) => isJsonValue(entry, seen));
  seen.delete(value);
  return valid;
}
function wireMessage(message) {
  return message.replace(/\bspice-ts\b(?!-(?:js|wasm))/g, "spice-ts-js");
}
function wireObject(value) {
  return Object.fromEntries(Object.entries(value).filter(([key]) => key.toLowerCase() !== "stack").map(([key, entry]) => [key, wireValue(entry)]));
}
function wireValue(value) {
  if (typeof value === "string") return wireMessage(value);
  if (Array.isArray(value)) return value.map(wireValue);
  if (value !== null && typeof value === "object") return wireObject(value);
  return value;
}
function numberParams(params) {
  return numberParamsExcept(params, []);
}
function numberParamsExcept(params, excluded) {
  const result = {};
  for (const [key, value] of Object.entries(params)) {
    if (!excluded.includes(key) && typeof value === "number") result[key] = value;
  }
  return result;
}
function numberParam(params, name) {
  const value = params[name];
  if (typeof value !== "number") throw new InvalidCircuitError(`Native component parameter '${name}' must be a number`);
  return value;
}
function optionalNumber(params, name) {
  const value = params[name];
  if (value === void 0) return void 0;
  if (typeof value !== "number") throw new InvalidCircuitError(`Native component parameter '${name}' must be a number`);
  return value;
}
function stringParam(params, name) {
  const value = params[name];
  return typeof value === "string" ? value : void 0;
}
function required(value, name) {
  if (value === void 0) throw new InvalidCircuitError(`Missing ${name}`);
  return value;
}
function waveform(params) {
  const kind = stringParam(params, "waveform") ?? "dc";
  switch (kind) {
    case "dc":
      return { dc: numberParam(params, "dc") };
    case "ac":
      return { type: "ac", dc: optionalNumber(params, "dc"), magnitude: optionalNumber(params, "magnitude") ?? 1, phase: optionalNumber(params, "phase") ?? 0 };
    case "sin":
      return { type: "sin", offset: numberParam(params, "offset"), amplitude: numberParam(params, "amplitude"), frequency: numberParam(params, "frequency"), delay: optionalNumber(params, "delay"), damping: optionalNumber(params, "damping"), phase: optionalNumber(params, "phase") };
    case "pulse":
      return { type: "pulse", v1: numberParam(params, "v1"), v2: numberParam(params, "v2"), delay: numberParam(params, "delay"), rise: numberParam(params, "rise"), fall: numberParam(params, "fall"), width: numberParam(params, "width"), period: numberParam(params, "period") };
    case "pwl": {
      const points = params.points;
      const delay = optionalNumber(params, "delay");
      const repeat = optionalNumber(params, "repeat");
      const options = { ...delay !== void 0 ? { delay } : {}, ...repeat !== void 0 ? { repeat } : {} };
      if (typeof points === "string") return { type: "pwl", points: parseIrPwlPoints(points), ...options };
      if (Array.isArray(points)) return { type: "pwl", points: points.map((point, index) => {
        if (typeof point !== "object" || point === null || Array.isArray(point)) throw new InvalidCircuitError(`Native PWL point ${index} is invalid`);
        const entry = point;
        return { time: numberParam(entry, "time"), value: numberParam(entry, "value") };
      }), ...options };
      throw new InvalidCircuitError("Native PWL parameter 'points' must be an array or CircuitIR string");
    }
    default:
      throw new InvalidCircuitError(`Unsupported native source waveform '${kind}'`);
  }
}
function parseIrPwlPoints(value) {
  if (value === "") return [];
  return value.split(",").map((point, index) => {
    const separator = point.indexOf(":");
    if (separator <= 0 || separator !== point.lastIndexOf(":")) {
      throw new InvalidCircuitError(`Native PWL point ${index} is invalid`);
    }
    const time = Number(point.slice(0, separator));
    const sample = Number(point.slice(separator + 1));
    if (!Number.isFinite(time) || !Number.isFinite(sample)) {
      throw new InvalidCircuitError(`Native PWL point ${index} is invalid`);
    }
    return { time, value: sample };
  });
}
function modelLine(model) {
  const params = Object.entries(numberParams(model.params)).map(([key, value]) => `${key}=${value}`).join(" ");
  return `.model ${model.name} ${model.type}${params ? ` (${params})` : ""}`;
}
function componentLine(component) {
  const circuit = new Circuit();
  addComponent(circuit, component);
  return circuit.toNetlist().split("\n").find((line) => line.startsWith(component.name + " ")) ?? (() => {
    throw new InvalidCircuitError(`Unable to serialize subcircuit component '${component.name}'`);
  })();
}

// src/protocol/canonical-json.ts
var CanonicalJsonError = class extends TypeError {
  constructor(code, path) {
    super(`${code} at ${path || "/"}`);
    this.code = code;
    this.path = path;
    this.name = "CanonicalJsonError";
  }
  code;
  path;
};
var escapePointer = (key) => key.replaceAll("~", "~0").replaceAll("/", "~1");
function compareUnicodeCodePoints(left, right) {
  const a = Array.from(left, (character) => character.codePointAt(0));
  const b = Array.from(right, (character) => character.codePointAt(0));
  for (let index = 0; index < Math.min(a.length, b.length); index++) {
    if (a[index] !== b[index]) return a[index] - b[index];
  }
  return a.length - b.length;
}
function canonicalJson(value) {
  const ancestors = /* @__PURE__ */ new Set();
  const serialize = (current, path) => {
    if (current === null || typeof current === "boolean" || typeof current === "string") return JSON.stringify(current);
    if (typeof current === "number") {
      if (!Number.isFinite(current)) throw new CanonicalJsonError("NON_FINITE_NUMBER", path);
      return Object.is(current, -0) ? "0" : JSON.stringify(current);
    }
    if (typeof current !== "object") throw new CanonicalJsonError("UNSUPPORTED_JSON_VALUE", path);
    if (ancestors.has(current)) throw new CanonicalJsonError("CYCLIC_VALUE", path);
    ancestors.add(current);
    try {
      if (Array.isArray(current)) {
        const entries = [];
        for (let index = 0; index < current.length; index++) {
          if (!(index in current)) throw new CanonicalJsonError("SPARSE_ARRAY", `${path}/${index}`);
          entries.push(serialize(current[index], `${path}/${index}`));
        }
        return `[${entries.join(",")}]`;
      }
      const prototype = Object.getPrototypeOf(current);
      if (prototype !== Object.prototype && prototype !== null) throw new CanonicalJsonError("UNSUPPORTED_JSON_VALUE", path);
      const record = current;
      return `{${Object.keys(record).sort(compareUnicodeCodePoints).map(
        (key) => `${JSON.stringify(key)}:${serialize(record[key], `${path}/${escapePointer(key)}`)}`
      ).join(",")}}`;
    } finally {
      ancestors.delete(current);
    }
  };
  return serialize(value, "");
}
function utf8Encode(value) {
  return new TextEncoder().encode(value);
}
var rotateRight = (value, amount) => value >>> amount | value << 32 - amount;
var SHA256_CONSTANTS = Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
function sha256(bytes) {
  const bitLength = bytes.length * 8;
  const paddedLength = Math.ceil((bytes.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296));
  view.setUint32(paddedLength - 4, bitLength >>> 0);
  const state = Uint32Array.from([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  const words = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index++) words[index] = view.getUint32(offset + index * 4);
    for (let index = 16; index < 64; index++) {
      const x = words[index - 15];
      const y = words[index - 2];
      const s0 = rotateRight(x, 7) ^ rotateRight(x, 18) ^ x >>> 3;
      const s1 = rotateRight(y, 17) ^ rotateRight(y, 19) ^ y >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = state;
    for (let index = 0; index < 64; index++) {
      const sum1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choose = e & f ^ ~e & g;
      const temporary1 = h + sum1 + choose + SHA256_CONSTANTS[index] + words[index] >>> 0;
      const sum0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = a & b ^ a & c ^ b & c;
      const temporary2 = sum0 + majority >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temporary1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temporary1 + temporary2 >>> 0;
    }
    state[0] = state[0] + a >>> 0;
    state[1] = state[1] + b >>> 0;
    state[2] = state[2] + c >>> 0;
    state[3] = state[3] + d >>> 0;
    state[4] = state[4] + e >>> 0;
    state[5] = state[5] + f >>> 0;
    state[6] = state[6] + g >>> 0;
    state[7] = state[7] + h >>> 0;
  }
  return Array.from(state, (word) => word.toString(16).padStart(8, "0")).join("");
}
function sha256CanonicalJson(value) {
  return sha256(utf8Encode(canonicalJson(value)));
}

// src/protocol/envelopes.ts
var CAPABILITIES = {
  apiVersion: "1",
  kind: "capabilities",
  capabilityId: "protocol-v1",
  analyses: [
    { id: "analysis:op", type: "op" },
    { id: "analysis:dc", type: "dc" },
    { id: "analysis:tran", type: "tran" },
    { id: "analysis:ac", type: "ac" }
  ],
  inputFormats: [
    { id: "input:spice", format: "spice" },
    { id: "input:spice-ts", format: "spice-ts" }
  ],
  limits: [
    { id: "limit:maxSourceBytes", name: "maxSourceBytes", unit: "bytes" },
    { id: "limit:maxVirtualFiles", name: "maxVirtualFiles", unit: "count" },
    { id: "limit:maxIncludeDepth", name: "maxIncludeDepth", unit: "depth" },
    { id: "limit:maxComponents", name: "maxComponents", unit: "count" },
    { id: "limit:maxSubcircuitDepth", name: "maxSubcircuitDepth", unit: "depth" },
    { id: "limit:maxAnalyses", name: "maxAnalyses", unit: "count" },
    { id: "limit:maxResultPoints", name: "maxResultPoints", unit: "count" },
    { id: "limit:maxSerializedResultBytes", name: "maxSerializedResultBytes", unit: "bytes" },
    { id: "limit:maxWallTimeMs", name: "maxWallTimeMs", unit: "milliseconds" }
  ],
  completions: ["complete", "failed", "limited", "cancelled"]
};
function protocolCapabilitiesV1() {
  return structuredClone(CAPABILITIES);
}
async function executeProtocolV1(request, options = {}) {
  const now = options.now ?? (() => performance.now());
  const startedAtMs = sampleTime(now);
  let inputHash = "";
  let requestId = options.requestId;
  const completed = [];
  const execution = {
    signal: options.signal,
    now,
    onSafePoint: options.onSafePoint,
    onAnalysisComplete: (analysis) => {
      completed.push(analysis);
      options.onAnalysisComplete?.(analysis);
    }
  };
  try {
    inputHash = sha256CanonicalJson(request);
    requestId ??= `request:${inputHash}`;
    const result = normalizeNegativeZero(await simulateProtocolV1(request, execution));
    const resultHash = sha256CanonicalJson(result);
    const metadata = metadataFor(
      inputHash,
      startedAtMs,
      now,
      "complete",
      false,
      safeRequestedAnalysisCount(request),
      result.analyses,
      resultHash
    );
    return {
      apiVersion: "1",
      kind: "terminal",
      ok: true,
      requestId,
      data: result,
      metadata
    };
  } catch (cause) {
    if (!inputHash) inputHash = invalidInputHash(cause);
    requestId ??= `request:${inputHash}`;
    const error = protocolError(cause);
    const completion = error.code === "CANCELLED" ? "cancelled" : error.code === "RESOURCE_LIMIT" ? "limited" : "failed";
    const partialAnalyses = normalizeNegativeZero(completed);
    const metadata = metadataFor(
      inputHash,
      startedAtMs,
      now,
      completion,
      partialAnalyses.length > 0,
      safeRequestedAnalysisCount(request),
      partialAnalyses
    );
    return {
      apiVersion: "1",
      kind: "terminal",
      ok: false,
      requestId,
      error,
      partial: { status: "partial", analyses: partialAnalyses },
      metadata
    };
  }
}
function protocolError(cause) {
  if (cause instanceof CanonicalJsonError) {
    return {
      code: "INVALID_REQUEST",
      message: "Request is not canonical JSON",
      retryable: false,
      phase: "validation",
      details: { reason: cause.code, path: cause.path || "/" }
    };
  }
  return mapProtocolErrorV1(cause);
}
function invalidInputHash(cause) {
  const marker = cause instanceof CanonicalJsonError ? { code: cause.code, path: cause.path || "/" } : { code: "INVALID_REQUEST", path: "/" };
  return sha256CanonicalJson({ invalidRequest: marker });
}
function metadataFor(inputHash, startedAtMs, now, completion, partial, requestedAnalyses, analyses, resultHash) {
  const finishedAtMs = sampleTime(now);
  return {
    protocolVersion: "1",
    executionId: `execution:${inputHash}`,
    inputId: `input:${inputHash}`,
    ...resultHash ? { resultId: `result:${resultHash}` } : {},
    completion,
    partial,
    timing: {
      startedAtMs,
      finishedAtMs,
      durationMs: Math.max(0, finishedAtMs - startedAtMs)
    },
    counts: {
      requestedAnalyses,
      completedAnalyses: new Set(analyses.map((analysis) => analysis.analysisIndex)).size,
      resultPoints: pointCount(analyses)
    }
  };
}
function requestedAnalysisCount(request) {
  if (request.input.format === "spice-ts") return request.input.document.analyses.length;
  if (request.input.format === "circuit-json") return request.input.analyses.length;
  return Array.from(request.input.source.matchAll(/^\s*\.(?:op|dc|tran|ac|noise|tf|sens)\b/gim)).length;
}
function safeRequestedAnalysisCount(request) {
  try {
    return requestedAnalysisCount(request);
  } catch {
    return 0;
  }
}
function pointCount(analyses) {
  return analyses.reduce((total, analysis) => {
    switch (analysis.type) {
      case "op":
        return total + 1;
      case "dc":
        return total + analysis.axis.values.length;
      case "tran":
        return total + analysis.timeS.length;
      case "ac":
        return total + analysis.frequencyHz.length;
    }
  }, 0);
}
function sampleTime(now) {
  try {
    const value = now();
    return Number.isFinite(value) ? Object.is(value, -0) ? 0 : value : 0;
  } catch {
    return 0;
  }
}
function normalizeNegativeZero(value) {
  if (Array.isArray(value)) return value.map(normalizeNegativeZero);
  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value).map(([key, entry]) => [key, normalizeNegativeZero(entry)]);
    return Object.fromEntries(entries);
  }
  return Object.is(value, -0) ? 0 : value;
}
export {
  ACResult,
  CCCS,
  CCVS,
  Circuit,
  ControlScriptError,
  ControlScriptExitError,
  ConvergenceError,
  CycleError,
  DCResult,
  DCSweepResult,
  DEVICE_MODEL_TYPES,
  DistortionResult,
  InvalidCircuitError,
  ModelTypeMismatchError,
  NoiseResult,
  ParseError,
  PoleZeroResult,
  SParameterResult,
  SUPPORTED_MODEL_TYPES,
  SensitivityResult,
  SingularMatrixError,
  SpiceError,
  TimestepTooSmallError,
  TopologyPreflightError,
  TransferFunctionResult,
  TransientResult,
  UnsupportedCircuitModelTypeError,
  UnsupportedCodeModelError,
  UnsupportedControlCommandError,
  UnsupportedMeasureError,
  UnsupportedModelFlagError,
  UnsupportedModelLevelError,
  UnsupportedModelParameterError,
  UnsupportedModelTypeError,
  UnsupportedModelVersionError,
  UnsupportedMultiplicityError,
  UnsupportedResistorParameterError,
  UnsupportedSourceWaveformError,
  UnsupportedTemperatureError,
  VCCS,
  VCVS,
  WasmNgspiceSimulator,
  createSimulator,
  createTransientSim,
  estimateProtocolResultPointsV1,
  executeProtocolV1,
  frequencyGrid,
  frequencyPointCount,
  mapProtocolErrorV1,
  parse,
  parseAsync,
  parseTitleless,
  parseTitlelessAsync,
  preflightTopology,
  preprocess,
  protocolCapabilitiesV1,
  simulate,
  simulateProtocolV1,
  simulateStepStream,
  simulateStream,
  validateProtocolV1
};
//# sourceMappingURL=index.js.map