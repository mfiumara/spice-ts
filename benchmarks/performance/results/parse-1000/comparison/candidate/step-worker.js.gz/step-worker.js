import {
  executeStepWorkerMessage
} from "./chunk-O4B6AOBE.js";
import "./chunk-V4I3LOAC.js";

// src/analysis/step-worker.ts
void import("worker_threads").then(({ parentPort }) => {
  if (!parentPort) throw new Error("Step worker started without a parent port");
  const port = {
    postMessage: (message) => parentPort.postMessage(message),
    onMessage: (listener) => parentPort.on("message", listener)
  };
  port.onMessage((message) => {
    void executeStepWorkerMessage(message, port);
  });
});
//# sourceMappingURL=step-worker.js.map