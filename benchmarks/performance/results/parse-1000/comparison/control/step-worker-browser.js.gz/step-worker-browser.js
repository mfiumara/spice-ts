import {
  executeStepWorkerMessage
} from "./chunk-2BVLAX35.js";
import "./chunk-V5FY37JO.js";

// src/analysis/step-worker-browser.ts
var scope = globalThis;
var port = {
  postMessage: (message) => scope.postMessage(message),
  onMessage: (listener) => scope.addEventListener("message", (event) => listener(event.data))
};
port.onMessage((message) => {
  void executeStepWorkerMessage(message, port);
});
//# sourceMappingURL=step-worker-browser.js.map