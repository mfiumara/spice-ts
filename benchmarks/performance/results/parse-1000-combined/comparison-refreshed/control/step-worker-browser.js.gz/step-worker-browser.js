import {
  executeStepWorkerMessage
} from "./chunk-EXZ5BDPM.js";
import "./chunk-I3XRFWTT.js";

// src/analysis/step-worker-browser.ts
var scope = globalThis;
var port = {
  postMessage: (message) => scope.postMessage(message),
  onMessage: (listener) => scope.addEventListener("message", (event) => listener(event.data))
};
port.onMessage((message) => {
  void executeStepWorkerMessage(message, port);
});
//# sourceMappingURL=step-worker-browser.js.map