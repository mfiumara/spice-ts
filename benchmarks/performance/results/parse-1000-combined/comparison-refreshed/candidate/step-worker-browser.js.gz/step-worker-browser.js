import {
  executeStepWorkerMessage
} from "./chunk-FNP6LKA4.js";
import "./chunk-S3S6YARQ.js";

// src/analysis/step-worker-browser.ts
var scope = globalThis;
var port = {
  postMessage: (message) => scope.postMessage(message),
  onMessage: (listener) => scope.addEventListener("message", (event) => listener(event.data))
};
port.onMessage((message) => {
  void executeStepWorkerMessage(message, port);
});
//# sourceMappingURL=step-worker-browser.js.map