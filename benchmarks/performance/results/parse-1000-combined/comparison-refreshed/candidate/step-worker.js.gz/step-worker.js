import {
  executeStepWorkerMessage
} from "./chunk-FNP6LKA4.js";
import "./chunk-S3S6YARQ.js";

// src/analysis/step-worker.ts
void import("worker_threads").then(({ parentPort }) => {
  if (!parentPort) throw new Error("Step worker started without a parent port");
  const port = {
    postMessage: (message) => parentPort.postMessage(message),
    onMessage: (listener) => parentPort.on("message", listener)
  };
  port.onMessage((message) => {
    void executeStepWorkerMessage(message, port);
  });
});
//# sourceMappingURL=step-worker.js.map