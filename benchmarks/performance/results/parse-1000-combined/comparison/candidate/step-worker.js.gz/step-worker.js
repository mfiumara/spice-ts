import {
  executeStepWorkerMessage
} from "./chunk-EW7J6KK2.js";
import "./chunk-QMLZKPTC.js";

// src/analysis/step-worker.ts
void import("worker_threads").then(({ parentPort }) => {
  if (!parentPort) throw new Error("Step worker started without a parent port");
  const port = {
    postMessage: (message) => parentPort.postMessage(message),
    onMessage: (listener) => parentPort.on("message", listener)
  };
  port.onMessage((message) => {
    void executeStepWorkerMessage(message, port);
  });
});
//# sourceMappingURL=step-worker.js.map