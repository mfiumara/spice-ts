import {
  simulate
} from "./chunk-I3XRFWTT.js";

// src/analysis/step-worker-runtime.ts
async function executeStepWorkerMessage(message, port) {
  try {
    const result = await simulate(message.task.netlist, {
      ...message.task.options,
      stepWorkers: false
    });
    port.postMessage({ type: "result", result });
  } catch (error) {
    port.postMessage({
      type: "error",
      message: error instanceof Error ? error.message : String(error)
    });
  }
}

export {
  executeStepWorkerMessage
};
//# sourceMappingURL=chunk-EXZ5BDPM.js.map