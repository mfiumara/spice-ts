import {
  simulate
} from "./chunk-K7XN7XMK.js";

// src/analysis/step-worker-runtime.ts
async function executeStepWorkerMessage(message, port) {
  try {
    const result = await simulate(message.task.netlist, {
      ...message.task.options,
      stepWorkers: false
    });
    port.postMessage({ type: "result", result });
  } catch (error) {
    port.postMessage({
      type: "error",
      message: error instanceof Error ? error.message : String(error)
    });
  }
}

export {
  executeStepWorkerMessage
};
//# sourceMappingURL=chunk-IP3NJW4Y.js.map